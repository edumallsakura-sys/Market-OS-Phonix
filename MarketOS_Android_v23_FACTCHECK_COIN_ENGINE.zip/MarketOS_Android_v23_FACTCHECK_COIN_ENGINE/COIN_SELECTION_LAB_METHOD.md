# Coin Selection Lab Method — v23

The app implements the user's original practical Binance Spot prompt as a gated workflow.

Stage A — Real Binance Spot universe
- Read live SPOT/TRADING exchangeInfo.
- Prefer USDT then USDC then FDUSD.
- Remove stablecoins, wrapped and leveraged tokens.
- Meme is excluded by default unless explicitly enabled.
- Batch 24h ticker queries at 20 symbols.
- Pre-score /30 is research priority only.

Stage B — Selected-coin automatic facts
- Binance Spot price/volume/range/trades.
- Spot spread and depth.
- 4H/1D/1W/1M Spot candles.
- CoinGecko MC/FDV/supply only after identity is unambiguous.
- DefiLlama economics by exact gecko_id mapping.
- GoPlus automated contract/holder screening only for resolved EVM contract.
- Futures funding/OI only as crowding context.

Stage C — Research gates
- full unlock 7/30/60/90D
- product/usage
- narrative/sector flow
- catalyst calendar
- audit/exploit/admin context
- team/backer/ecosystem
- special/legal/monitoring risk
- invalidation and risk plan

Stage D — Original /100 score
10 + 15 + 15 + 15 + 10 + 10 + 10 + 5 + 5 + 5.
Unknown evidence is not renormalized.
Final remains LOCKED until every mandatory group is sufficiently sourced.
