# v21 Change Log
1. Coin Lab: bounded liquid universe, 10-symbol batches, no exchangeInfo, no full-market payload, no retry loop.
2. Header: compact app bar, Data Health drawer, refresh/settings icons, bottom nav only.
3. Cockpit: AI Research Brief rendered as decision cards; local engine fallback on quota/network failure.
4. DD: local liquidity/spread/depth/dilution flags; final score remains UNRATED until evidence gates are complete.
