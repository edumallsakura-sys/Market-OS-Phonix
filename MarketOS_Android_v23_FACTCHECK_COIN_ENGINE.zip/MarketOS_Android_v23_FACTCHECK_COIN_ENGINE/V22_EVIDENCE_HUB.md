# Market OS v22 — Evidence Hub

Coin Selection Lab now uses an evidence hierarchy rather than filling UNKNOWN with synthetic scores.

## Automatic structured sources
1. Binance Spot: price, volume, trades, order-book spread/depth.
2. CoinGecko: CoinGecko ID, MC/FDV/supply, project links, platform/contract mapping.
3. DefiLlama free endpoints (where a verified protocol mapping exists):
   - current TVL
   - fees
   - protocol revenue
   - token-holder revenue
4. GoPlus Token Security (where the selected contract/chain is supported):
   - contract/admin risk fields
   - holder count
   - top-10 raw/non-burn concentration
   - supported locked_detail records

## Unlock rule
GoPlus locked_detail is PARTIAL evidence only. It covers supported lock addresses/top holders and cannot be treated as a complete vesting calendar.
Full 7/30/60/90D unlock remains a required research gate.

## Final score
The app may show a Preliminary Evidence Score for verified components.
Final Investment Score remains locked until required evidence coverage, full unlock and sourced catalysts are available.

No new polling was added. All project-evidence calls run only for the selected coin.
