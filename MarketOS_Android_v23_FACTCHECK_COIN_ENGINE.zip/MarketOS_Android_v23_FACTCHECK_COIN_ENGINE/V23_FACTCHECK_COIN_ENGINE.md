# Market OS v23 — Fact-Check Coin Engine

## Why v22 was not fully faithful to the original coin prompt
v22 used a bounded hard-coded liquid universe and a 5×20 evidence score. That was safe for network usage but not equivalent to:
- scan the real Binance Spot universe,
- show rejected coins and reasons,
- score the original 10 categories /100,
- refuse final when full unlock/news/risk/action/source evidence is missing.

## v23 changes
1. Dynamic Binance Spot discovery
   - `/api/v3/exchangeInfo?permissions=SPOT&showPermissionSets=false&symbolStatus=TRADING`
   - one preferred pair per base: USDT → USDC → FDUSD
   - stable/wrapped/leveraged exclusion
   - optional meme inclusion and sector filter
   - 24h ticker batched at 20 symbols per request
   - no auto-retry loop.

2. Original prompt score restored
   - Spot/liquidity 10
   - Supply/MC-FDV/unlock 15
   - Product/usage 15
   - Revenue/fees/value capture 15
   - Narrative/sector flow 10
   - Catalyst 10
   - Security/audit 10
   - Team/backer/ecosystem 5
   - Chart/timing 5
   - Special risk 5
   Missing categories are NOT renormalized.

3. CoinGecko identity safety
   - exact symbol must be unique, otherwise AMBIGUOUS.
   - manual CoinGecko ID override can resolve ambiguity.
   - contract/security/economics mapping does not run as fact on ambiguous identity.

4. DefiLlama
   - dynamic mapping by exact `gecko_id` from `/protocols`
   - bounded 6-hour in-memory directory cache.

5. Spot timing
   - Binance Spot 4H / 1D / 1W / 1M klines
   - SMA20/SMA50, RSI14, ATR%, 20-bar return, volume ratio.
   - Funding/OI is context only.

6. Unlock semantics
   - GoPlus no lock record is UNKNOWN, never `$0 unlock`.
   - full unlock requires grounded source and 30/90D windows before it can be VERIFIED.

7. Grounded research closes gates only after validation
   - Gemini grounded sources required.
   - structured evidence block is parsed.
   - source URL must be present in grounding metadata.
   - non-grounded providers cannot close web-research gates.

8. FRED semantics
   - Loaded != Fresh.
   - UI shows Loaded / Fresh / Stale / Failed separately.

## Safety
No new polling was added. Binance universe scan is user-triggered. Deep DD and research are selected-coin only.
Final score stays locked until the prompt's minimum-data checklist is complete.
