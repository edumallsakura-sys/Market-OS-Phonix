# Market OS v23 — Audit & Fact-Check Notes

## Main findings corrected from v22
- `Loaded` FRED observations are separated from `Fresh` observations. HTTP success is not treated as new economic data.
- Coin Selection Lab no longer uses a hard-coded liquid list as if it were the full Binance Spot universe.
- Binance Stage A is user-triggered and reads live `exchangeInfo` with SPOT/TRADING filters, then batches 24h ticker requests in groups of 20.
- CoinGecko ticker collisions are treated as `AMBIGUOUS`; contract/security/fundamental mapping is blocked until identity is resolved.
- DefiLlama mapping uses exact `gecko_id` from the live protocol directory rather than a fixed ticker mapping.
- GoPlus `no lock record` is `UNKNOWN`, not `$0 unlock`.
- The score now follows the original 10 categories totaling 100 points. Missing categories are never renormalized.
- Spot timing is based on Binance Spot 4H/1D/1W/1M candles; futures funding/OI remains context only.
- Gemini Grounded research can merge evidence only when returned source URLs are present in grounding metadata. Full unlock has additional source/window checks.

## Source tiers used in the app
- Tier A: Binance / official project / official GitHub / official primary source.
- Tier B: CoinGecko / DefiLlama / GoPlus structured third-party data.
- Grounded research: source-backed only after grounding validation; otherwise UNVERIFIED.

## Runtime limitation
Static checks were completed in this environment, but a real Android Gradle compile and device/network runtime test still need GitHub Actions / installed APK. The included Universal FINAL workflow is unchanged.
