MarketOS GitHub ONE-CLICK v35.2.2 — COIN RESEARCH RELIABILITY

PHẠM VI SỬA CÓ CHỦ ĐÍCH
- Chỉ tập trung Coin Selection Lab → Lọc → Research → Deep Due Diligence.
- Không redesign Macro/Policy/Track Record ở vòng này.

SỬA LỖI CHÍNH
- Lọc/Deep DD/AI Research có bounded interactive executor riêng, không bị background refresh làm đói worker.
- Mọi queue rejection trả callback lỗi rõ; không còn trạng thái UI chờ im lặng.
- Lọc coin không block trên DefiLlama stablecoin metadata; dùng bounded cache + hard safety list và refresh metadata bất đồng bộ.
- FAST shortlist hiện trước; top-10 enrichment có wall-clock budget hữu hạn.
- UI watchdog tự thoát “Đang lọc”/“Đang research” nếu nguồn quá chậm, không auto-retry.
- Deep DD trả progress SPOT → DEPTH → TECHNICAL → IDENTITY để có thông tin sử dụng trước khi provider chậm hoàn tất.
- Khôi phục nút Research coin rõ ràng và Research trên từng ứng viên.

CÁCH BUILD
1) Giải nén ONE-CLICK vào root repo GitHub.
2) Commit/push .github/workflows/build-apk.yml và projects/*.zip.
3) Actions > Universal Android ZIP Builder V35.2.2 > Run workflow.
4) Tải artifact Android-APKs.

Version: 35.0.4 / versionCode 43
UI: v35.2.2
Engine/hash semantics: 35.0.0 (unchanged)
Source: projects/MarketOS_Android_v35_2_2_COIN_RESEARCH_RELIABILITY.zip
