# Market OS v19 — Event Driven + Delta Feed

Fixes:
- failure backoff/cooldown: no request storm after source errors
- single 30s scheduler checks deadlines; network calls remain deadline/event driven
- screen with no automatic data (Coin Lab) no longer shows Infinity:NaN
- Binance scan uses MINI 24h ticker to keep response below bounded network limits
- obsolete GOLDAMGBD228NLBM removed from FRED CORE batch
- Gold remains market-feed only; unavailable means unavailable
- Data Lab adds What Changed: value/date deltas since previous sync
- Policy adds Release Radar explaining scheduled official data vs headlines
- partial FRED batch triggers cooldown rather than immediate repeat
- failures do not become “fresh”

Universal FINAL workflow unchanged.
