# Market OS v26 — Auditable Decision Engine

Core principle: source truth -> freshness -> regime -> cross-asset confirmation -> Binance Spot universe -> deep DD -> evidence lock -> capital gate.

v26 specifically fixes:
1. Fed Recent Postings titles and latest-content filtering.
2. Separates Fed news from FRED numeric-data confirmation.
3. Makes Coin Lab Stage A a real bounded research-priority screen using live Binance Spot + daily candles, not just 24h volume.
4. Explains LOCK as insufficient evidence rather than a negative signal.
5. Strengthens cross-asset confirmation.
6. Labels macro `/100` values as internal heuristic Signal Indices.
7. Keeps missing data UNKNOWN; no renormalization.

Version 26.0.0 / versionCode 29.
