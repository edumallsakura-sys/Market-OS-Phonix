Market OS Phoenix v2.3 — ONECLICK

1) Giải nén file này.
2) Upload toàn bộ nội dung vào root repository GitHub.
3) Actions -> Build MarketOS Phoenix v2.3 APK -> Run workflow.
4) Workflow tự tìm ZIP trong projects/, giải nén, chạy static audit + node --check rồi build APK.

v2.3 tập trung sửa Fed Policy: không dùng nút link thay ingestion; dùng official investor-relevant feeds + Recent Postings, có fallback HTML và cache label.
