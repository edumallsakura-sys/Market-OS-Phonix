# Market OS Phoenix v2.3 — Fed Signal Stream Fact-check

Ngày kiểm: 14/09/2026.

## Vì sao v2.2 nhìn như “gán link” và tin chậm

1. UI đặt nút `Z.1 ↗` và `X Fed ↗` cạnh các bộ lọc. Hai nút này chỉ mở trang ngoài, không tạo dữ liệu/insight trong app.
2. `All Data RSS` là feed DDP rất rộng. Nó vừa nhiều nhiễu vừa có thể vượt giới hạn response bounded của app; khi fail, Source Health hiện dấu X nhưng người dùng vẫn không có dữ liệu thay thế hữu ích.
3. `Recent Postings` có nhiều anchor generic như `Statistical Release`, `Publications`, `Joint Press Release`; parser v2.2 đôi khi giữ nguyên nhãn generic thay vì lấy tiêu đề thực ở phần text kế bên.
4. Cache Fed được render ngay khi mở tab nhưng UI không nói rõ đó là cache, nên dữ liệu cũ có thể trông như live.

## Sửa trong v2.3

- Bỏ hai nút Z.1/X khỏi màn Chính sách. Link không còn được coi là chức năng.
- Bỏ `datadownload.xml` khỏi ingestion chính.
- Thay bằng các official feed đầu tư trọng yếu:
  - Z.1 Financial Accounts
  - H.4.1 Factors Affecting Reserve Balances
  - H.8 Assets and Liabilities of Commercial Banks
  - H.15 Selected Interest Rates
  - Policy Rates
  - H.6 Money Stock Measures
  - G.17 Industrial Production and Capacity Utilization
  - G.19 Consumer Credit
  - SLOOS Senior Loan Officer Opinion Survey
- Giữ Recent Postings, monetary press, all press, speeches, testimony, board meetings, FEDS Notes.
- XML feed lỗi sẽ thử HTML mirror chính thức cùng tên feed.
- Không thêm cache-busting query vào Fed XML endpoints.
- Cache Fed tối đa 24h mới được render tạm; UI phải ghi rõ `Fed: cache` và “đang đồng bộ lại”.
- Recent Postings generic title được resolve bằng DOM context và mapping release URL.
- Mỗi item có `theme` + `Ý nghĩa đầu tư` deterministic, không AI và không tự biến thành BUY/SELL.
- Source Health thu gọn vào details, không chiếm màn hình chính.

## Fact-check các nguồn quan trọng

- Federal Reserve Recent Postings là master index chính thức.
- Z.1 2026:Q2 được phát hành ngày 11/09/2026.
- H.4.1 là release hàng tuần của bảng cân đối/reserve balances; release gần nhất kiểm được trong đợt audit là 10/09/2026.
- H.15 là release lãi suất hàng ngày; trang chính thức kiểm được cho release 11/09/2026 với dữ liệu đến 10/09/2026.
- Federal Reserve có feed riêng cho Z.1, H.4.1, H.8, H.15, H.6, SLOOS và nhiều data release khác.

## X / @federalreserve

Không scrape X trong core v2.3. Public HTML của X không phải machine feed ổn định và dễ bị chặn/thay đổi; dùng scraper/mirror để đưa thẳng vào evidence sẽ làm giảm độ tin cậy. Nếu sau này cần ingest X tự động, nên dùng API chính thức với token và chỉ coi post là ALERT; claim đầu tư vẫn phải link ngược về `federalreserve.gov`.

## Regression scope

v2.3 chỉ thay:
- `MainActivity.java` — Fed ingestion/parser/cache labelling.
- `index.html` — Policy UI/Fed Signal Stream.
- version/build workflow/audit/docs.

Không thay logic macro FRED, gold fallback, crypto watchlist, order book, candles, Coin Selection Lab, CoinGecko, DefiLlama, ML Kit translation, Document Identity Gate hay Decision Gate.
