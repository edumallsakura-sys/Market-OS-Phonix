# Market OS v11 — Resilient Research

Bản v11 tập trung sửa hai lỗi thực tế:
- Gemini 503/high demand: retry có exponential backoff + jitter, sau đó fallback sang model Flash ổn định khác.
- So sánh tài liệu: chỉ cho phép ghép đúng họ tài liệu (FOMC minutes, discount-rate minutes, statement, MPR...), không fallback sang bài khác loại.

Giữ nguyên:
- Fed Deep Document Reader
- HTML/PDF trong app
- dịch sát nghĩa ML Kit / AI
- AI Research Note
- so sánh hai bản gần nhất
- Data Quality / Market Regime / Cross-Asset
- Adaptive Icon

Nguyên tắc:
- không dùng dữ liệu demo;
- không coi lỗi API là dữ liệu;
- không so sánh nếu document identity không đủ chắc chắn;
- link nguồn chỉ để kiểm chứng, không phải chức năng chính.
