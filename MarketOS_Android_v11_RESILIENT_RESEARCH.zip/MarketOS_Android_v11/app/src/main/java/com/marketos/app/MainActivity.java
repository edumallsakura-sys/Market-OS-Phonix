package com.marketos.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService executor = Executors.newFixedThreadPool(5);
    private Translator enViTranslator;
    private SharedPreferences prefs;

    private static class FeedItem {
        String title = "", link = "", pubDate = "", description = "", source = "";
        long epoch = 0L;
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("marketos_secure_config", MODE_PRIVATE);
        PDFBoxResourceLoader.init(getApplicationContext());
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.VIETNAMESE)
                .build();
        enViTranslator = Translation.getClient(options);

        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " MarketOS/9.0");
        webView.addJavascriptInterface(new NativeBridge(), "MarketNative");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class NativeBridge {
        @JavascriptInterface public void refreshFed() {
            executor.execute(() -> {
                try {
                    List<FeedItem> all = new ArrayList<>();
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/press_monetary.xml", "Monetary Policy"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/speeches.xml", "Speech"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/testimony.xml", "Testimony"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/press_all.xml", "Press Release"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/clp.xml", "Liquidity/Balance Sheet"));
                    List<FeedItem> unique = new ArrayList<>();
                    Set<String> seen = new HashSet<>();
                    for (FeedItem item : all) {
                        String key = item.link.isEmpty() ? item.title + item.pubDate : item.link;
                        if (seen.add(key)) unique.add(item);
                    }
                    Collections.sort(unique, (a,b) -> Long.compare(b.epoch, a.epoch));
                    JSONArray arr = new JSONArray();
                    for (int i=0;i<Math.min(unique.size(),140);i++) {
                        FeedItem x=unique.get(i); JSONObject o=new JSONObject();
                        o.put("title",x.title); o.put("link",x.link); o.put("pubDate",x.pubDate);
                        o.put("description",clean(x.description)); o.put("source",x.source); o.put("importance",importance(x));
                        arr.put(o);
                    }
                    JSONObject p=new JSONObject(); p.put("ok",true); p.put("updatedAt",isoNow()); p.put("items",arr);
                    send("onFedPayload",p.toString());
                } catch(Exception e) { sendError("onFedPayload", e); }
            });
        }

        @JavascriptInterface public void fetchFedArticle(String requestId, String url) {
            executor.execute(() -> {
                try {
                    assertOfficialFedUrl(url);
                    JSONObject article = fetchArticle(url);
                    String text = article.getString("text");
                    JSONObject p = new JSONObject();
                    p.put("ok", true); p.put("requestId", requestId); p.put("url", url);
                    p.put("title", article.optString("title"));
                    p.put("subtitle", article.optString("subtitle"));
                    p.put("byline", article.optString("byline"));
                    p.put("text", text);
                    p.put("paragraphs", article.optJSONArray("paragraphs"));
                    p.put("blocks", article.optJSONArray("blocks"));
                    p.put("sourcePageUrl", article.optString("sourcePageUrl", url));
                    p.put("contentUrl", article.optString("contentUrl", url));
                    p.put("htmlUrl", article.optString("htmlUrl", ""));
                    p.put("pdfUrl", article.optString("pdfUrl", ""));
                    p.put("contentKind", article.optString("contentKind", "HTML"));
                    p.put("analysis", analyzeTone(text));
                    p.put("investment", analyzeInvestmentChannels(text));
                    p.put("updatedAt", isoNow());
                    send("onFedArticlePayload", p.toString());
                } catch (Exception e) { sendReqError("onFedArticlePayload", requestId, e); }
            });
        }

        @JavascriptInterface public void translateToVietnamese(String requestId, String text) {
            executor.execute(() -> {
                try {
                    if (text == null || text.trim().isEmpty()) throw new IllegalArgumentException("Không có văn bản để dịch");
                    DownloadConditions conditions = new DownloadConditions.Builder().build();
                    Tasks.await(enViTranslator.downloadModelIfNeeded(conditions), 90, TimeUnit.SECONDS);
                    String translated = translateChunks(text);
                    JSONObject p = new JSONObject(); p.put("ok", true); p.put("requestId", requestId);
                    p.put("provider", "ML Kit on-device"); p.put("translated", translated);
                    send("onTranslationPayload", p.toString());
                } catch (Exception localError) {
                    try {
                        AiCfg cfg=getAiCfg();
                        String translated=callFaithfulTranslation(cfg,text);
                        JSONObject p = new JSONObject(); p.put("ok", true); p.put("requestId", requestId);
                        p.put("provider", "AI API fallback"); p.put("translated", translated);
                        send("onTranslationPayload", p.toString());
                    } catch (Exception fallbackError) {
                        sendReqError("onTranslationPayload", requestId, new IllegalStateException("ML Kit: "+localError.getMessage()+" | AI fallback: "+fallbackError.getMessage()));
                    }
                }
            });
        }

        @JavascriptInterface public void saveAiTranslator(String provider, String endpoint, String model, String apiKey) {
            try {
                String pv = provider == null ? "AUTO" : provider.trim().toUpperCase(Locale.US);
                String ep = endpoint == null ? "" : endpoint.trim();
                if (pv.equals("GEMINI") && !ep.contains("generativelanguage.googleapis.com")) ep = "";
                String md = model == null ? "" : model.trim();
                String key = apiKey == null ? "" : apiKey.trim();
                if (!ep.isEmpty()) {
                    Uri u=Uri.parse(ep);
                    if (!"https".equalsIgnoreCase(u.getScheme()) || u.getHost()==null) throw new IllegalArgumentException("Endpoint phải dùng HTTPS");
                }
                if (md.isEmpty()) md = pv.equals("GEMINI") ? "AUTO" : "llama-3.1-8b-instant";
                prefs.edit().putString("ai_provider", pv).putString("ai_endpoint", ep).putString("ai_model", md)
                        .putString("ai_key_secure", encryptSecret(key)).remove("ai_key").apply();
                JSONObject p=new JSONObject(); p.put("ok",true); p.put("provider",pv); p.put("endpoint",ep); p.put("model",md); p.put("hasKey",!key.isEmpty());
                send("onAiConfigPayload",p.toString());
            } catch(Exception e){ sendError("onAiConfigPayload",e); }
        }

        @JavascriptInterface public void getAiTranslatorConfig() {
            try {
                String savedProvider=prefs.getString("ai_provider","");
                String savedEndpoint=prefs.getString("ai_endpoint","");
                String savedModel=prefs.getString("ai_model","");
                String pv=savedProvider;
                if(pv.isEmpty()) pv=(savedModel.toLowerCase(Locale.US).startsWith("gemini-")||savedEndpoint.contains("generativelanguage.googleapis.com"))?"GEMINI":(!savedEndpoint.isEmpty()?"OPENAI_COMPATIBLE":"GEMINI");
                if(pv.equals("GEMINI")&&!savedEndpoint.contains("generativelanguage.googleapis.com")) savedEndpoint="";
                JSONObject p=new JSONObject(); p.put("ok",true); p.put("provider",pv);
                p.put("endpoint",savedEndpoint.isEmpty()?(pv.equals("GEMINI")?"":"https://api.groq.com/openai/v1/chat/completions"):savedEndpoint);
                p.put("model",savedModel.isEmpty()?(pv.equals("GEMINI")?"AUTO":"llama-3.1-8b-instant"):savedModel); p.put("activeModel",prefs.getString("ai_last_model",""));
                p.put("hasKey",hasStoredAiKey());
                send("onAiConfigPayload",p.toString());
            }catch(Exception ignored){}
        }

        @JavascriptInterface public void testAiTranslator(String requestId) {
            executor.execute(() -> {
                try {
                    AiCfg c = getAiCfg();
                    String out = callAi(c, "Bạn là bộ kiểm tra kết nối. Chỉ trả lời đúng: OK", "Trả lời OK.", 0.0);
                    JSONObject p=new JSONObject(); p.put("ok", out.toUpperCase(Locale.US).contains("OK")); p.put("requestId",requestId); p.put("provider",c.provider); p.put("model",c.model); p.put("message","Kết nối API hoạt động");
                    send("onAiTestPayload",p.toString());
                } catch(Exception e) { sendReqError("onAiTestPayload",requestId,e); }
            });
        }

        @JavascriptInterface public void translateWithAi(String requestId, String text) {
            executor.execute(() -> {
                try {
                    AiCfg c=getAiCfg();
                    String translated=callFaithfulTranslation(c,text);
                    JSONObject p=new JSONObject(); p.put("ok",true);p.put("requestId",requestId);p.put("provider",c.provider+(c.provider.equals("GEMINI")?" · "+c.model:""));p.put("translated",translated);
                    send("onTranslationPayload",p.toString());
                }catch(Exception e){sendReqError("onTranslationPayload",requestId,e);}
            });
        }

        @JavascriptInterface public void analyzeWithAi(String requestId, String title, String text) {
            executor.execute(() -> {
                try {
                    AiCfg c=getAiCfg();
                    String prompt = "TITLE: "+(title==null?"":title)+"\n\nSOURCE:\n"+(text==null?"":text);
                    String analysis = callInvestmentAi(c, prompt);
                    JSONObject p=new JSONObject(); p.put("ok",true); p.put("requestId",requestId); p.put("provider",c.provider+(c.provider.equals("GEMINI")?" · "+c.model:"")); p.put("analysisText",analysis);
                    send("onAiInvestmentPayload",p.toString());
                } catch(Exception e) { sendReqError("onAiInvestmentPayload",requestId,e); }
            });
        }

        @JavascriptInterface public void compareWithPrevious(String requestId, String currentUrl, String title, String source) {
            executor.execute(() -> {
                try {
                    assertOfficialFedUrl(currentUrl);
                    JSONObject current=fetchArticle(currentUrl);
                    String previousUrl=findPreviousComparableUrl(currentUrl,title,source);
                    if(previousUrl==null||previousUrl.isEmpty()) throw new IllegalStateException("Không tìm thấy bản gần nhất trước đó cùng loại trong nguồn Fed");
                    JSONObject previous=fetchArticle(previousUrl);
                    validateComparableDocuments(title,current,previous);
                    AiCfg cfg=getAiCfg();
                    String comparison=callComparisonAi(cfg, previous, current);
                    JSONObject p=new JSONObject(); p.put("ok",true);p.put("requestId",requestId);p.put("provider",cfg.provider+(cfg.provider.equals("GEMINI")?" · "+cfg.model:""));
                    p.put("previousTitle",previous.optString("title"));p.put("previousUrl",previousUrl);p.put("currentTitle",current.optString("title"));p.put("comparisonText",comparison);
                    send("onComparisonPayload",p.toString());
                }catch(Exception e){sendReqError("onComparisonPayload",requestId,e);}
            });
        }

        @JavascriptInterface public void openHtmlInApp(String url) {
            try { assertOfficialFedUrl(url); Intent i=new Intent(MainActivity.this, DocumentWebActivity.class); i.putExtra("url",url); startActivity(i); } catch(Exception ignored){}
        }

        @JavascriptInterface public void openPdfInApp(String url) {
            try { assertOfficialFedUrl(url); Intent i=new Intent(MainActivity.this, PdfViewerActivity.class); i.putExtra("url",url); startActivity(i); } catch(Exception ignored){}
        }

        @JavascriptInterface public void fetchFredSeries(String id) {
            executor.execute(() -> {
                try { send("onFredSeriesPayload", fetchFred(id).toString()); }
                catch(Exception e) { sendFredError(id,e); }
            });
        }

        @JavascriptInterface public void refreshCrypto() {
            executor.execute(() -> {
                try {
                    JSONObject out = new JSONObject();
                    JSONObject simple = httpJson("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd&include_24hr_change=true");
                    JSONObject global = httpJson("https://api.coingecko.com/api/v3/global").optJSONObject("data");
                    JSONObject btc = simple.optJSONObject("bitcoin");
                    JSONObject eth = simple.optJSONObject("ethereum");
                    if (btc == null || eth == null) throw new IllegalStateException("CoinGecko thiếu dữ liệu BTC/ETH");
                    out.put("ok", true);
                    out.put("btcUsd", btc.optDouble("usd", Double.NaN));
                    out.put("btc24", btc.optDouble("usd_24h_change", Double.NaN));
                    out.put("ethUsd", eth.optDouble("usd", Double.NaN));
                    out.put("eth24", eth.optDouble("usd_24h_change", Double.NaN));
                    if (global != null) {
                        JSONObject pct = global.optJSONObject("market_cap_percentage");
                        JSONObject tmc = global.optJSONObject("total_market_cap");
                        if (pct != null) out.put("btcDominance", pct.optDouble("btc", Double.NaN));
                        if (tmc != null) out.put("totalMarketCapUsd", tmc.optDouble("usd", Double.NaN));
                        out.put("marketCap24", global.optDouble("market_cap_change_percentage_24h_usd", Double.NaN));
                    }
                    out.put("updatedAt", isoNow());
                    out.put("source", "CoinGecko");
                    send("onCryptoPayload", out.toString());
                } catch (Exception e) { sendError("onCryptoPayload", e); }
            });
        }

        @JavascriptInterface public void openExternal(String url) {
            try {
                Uri u=Uri.parse(url); String h=u.getHost();
                if ("https".equalsIgnoreCase(u.getScheme()) && h!=null &&
                    (h.endsWith("federalreserve.gov") || h.endsWith("fred.stlouisfed.org") || h.endsWith("newyorkfed.org"))) {
                    startActivity(new Intent(Intent.ACTION_VIEW,u));
                }
            } catch(Exception ignored) {}
        }
    }

    private String translateChunks(String text) throws Exception {
        String normalized=text.replace("\r","").trim();
        List<String> chunks=new ArrayList<>(); int start=0;
        while(start<normalized.length()){
            int end=Math.min(start+2800,normalized.length());
            if(end<normalized.length()){
                int cut=Math.max(normalized.lastIndexOf(". ",end), normalized.lastIndexOf("\n",end));
                if(cut>start+1200) end=cut+1;
            }
            chunks.add(normalized.substring(start,end).trim()); start=end;
        }
        StringBuilder out=new StringBuilder();
        for(String c:chunks){ if(c.isEmpty())continue; String t=Tasks.await(enViTranslator.translate(c),45,TimeUnit.SECONDS); if(out.length()>0)out.append("\n\n");out.append(t); }
        return out.toString();
    }

    private static class AiCfg { String provider, endpoint, model, key; }

    private static final String KEYSTORE_ALIAS="MarketOS_AI_KEY_V1";
    private boolean hasStoredAiKey(){try{return !getStoredAiKey().isEmpty();}catch(Exception e){return false;}}
    private String getStoredAiKey() throws Exception {
        String enc=prefs.getString("ai_key_secure","");
        if(!enc.isEmpty()) return decryptSecret(enc);
        String legacy=prefs.getString("ai_key","");
        if(!legacy.isEmpty()){prefs.edit().putString("ai_key_secure",encryptSecret(legacy)).remove("ai_key").apply();return legacy;}
        return "";
    }
    private SecretKey getOrCreateSecretKey() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(ks.containsAlias(KEYSTORE_ALIAS)) return ((KeyStore.SecretKeyEntry)ks.getEntry(KEYSTORE_ALIAS,null)).getSecretKey();
        KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(KEYSTORE_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return kg.generateKey();
    }
    private String encryptSecret(String plain) throws Exception {if(plain==null||plain.isEmpty())return"";Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,getOrCreateSecretKey());byte[] iv=c.getIV(),ct=c.doFinal(plain.getBytes(StandardCharsets.UTF_8));return Base64.encodeToString(iv,Base64.NO_WRAP)+"."+Base64.encodeToString(ct,Base64.NO_WRAP);}
    private String decryptSecret(String enc) throws Exception {String[] a=enc.split("\\.",2);if(a.length!=2)throw new IllegalStateException("Secret format invalid");byte[] iv=Base64.decode(a[0],Base64.NO_WRAP),ct=Base64.decode(a[1],Base64.NO_WRAP);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,getOrCreateSecretKey(),new GCMParameterSpec(128,iv));return new String(c.doFinal(ct),StandardCharsets.UTF_8);}

    private AiCfg getAiCfg() throws Exception {
        AiCfg c=new AiCfg(); c.provider=prefs.getString("ai_provider","GEMINI").trim().toUpperCase(Locale.US);
        c.endpoint=prefs.getString("ai_endpoint","").trim(); c.model=prefs.getString("ai_model","").trim(); c.key=getStoredAiKey().trim();
        if(c.key.isEmpty()) throw new IllegalStateException("Chưa có API key");
        if(c.model.isEmpty()) c.model=c.provider.equals("GEMINI")?"AUTO":"llama-3.1-8b-instant";
        if(c.provider.equals("AUTO")) c.provider=(c.model.equalsIgnoreCase("AUTO") || c.model.toLowerCase(Locale.US).startsWith("gemini-") || c.endpoint.isEmpty() || c.endpoint.contains("generativelanguage.googleapis.com"))?"GEMINI":"OPENAI_COMPATIBLE";
        return c;
    }

    private String callAi(AiCfg cfg,String system,String user,double temperature) throws Exception {
        if("GEMINI".equals(cfg.provider)) return callGemini(cfg,user,system,temperature);
        return callOpenAiCompatible(cfg,user,system,temperature);
    }

    private String callGemini(AiCfg cfg,String user,String system,double temperature) throws Exception {
        LinkedHashSet<String> models=new LinkedHashSet<>();
        String requested=cfg.model==null?"":cfg.model.trim();
        boolean auto=requested.isEmpty()||requested.equalsIgnoreCase("AUTO")||requested.equalsIgnoreCase("LATEST");
        if(!auto) models.add(requested.replace("models/",""));
        // Current stable Flash ladder. If Google retires one model, 404 automatically falls through.
        models.add("gemini-3.8-flash");
        models.add("gemini-3.7-flash");
        models.add("gemini-3.6-flash");
        models.add("gemini-3.5-flash");
        Exception last=null;
        for(String model:models){
            try {
                String out=callGeminiModelResilient(cfg,model,user,system,temperature);
                cfg.model=model;
                prefs.edit().putString("ai_last_model",model).apply();
                return out;
            } catch(Exception e){
                last=e;
                String m=String.valueOf(e.getMessage()).toLowerCase(Locale.US);
                // 404 = model retired/unavailable; 503/5xx = temporary capacity/server issue.
                // After bounded retries on the same model, continue down the stable model ladder.
                boolean fallback=m.contains("http 404")||m.contains("not_found")||m.contains("no longer available")||
                        m.contains("http 503")||m.contains("unavailable")||m.contains("http 500")||
                        m.contains("http 502")||m.contains("http 504");
                if(!fallback) throw e;
            }
        }
        throw new IllegalStateException("Gemini tạm thời không có model khả dụng. App đã thử các model dự phòng. "+(last==null?"":friendlyAiError(last)));
    }


    private String callGeminiModelResilient(AiCfg cfg,String model,String user,String system,double temperature) throws Exception {
        Exception last=null;
        long[] waits={900L,1800L,3600L};
        for(int attempt=0;attempt<waits.length;attempt++){
            try { return callGeminiModel(cfg,model,user,system,temperature); }
            catch(Exception e){
                last=e; String m=String.valueOf(e.getMessage()).toLowerCase(Locale.US);
                boolean retryable=m.contains("http 429")||m.contains("resource_exhausted")||m.contains("http 500")||
                        m.contains("http 502")||m.contains("http 503")||m.contains("http 504")||m.contains("unavailable")||m.contains("timeout");
                if(!retryable || attempt==waits.length-1) throw e;
                long jitter=(long)(Math.random()*350L);
                try { Thread.sleep(waits[attempt]+jitter); } catch(InterruptedException ie){Thread.currentThread().interrupt();throw e;}
            }
        }
        throw last==null?new IllegalStateException("Gemini unavailable"):last;
    }

    private String callGeminiModel(AiCfg cfg,String model,String user,String system,double temperature) throws Exception {
        String ep=cfg.endpoint;
        if(ep!=null&&!ep.isEmpty()){try{Uri u=Uri.parse(ep);if(u.getHost()==null||!u.getHost().equalsIgnoreCase("generativelanguage.googleapis.com"))ep="";}catch(Exception e){ep="";}}
        // A custom Gemini endpoint is accepted only as a base; the selected model is always injected here.
        if(ep==null||ep.isEmpty()||ep.contains("/models/")) ep="https://generativelanguage.googleapis.com/v1beta/models/"+URLEncoder.encode(model,"UTF-8")+":generateContent";
        else { if(ep.endsWith("/")) ep=ep.substring(0,ep.length()-1); ep=ep+"/v1beta/models/"+URLEncoder.encode(model,"UTF-8")+":generateContent"; }
        HttpURLConnection c=(HttpURLConnection)new URL(ep).openConnection(); c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setConnectTimeout(15000); c.setReadTimeout(90000); c.setRequestProperty("x-goog-api-key",cfg.key); c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Accept","application/json");
        JSONObject body=new JSONObject(); JSONArray contents=new JSONArray(); JSONObject content=new JSONObject(); JSONArray parts=new JSONArray();
        parts.put(new JSONObject().put("text", system+"\n\n"+user)); content.put("role","user"); content.put("parts",parts); contents.put(content); body.put("contents",contents);
        body.put("generationConfig",new JSONObject().put("temperature",temperature));
        String raw=postJson(c,body); JSONObject r=new JSONObject(raw); JSONArray cand=r.optJSONArray("candidates");
        if(cand==null||cand.length()==0) throw new IllegalStateException("Gemini không trả về nội dung");
        JSONArray outParts=cand.getJSONObject(0).getJSONObject("content").getJSONArray("parts"); StringBuilder out=new StringBuilder();
        for(int i=0;i<outParts.length();i++){String t=outParts.getJSONObject(i).optString("text","");if(!t.isEmpty()){if(out.length()>0)out.append("\n");out.append(t);}}
        if(out.length()==0) throw new IllegalStateException("Gemini trả về nội dung rỗng"); return out.toString().trim();
    }

    private String callOpenAiCompatible(AiCfg cfg,String user,String system,double temperature) throws Exception {
        String ep=cfg.endpoint; if(ep==null||ep.isEmpty()) throw new IllegalStateException("Thiếu endpoint OpenAI-compatible");
        HttpURLConnection c=(HttpURLConnection)new URL(ep).openConnection(); c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setConnectTimeout(15000); c.setReadTimeout(90000); c.setRequestProperty("Authorization","Bearer "+cfg.key); c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Accept","application/json");
        JSONObject body=new JSONObject(); body.put("model",cfg.model); body.put("temperature",temperature); JSONArray msgs=new JSONArray();
        msgs.put(new JSONObject().put("role","system").put("content",system)); msgs.put(new JSONObject().put("role","user").put("content",user)); body.put("messages",msgs);
        String raw=postJson(c,body); JSONObject r=new JSONObject(raw); return r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim();
    }

    private String postJson(HttpURLConnection c,JSONObject body) throws Exception {
        byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8); c.setFixedLengthStreamingMode(bytes.length); try(OutputStream os=c.getOutputStream()){os.write(bytes);} int code=c.getResponseCode();
        InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream(); BufferedReader br=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8)); StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null)sb.append(line);br.close();c.disconnect();
        if(code<200||code>=300)throw new IllegalStateException("AI API HTTP "+code+": "+sb.substring(0,Math.min(700,sb.length()))); return sb.toString();
    }

    private String callFaithfulTranslation(AiCfg cfg,String text) throws Exception {
        String norm=text==null?"":text.replace("\r","").trim();
        if(norm.isEmpty()) throw new IllegalArgumentException("Không có văn bản để dịch");
        List<String> chunks=splitText(norm,11000); StringBuilder out=new StringBuilder();
        String sys="Bạn là biên dịch viên tài chính-vĩ mô Anh→Việt. Dịch SÁT NGHĨA toàn bộ nguồn, giữ nguyên số liệu, ngày, tên riêng, thuật ngữ chính sách, mức độ bất định và cấu trúc heading/bullet. Không tóm tắt, không thêm nhận định, không bỏ câu. Với thuật ngữ khó, ưu tiên tiếng Việt chuẩn và có thể giữ thuật ngữ Anh trong ngoặc ở lần xuất hiện đầu.";
        for(String ch:chunks){String t=callAi(cfg,sys,ch,0.05);if(out.length()>0)out.append("\n\n");out.append(t);} return out.toString();
    }

    private List<String> splitText(String text,int max){
        List<String> out=new ArrayList<>();int start=0;
        while(start<text.length()){
            int end=Math.min(start+max,text.length());
            if(end<text.length()){
                int cut=Math.max(text.lastIndexOf("\n\n",end),text.lastIndexOf(". ",end));
                if(cut>start+max/2)end=cut+1;
            }
            out.add(text.substring(start,end).trim());start=end;
        }
        return out;
    }

    private JSONObject fetchArticle(String urlString) throws Exception {
        assertOfficialFedUrl(urlString);
        Document wrapper = connectFed(urlString);
        String htmlUrl = ""; String pdfUrl = "";
        for(Element a:wrapper.select("a[href]")){
            String href=a.absUrl("href"); if(href==null||href.isEmpty())continue; Uri u=Uri.parse(href); String h=u.getHost(); if(h==null||!h.endsWith("federalreserve.gov"))continue;
            String label=clean(a.text()).toLowerCase(Locale.US); String low=href.toLowerCase(Locale.US);
            if(pdfUrl.isEmpty() && (low.endsWith(".pdf") || label.equals("pdf") || label.contains("attachment (pdf)"))) pdfUrl=href;
            if(htmlUrl.isEmpty() && !href.equals(urlString) && (label.equals("html") || low.contains("fomcminutes") || low.contains("fomcstatement") || low.contains("monetarypolicy/fomc"))) htmlUrl=href;
        }
        Document contentDoc=wrapper; String contentUrl=urlString; String contentKind="HTML";
        if(!htmlUrl.isEmpty()) { try { contentDoc=connectFed(htmlUrl); contentUrl=htmlUrl; } catch(Exception ignored){} }
        JSONObject parsed=parseHtmlDocument(contentDoc);
        String text=parsed.optString("text","");
        boolean looksWrapper=text.length()<1200 || text.toLowerCase(Locale.US).contains("for media inquiries");
        if(!pdfUrl.isEmpty() && looksWrapper){
            try {
                String pdfText=extractPdfText(pdfUrl);
                if(pdfText.length()>Math.max(900,text.length()*2)){
                    parsed=buildTextArticle(pdfText, parsed.optString("title",clean(wrapper.title()))); contentKind="PDF"; contentUrl=pdfUrl;
                }
            } catch(Exception ignored){}
        }
        parsed.put("sourcePageUrl",urlString); parsed.put("contentUrl",contentUrl); parsed.put("htmlUrl",htmlUrl.isEmpty()?urlString:htmlUrl); parsed.put("pdfUrl",pdfUrl); parsed.put("contentKind",contentKind);
        return parsed;
    }

    private Document connectFed(String url) throws Exception { return Jsoup.connect(url).userAgent("MarketOS/9.0 Android").timeout(25000).maxBodySize(3_000_000).get(); }

    private JSONObject parseHtmlDocument(Document doc) throws Exception {
        doc=doc.clone();
        doc.select("script,style,noscript,nav,header,footer,.breadcrumb,.breadcrumbs,.share,.social,.social-links,.skip-link,.btn,.button,.watch-live,.related,.related-links").remove();
        Element root=doc.selectFirst("#content");if(root==null)root=doc.selectFirst("main");if(root==null)root=doc.body();if(root==null)throw new IllegalStateException("Không tìm thấy vùng nội dung tài liệu");
        String pageTitle=clean(doc.title()),title="",subtitle="",byline="";
        JSONArray paragraphs=new JSONArray(),blocks=new JSONArray();StringBuilder text=new StringBuilder();Elements nodes=root.select("h1,h2,h3,h4,p,li");
        for(Element el:nodes){
            String t=clean(el.text());if(t.isEmpty())continue;String low=t.toLowerCase(Locale.US);if(isFedBoilerplate(low))continue;if(t.length()<18&&!el.tagName().matches("h[1-4]"))continue;
            if(title.isEmpty()&&el.tagName().matches("h[1-4]")&&!isGenericFedHeading(low))title=t;
            else if(subtitle.isEmpty()&&el.tagName().matches("h[2-4]")&&!isGenericFedHeading(low)&&!t.equals(title))subtitle=t;
            if(byline.isEmpty()&&(low.startsWith("chair ")||low.startsWith("governor ")||low.startsWith("vice chair ")))byline=t;
            if(el.tagName().equals("li")&&el.parents().select("li").size()>0)continue;
            paragraphs.put(t);String type=el.tagName().matches("h[1-4]")?"heading":(el.tagName().equals("li")?"bullet":"paragraph");blocks.put(new JSONObject().put("type",type).put("text",t));
            if(text.length()>0)text.append("\n\n");text.append(t);if(text.length()>=90000)break;
        }
        String out=text.toString().trim();if(out.length()<120)throw new IllegalStateException("Không trích được phần thân tài liệu Fed");if(title.isEmpty())title=pageTitle.replace(" - Federal Reserve Board","").trim();
        JSONObject r=new JSONObject();r.put("title",title);r.put("subtitle",subtitle);r.put("byline",byline);r.put("text",out);r.put("paragraphs",paragraphs);r.put("blocks",blocks);return r;
    }

    private String extractPdfText(String pdfUrl) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(pdfUrl).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(45000);c.setRequestProperty("User-Agent","MarketOS/9.0 Android");int code=c.getResponseCode();if(code<200||code>=300)throw new IllegalStateException("PDF HTTP "+code);
        ByteArrayOutputStream bos=new ByteArrayOutputStream();try(InputStream is=c.getInputStream()){byte[] buf=new byte[16384];int n;while((n=is.read(buf))>0){bos.write(buf,0,n);if(bos.size()>20_000_000)throw new IllegalStateException("PDF quá lớn");}}c.disconnect();
        try(PDDocument doc=PDDocument.load(new ByteArrayInputStream(bos.toByteArray()))){PDFTextStripper stripper=new PDFTextStripper();stripper.setSortByPosition(true);String t=stripper.getText(doc);return normalizePdfText(t);}
    }

    private String normalizePdfText(String t){
        if(t==null)return"";
        return t.replace("\r","").replaceAll("(?m)^\\s*Page \\d+\\s*$","").replaceAll("[ \\t]+"," ").replaceAll("\\n{3,}","\n\n").trim();
    }

    private JSONObject buildTextArticle(String text,String fallbackTitle) throws Exception {
        JSONArray paras=new JSONArray(),blocks=new JSONArray();String[] ps=text.split("\\n\\s*\\n");String title=fallbackTitle;StringBuilder all=new StringBuilder();
        for(String raw:ps){String t=clean(raw);if(t.length()<12)continue;paras.put(t);blocks.put(new JSONObject().put("type","paragraph").put("text",t));if(all.length()>0)all.append("\n\n");all.append(t);if(all.length()>100000)break;}
        JSONObject r=new JSONObject();r.put("title",title);r.put("subtitle","");r.put("byline","");r.put("text",all.toString());r.put("paragraphs",paras);r.put("blocks",blocks);return r;
    }

    private void assertOfficialFedUrl(String url){Uri u=Uri.parse(url);String h=u.getHost();if(!"https".equalsIgnoreCase(u.getScheme())||h==null||!h.endsWith("federalreserve.gov"))throw new IllegalArgumentException("Chỉ cho phép tài liệu chính thức federalreserve.gov");}

    private boolean isGenericFedHeading(String low) {
        return low.equals("speech") || low.equals("testimony") || low.equals("press release") ||
                low.equals("federal reserve board") || low.equals("monetary policy") || low.equals("news & events");
    }

    private boolean isFedBoilerplate(String low) {
        String[] bad = {
                "skip to main content", "subscribe to rss", "subscribe to email", "please enable javascript",
                "back to home", "search button", "facebook", "linkedin", "youtube", "flickr", "contact us",
                "accessibility", "foia", "privacy program", "information quality", "open government",
                "last update:", "return to text", "board of governors of the federal reserve system"
        };
        for (String x : bad) if (low.contains(x)) return true;
        return low.equals("pdf") || low.equals("html") || low.equals("watch live") || low.equals("more information");
    }

    private JSONObject analyzeTone(String text) throws Exception {
        String t=text.toLowerCase(Locale.US); String[] hawk={"inflation remains elevated","inflation is still elevated","upside risks to inflation","restrictive","higher for longer","not appropriate to reduce","not yet confident","tight labor market","further tightening"};
        String[] dove={"disinflation","downside risks to employment","labor market has cooled","easing","reduce the target range","rate cuts","less restrictive","inflation has eased","risks are roughly in balance"}; int hs=0,ds=0;JSONArray hm=new JSONArray(),dm=new JSONArray();
        for(String k:hawk)if(t.contains(k)){hs++;hm.put(k);}for(String k:dove)if(t.contains(k)){ds++;dm.put(k);} JSONObject o=new JSONObject();o.put("hawk",hs);o.put("dove",ds);o.put("label",hs>ds?"HAWKISH":ds>hs?"DOVISH":"NEUTRAL/MIXED");o.put("hawkMatches",hm);o.put("doveMatches",dm);return o;
    }

    private JSONObject analyzeInvestmentChannels(String text) throws Exception {
        String t = text.toLowerCase(Locale.US);
        JSONObject o = new JSONObject();
        JSONArray themes = new JSONArray();
        JSONArray channels = new JSONArray();
        int evidence = 0;

        evidence += addTheme(themes, t, "Lạm phát", new String[]{"inflation","prices","price stability","pce"});
        evidence += addTheme(themes, t, "Lao động", new String[]{"employment","unemployment","labor market","payroll","wages"});
        evidence += addTheme(themes, t, "Tăng trưởng", new String[]{"growth","gdp","economic activity","consumption","investment"});
        evidence += addTheme(themes, t, "Lãi suất", new String[]{"federal funds","target range","policy rate","restrictive","easing"});
        evidence += addTheme(themes, t, "Thanh khoản/QT", new String[]{"balance sheet","quantitative tightening","securities holdings","reserves","liquidity"});
        evidence += addTheme(themes, t, "Tín dụng/Ngân hàng", new String[]{"credit","lending","banks","financial conditions","delinquency"});

        JSONObject tone = analyzeTone(text);
        String label = tone.optString("label", "NEUTRAL/MIXED");
        if (label.equals("HAWKISH")) {
            channels.put("Nếu thị trường diễn giải là hawkish: lợi suất ngắn hạn và USD có thể chịu áp lực tăng; tài sản duration cao/risk assets có thể chịu sức ép. Cần xác nhận bằng US2Y, DXY và credit spreads.");
        } else if (label.equals("DOVISH")) {
            channels.put("Nếu thị trường diễn giải là dovish: lợi suất ngắn hạn có thể giảm và điều kiện tài chính có thể nới; cần xác nhận bằng US2Y, real yield, USD và breadth của risk assets.");
        } else {
            channels.put("Thông điệp hiện mang tính pha trộn; không nên suy ra hướng giao dịch chỉ từ văn bản. Ưu tiên phản ứng của rates, USD, credit và liquidity.");
        }
        if (t.contains("balance sheet") || t.contains("liquidity") || t.contains("reserves")) {
            channels.put("Theo dõi kênh thanh khoản: WALCL, reserves, TGA và ON RRP để kiểm tra xem thông điệp có đi cùng thay đổi thanh khoản thực tế hay không.");
        }
        if (t.contains("labor market") || t.contains("employment") || t.contains("unemployment")) {
            channels.put("Theo dõi kênh lao động: unemployment, initial claims và payrolls để xác nhận độ bền của tăng trưởng và xác suất thay đổi chính sách.");
        }
        if (t.contains("inflation") || t.contains("price stability")) {
            channels.put("Theo dõi kênh lạm phát: CPI/Core PCE cùng real yield; một phát biểu không thay thế dữ liệu công bố chính thức.");
        }

        o.put("themes", themes);
        o.put("channels", channels);
        o.put("evidenceCount", evidence);
        o.put("confidence", evidence >= 10 ? "HIGH" : evidence >= 5 ? "MEDIUM" : "LOW");
        o.put("note", "Bản đồ truyền dẫn theo kịch bản, không phải khuyến nghị mua/bán.");
        return o;
    }

    private int addTheme(JSONArray themes, String text, String name, String[] keys) throws Exception {
        int count = 0;
        for (String k : keys) {
            int pos = 0;
            while ((pos = text.indexOf(k, pos)) >= 0) { count++; pos += k.length(); }
        }
        if (count > 0) themes.put(new JSONObject().put("name", name).put("count", count));
        return count;
    }

    private String callInvestmentAi(AiCfg cfg,String source) throws Exception {
        String sys="Bạn là nhà phân tích vĩ mô đầu tư theo nguồn. Chỉ được dùng tài liệu Federal Reserve được cung cấp. Trả lời tiếng Việt có cấu trúc: 1) TÓM TẮT ĐIỀU HÀNH 2) CÁC ĐIỂM CHÍNH 3) THAY ĐỔI NARRATIVE/CHÍNH SÁCH 4) TÁC ĐỘNG TIỀM NĂNG LÊN US2Y/US10Y/USD/GOLD/EQUITY/BTC 5) DỮ LIỆU CẦN XÁC NHẬN 6) RỦI RO & ĐIỀU KIỆN VÔ HIỆU 7) FACT vs INFERENCE. Không bịa số liệu, không tạo trích dẫn giả, không đưa lệnh mua/bán.";
        return callAi(cfg,sys,source.length()>50000?source.substring(0,50000):source,0.05);
    }

    private void validateComparableDocuments(String expectedCurrentTitle,JSONObject current,JSONObject previous) throws Exception {
        String ct=current.optString("text","").trim(), pt=previous.optString("text","").trim();
        if(ct.length()<500||pt.length()<500) throw new IllegalStateException("Một trong hai tài liệu quá ngắn sau khi làm sạch; không đủ an toàn để so sánh.");
        String cls=docClass(expectedCurrentTitle);
        if("OTHER".equals(cls)) throw new IllegalStateException("Không xác định được họ tài liệu hiện tại.");
        String prevTitle=previous.optString("title","");
        // Generic navigation/about pages are never accepted as a previous policy document.
        String low=prevTitle.toLowerCase(Locale.US);
        if(low.equals("federal open market committee")||low.equals("monetary policy")||low.equals("federal reserve board"))
            throw new IllegalStateException("Bản trước nhận diện thành trang giới thiệu/navigation, không phải tài liệu chính sách. App đã chặn kết quả sai.");
        if(!isComparableIdentity(expectedCurrentTitle,prevTitle,cls) && !"SPEECH".equals(cls) && !"TESTIMONY".equals(cls))
            throw new IllegalStateException("Bản trước không cùng họ tài liệu với bản hiện tại. App đã chặn so sánh sai nguồn.");
    }

    private String callComparisonAi(AiCfg cfg,JSONObject prev,JSONObject cur) throws Exception {
        String p=prev.optString("text","");String c=cur.optString("text","");if(p.length()>38000)p=p.substring(0,38000);if(c.length()>38000)c=c.substring(0,38000);
        String sys="So sánh HAI tài liệu Federal Reserve gần nhất cùng loại. Chỉ dùng nội dung cung cấp. Trả tiếng Việt với các mục: 1) TÓM TẮT KHÁC BIỆT 2) ĐIỂM MỚI/ĐƯỢC THÊM 3) ĐIỂM BỊ GIẢM/NHẤN MẠNH ÍT HƠN 4) THAY ĐỔI VỀ LẠM PHÁT 5) LAO ĐỘNG 6) TĂNG TRƯỞNG 7) LÃI SUẤT/QT/THANH KHOẢN 8) HAWKISH↔DOVISH SHIFT 9) KÊNH TÁC ĐỘNG THỊ TRƯỜNG 10) CÂU/Ý BẰNG CHỨNG. Phân biệt fact và inference, không bịa trích dẫn hoặc số liệu.";
        String user="BẢN TRƯỚC: "+prev.optString("title")+"\n"+p+"\n\n===== BẢN MỚI =====\n"+cur.optString("title")+"\n"+c;
        return callAi(cfg,sys,user,0.05);
    }

    private String findPreviousComparableUrl(String currentUrl,String title,String source) throws Exception {
        String feed="https://www.federalreserve.gov/feeds/press_monetary.xml";
        String src=source==null?"":source.toLowerCase(Locale.US);
        if(src.contains("speech"))feed="https://www.federalreserve.gov/feeds/speeches.xml";
        else if(src.contains("testimony"))feed="https://www.federalreserve.gov/feeds/testimony.xml";
        else if(src.contains("liquidity"))feed="https://www.federalreserve.gov/feeds/clp.xml";

        String cls=docClass(title);
        if("OTHER".equals(cls)) throw new IllegalStateException("Chưa xác định được họ tài liệu để so sánh an toàn. App sẽ không ghép một bài Fed khác loại.");
        List<FeedItem> items=fetchFeed(feed,source==null?"":source);
        int pos=-1;
        for(int i=0;i<items.size();i++){if(items.get(i).link.equals(currentUrl)){pos=i;break;}}
        int startAt=pos>=0?pos+1:0;
        for(int i=startAt;i<items.size();i++){
            FeedItem x=items.get(i);
            if(x.link.equals(currentUrl))continue;
            if(!docClass(x.title).equals(cls))continue;
            if(!isComparableIdentity(title,x.title,cls))continue;
            return x.link;
        }
        throw new IllegalStateException("Không tìm thấy bản trước cùng họ "+cls+" trong nguồn Fed hiện có. App đã từ chối so sánh với tài liệu khác loại để tránh kết luận sai.");
    }

    private boolean isComparableIdentity(String currentTitle,String previousTitle,String cls){
        String a=(currentTitle==null?"":currentTitle).toLowerCase(Locale.US);
        String b=(previousTitle==null?"":previousTitle).toLowerCase(Locale.US);
        if("DISCOUNT_MINUTES".equals(cls)) return a.contains("discount rate")&&b.contains("discount rate")&&a.contains("minutes")&&b.contains("minutes");
        if("FOMC_MINUTES".equals(cls)) return a.contains("minutes")&&b.contains("minutes")&&(a.contains("federal open market committee")||a.contains("fomc"))&&(b.contains("federal open market committee")||b.contains("fomc"));
        if("FOMC_STATEMENT".equals(cls)) return (a.contains("statement")||a.contains("fomc"))&&(b.contains("statement")||b.contains("fomc"));
        if("MPR".equals(cls)) return a.contains("monetary policy report")&&b.contains("monetary policy report");
        return true;
    }

    private String docClass(String title){
        String t=(title==null?"":title).toLowerCase(Locale.US);
        if(t.contains("discount rate")&&t.contains("minutes"))return"DISCOUNT_MINUTES";
        if(t.contains("minutes")&&(t.contains("federal open market committee")||t.contains("fomc")))return"FOMC_MINUTES";
        if((t.contains("statement")||t.contains("press release"))&&(t.contains("fomc")||t.contains("federal open market committee")))return"FOMC_STATEMENT";
        if(t.contains("monetary policy report"))return"MPR";
        if(t.contains("beige book"))return"BEIGE_BOOK";
        if(t.contains("financial stability report"))return"FIN_STABILITY";
        if(t.contains("speech")||t.contains("remarks")||t.contains("address"))return"SPEECH";
        if(t.contains("testimony"))return"TESTIMONY";
        return"OTHER";
    }

    private JSONObject httpJson(String urlString) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlString).openConnection();
        c.setConnectTimeout(12000); c.setReadTimeout(18000);
        c.setRequestProperty("User-Agent", "MarketOS/9.0 Android");
        c.setRequestProperty("Accept", "application/json");
        int code = c.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream(), StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder(); String line; while ((line = br.readLine()) != null) sb.append(line);
        br.close(); c.disconnect();
        if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + ": " + sb.substring(0, Math.min(240, sb.length())));
        return new JSONObject(sb.toString());
    }

    private JSONObject fetchFred(String rawId) throws Exception {
        String id=(rawId==null?"":rawId.trim().toUpperCase(Locale.US)); if(!id.matches("[A-Z0-9_.-]{1,64}")) throw new IllegalArgumentException("FRED series ID không hợp lệ");
        java.util.Calendar cal=java.util.Calendar.getInstance();cal.add(java.util.Calendar.YEAR,-2);String cosd=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(cal.getTime());
        String url="https://fred.stlouisfed.org/graph/fredgraph.csv?id="+URLEncoder.encode(id,"UTF-8")+"&cosd="+cosd;HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(18000);c.setRequestProperty("User-Agent","MarketOS/9.0 Android");int code=c.getResponseCode();if(code<200||code>=300)throw new IllegalStateException("FRED HTTP "+code);
        BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));String line=br.readLine();if(line==null||!line.toUpperCase(Locale.US).contains(id))throw new IllegalStateException("Không tìm thấy series "+id);List<String> dates=new ArrayList<>();List<Double> vals=new ArrayList<>();
        while((line=br.readLine())!=null){String[] a=line.split(",",-1);if(a.length<2)continue;String v=a[1].replace("\"","").trim();if(v.isEmpty()||".".equals(v)||"NA".equalsIgnoreCase(v))continue;try{dates.add(a[0].replace("\"","").trim());vals.add(Double.parseDouble(v));}catch(Exception ignored){}}br.close();c.disconnect();if(vals.isEmpty())throw new IllegalStateException("Series chưa có dữ liệu khả dụng");
        int n=vals.size();double value=vals.get(n-1);Double previous=n>1?vals.get(n-2):null;JSONObject p=new JSONObject();p.put("ok",true);p.put("id",id);p.put("date",dates.get(n-1));p.put("value",value);if(previous!=null){double delta=value-previous;p.put("previous",previous);p.put("delta",delta);if(previous!=0)p.put("pct",delta/Math.abs(previous)*100.0);}JSONArray hist=new JSONArray();int start=Math.max(0,n-60);for(int i=start;i<n;i++){JSONObject x=new JSONObject();x.put("date",dates.get(i));x.put("value",vals.get(i));hist.put(x);}p.put("history",hist);p.put("updatedAt",isoNow());return p;
    }

    private List<FeedItem> fetchFeed(String urlString,String source) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(urlString).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setRequestProperty("User-Agent","MarketOS/9.0 Android");c.setRequestProperty("Accept","application/rss+xml, application/xml, text/xml, */*");int code=c.getResponseCode();if(code<200||code>=300)throw new IllegalStateException("Fed feed HTTP "+code);
        XmlPullParserFactory f=XmlPullParserFactory.newInstance();f.setNamespaceAware(false);XmlPullParser p=f.newPullParser();p.setInput(new BufferedInputStream(c.getInputStream()),"UTF-8");List<FeedItem> out=new ArrayList<>();FeedItem cur=null;String tag="";int ev=p.getEventType();while(ev!=XmlPullParser.END_DOCUMENT){if(ev==XmlPullParser.START_TAG){tag=p.getName().toLowerCase(Locale.US);if("item".equals(tag))cur=new FeedItem();}else if(ev==XmlPullParser.TEXT&&cur!=null){String tx=p.getText();if(tx!=null){if("title".equals(tag))cur.title+=tx;else if("link".equals(tag))cur.link+=tx;else if("pubdate".equals(tag))cur.pubDate+=tx;else if("description".equals(tag))cur.description+=tx;}}else if(ev==XmlPullParser.END_TAG){String end=p.getName().toLowerCase(Locale.US);if("item".equals(end)&&cur!=null){cur.source=source;cur.title=clean(cur.title);cur.link=cur.link.trim();cur.pubDate=cur.pubDate.trim();cur.epoch=parseRssDate(cur.pubDate);out.add(cur);cur=null;}tag="";}ev=p.next();}c.disconnect();return out;
    }

    private void send(String fn,String json){final String q=JSONObject.quote(json);runOnUiThread(()->webView.evaluateJavascript("window."+fn+"(JSON.parse("+q+"));",null));}
    private void sendError(String fn,Exception e){try{JSONObject p=new JSONObject();p.put("ok",false);p.put("error",friendlyAiError(e));send(fn,p.toString());}catch(Exception ignored){}}
    private void sendReqError(String fn,String requestId,Exception e){try{JSONObject p=new JSONObject();p.put("ok",false);p.put("requestId",requestId);p.put("error",friendlyAiError(e));send(fn,p.toString());}catch(Exception ignored){}}
    private String friendlyAiError(Exception e){String m=e==null?"Lỗi không xác định":String.valueOf(e.getMessage());String low=m.toLowerCase(Locale.US);if(low.contains("http 401")||low.contains("invalid api key"))return "API key không hợp lệ hoặc chưa được cấp quyền.";if(low.contains("http 404")||low.contains("not_found")||low.contains("no longer available"))return "Model không khả dụng. Hãy chọn AUTO để app tự chuyển sang Gemini Flash hiện hành.";if(low.contains("http 429")||low.contains("resource_exhausted"))return "API đang vượt hạn mức/rate limit. App đã thử lại tự động; hãy thử sau nếu quota vẫn bận.";if(low.contains("http 503")||low.contains("unavailable")||low.contains("high demand"))return "Gemini đang quá tải tạm thời (503). App đã tự retry và thử model dự phòng; hãy bấm lại sau ít phút nếu tất cả model đều bận.";if(low.contains("http 500")||low.contains("http 502")||low.contains("http 504"))return "Máy chủ AI đang lỗi tạm thời. App đã retry/fallback nhưng chưa thành công.";if(low.contains("timeout"))return "API phản hồi quá chậm hoặc hết thời gian chờ.";return m.length()>420?m.substring(0,420)+"…":m;}
    private void sendFredError(String id,Exception e){try{JSONObject p=new JSONObject();p.put("ok",false);p.put("id",id);p.put("error",e.getMessage());send("onFredSeriesPayload",p.toString());}catch(Exception ignored){}}
    private static String clean(String s){if(s==null)return"";return s.replaceAll("<[^>]+>"," ").replace("&nbsp;"," ").replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").replaceAll("\\s+"," ").trim();}
    private static long parseRssDate(String value){if(value==null)return 0L;String[] ps={"EEE, dd MMM yyyy HH:mm:ss z","EEE, dd MMM yyyy HH:mm z","MM/dd/yyyy"};for(String x:ps)try{Date d=new SimpleDateFormat(x,Locale.US).parse(value.trim());if(d!=null)return d.getTime();}catch(Exception ignored){}return 0L;}
    private static String importance(FeedItem x){String t=(x.title+" "+x.source).toLowerCase(Locale.US);if(t.contains("fomc")||t.contains("minutes")||t.contains("monetary policy report")||t.contains("projection")||t.contains("federal funds")||t.contains("beige book"))return"CRITICAL";if(t.contains("chair")||t.contains("economic outlook")||t.contains("testimony")||t.contains("balance sheet")||t.contains("liquidity"))return"HIGH";return"NORMAL";}
    private static String isoNow(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",Locale.US);f.setTimeZone(TimeZone.getDefault());return f.format(new Date());}
    @Override protected void onDestroy(){executor.shutdownNow();if(enViTranslator!=null)enViTranslator.close();if(webView!=null)webView.destroy();super.onDestroy();}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
