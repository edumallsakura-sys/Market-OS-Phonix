# Market OS v13 — Live Market + Primary Sources + Grounded Research

## Nâng cấp chính
- EFFR đổi sang series chính xác `EFFR` của New York Fed/FRED, gắn nhãn official daily thay vì giả gọi realtime.
- Gold: best-effort COMEX Gold futures `GC=F` near-live/delayed từ Yahoo Finance; tự fallback LBMA Gold AM/FRED daily khi nguồn market không có.
- Mỗi card FRED/Data Lab có hyperlink nguồn để fact-check.
- Khôi phục/ mở rộng Data Lab: EFFR, IORB, SOFR, RRP, repo, monetary base, M1/M2, bank credit, yield curve, credit, inflation, labor, equities, gold, USD.
- Crypto Trading Lab: Binance Spot candles 1H/4H/1W/1M, candlestick + SMA20 + RSI14 + MACD + ATR14 + realized volatility + volume trend; watchlist CoinGecko thêm/bớt.
- AI Grounded Market Research: khi dùng Gemini, gọi Google Search grounding và trả danh sách nguồn; OpenAI-compatible vẫn hỗ trợ Groq/OpenRouter/Ollama/vLLM endpoint riêng nhưng không tự có web-grounding.
- Không hard-code số demo; nguồn lỗi => fallback có nhãn hoặc UNKNOWN.

## Lưu ý về realtime
Dữ liệu vĩ mô chính thức không phải tick realtime: EFFR được NY Fed công bố cho ngày làm việc trước; FRED có cadence Daily/Weekly/Monthly. App hiển thị freshness và nguồn. Crypto market data gần thời gian thực; Gold GC=F là quote delayed/near-live tùy feed.
