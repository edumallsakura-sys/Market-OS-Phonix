# Market OS v18 — Production Data Integrity

Focus: make data freshness auditable, not decorative.

## FRED production-grade changes
- Batch-aware CORE refresh. Every core series is tied to one batch ID.
- Macro refresh timestamp is updated only after the entire CORE batch finishes with zero request failures.
- PARTIAL batch remains visibly partial; failed IDs are shown and refresh remains due.
- FRESH/STALE now uses frequency-specific policies with per-series overrides.
- Engine coverage counts only FRESH official observations.
- TGA liquidity input uses WDTGAL (Wednesday Level); WTREGEN remains visible as Weekly Average for comparison.
- Data Lab shows observation date, age, fetch time and source link for each series.
- No-cache / no-store and request dedup remain enabled.

## Existing features retained
- Fed RSS + official HTML fallback and Source Audit
- live/near-live market data with source labels
- Coin Selection Lab with evidence gates
- Gemini grounded research
- Resource Safety Contract, System Health, deadline refresh
- Universal FINAL GitHub workflow unchanged
