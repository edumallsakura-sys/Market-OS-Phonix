# Market OS Phoenix v2.4 — Policy/FRED + Document Reader rebuild

## Mục tiêu
Sửa triệt để phần Chính sách/Federal Reserve mà không thay đổi logic Crypto/Coin Lab đang ổn.

## 1. Policy source engine
- Khôi phục parser `Recent Postings` theo anchor-local date của v2.2 (ổn định hơn parser row-wide của v2.3).
- Recent Postings vẫn là master index cho tài liệu Board.
- Giữ RSS chính thức: Monetary, Press, Speeches, Testimony, Board Meetings, FEDS Notes.
- Data-release channels: Z.1, H.4.1, H.8, H.15, Policy Rates, H.6, G.17, G.19, SLOOS.
- Bổ sung SCOOS, charge-offs/delinquencies, commercial paper, G.20 Finance Companies.
- Data feeds ưu tiên HTML announcement chính thức rồi mới fallback RSS, vì timestamp announcement có thể mới hơn RSS.
- Beige Book có index riêng, không phụ thuộc generic news feed.
- 20 data/news channels chạy concurrent tối đa 4 workers, timeout hữu hạn; không polling, không infinite retry.

## 2. FRED API thật
- Thêm FRED API key trong Settings, lưu cục bộ trên máy.
- Không hard-code/shared key vào APK.
- Có nút Test API.
- Dùng `fred/releases/dates` cho release metadata.
- Dùng `fred/series/updates` cho `last_updated` của đúng các series MarketOS theo dõi.
- Không quét toàn bộ FRED vô hạn. FRED metadata là lớp bổ sung; Federal Reserve Board vẫn là canonical source cho document.
- Macro observation vẫn hoạt động không key qua FRED graph CSV hiện có.

## 3. Article reader
- Modal chuyển sang full-screen responsive `100dvh`, tránh màn hình lửng/cắt nội dung.
- Tiêu đề tự dịch EN→VI trên máy.
- Tạo `Tóm tắt từ chính nguồn` deterministic, sau đó tự dịch tóm tắt sang tiếng Việt.
- `Investor Source Extract` vẫn source-only, không gọi AI web để tự sinh fact.
- Bỏ FOMC blurb cố định cho mọi document; context thay đổi theo loại tài liệu.
- Có `Dịch toàn bài trên máy` và `Dịch đoạn bôi đen`.

## 4. PDF on-app
- Thêm `pdfbox-android` để tải PDF chính thức và trích text layer ngay trong app.
- Giới hạn 15 MB, tối đa 80 trang/lần và 100k ký tự để tránh RAM runaway.
- Có `Đọc PDF` trong app, `Dịch PDF trên máy`, và dịch đoạn bôi đen.
- Nếu PDF scan không có text layer, app báo rõ thay vì giả OCR hoặc trả text rác.

## 5. Safety
- Không thêm background polling.
- Feed refresh chỉ khi người dùng mở/refresh Policy.
- Parallel source workers bounded = 4 và shutdown sau batch.
- FRED 429/timeout dừng và báo lỗi, không retry storm.
- Cache vẫn phân biệt cache/live.
