MARKET OS PHOENIX v2.4 — GITHUB ONECLICK

1) Upload TOÀN BỘ nội dung của ZIP này vào root GitHub repo.
2) Vào Actions -> Build MarketOS Phoenix v2.4 APK -> Run workflow.
3) Sau khi build xong, tải artifact MarketOS-Phoenix-v2.4-debug-APK.

v2.4 tập trung sửa Policy/Federal Reserve + FRED API + reader HTML/PDF + dịch EN→VI trên máy.
FRED API key KHÔNG được hard-code. Vào app -> ⚙ -> FRED API để nhập key riêng nếu muốn release/series freshness metadata.
Không có key: Macro + Board official feeds vẫn hoạt động.
