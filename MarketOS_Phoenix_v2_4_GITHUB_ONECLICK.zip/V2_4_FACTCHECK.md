# v2.4 Fact-check & engineering notes

## FRED API
Official FRED API requires a registered API key for web-service calls. MarketOS therefore does not ship a shared key. The user can add their own 32-character lowercase alphanumeric key in Settings. v2.4 uses:
- `fred/releases/dates` — release-date metadata.
- `fred/series/updates` — series ordered by FRED `last_updated`, limited by FRED to recently updated series.

FRED is not the canonical source for Federal Reserve Board documents. Policy documents/news still come from federalreserve.gov; FRED is used for data/release metadata and macro observations.

## Federal Reserve Board feeds
The Board publishes official RSS/data announcement feeds for press releases, speeches/testimony, Board meetings, research and many statistical releases. v2.4 uses a bounded investor-relevant subset rather than the giant All Data feed.

## Why v2.3 could show an older 'latest' item
v2.3 introduced a row-wide Recent Postings parser that could bind one date to multiple links inside a broad Bootstrap container and mark links as already seen before the local-anchor pass. v2.4 restores anchor-first/local-date parsing from the previously better-working path and keeps source dedupe.

## PDF
PDF text extraction is on-device and only reads a real PDF text layer. Scanned/image-only PDFs remain explicitly unsupported in this build; no fake OCR is performed.

## Translation
English→Vietnamese translation is Google ML Kit on-device after the language model is available. It is not an external LLM/API request and therefore does not consume Gemini/OpenAI quota.

## WAIT gates
`WAIT` is not always a network error. In MarketOS, a gate intentionally remains WAIT when exact project-specific evidence has not been verified (e.g. full unlock schedule, security/admin risk, catalyst, token value capture). The app must not convert missing evidence to PASS. Selecting a coin and running deep view fills exchange/price/order-book/candles/MC-FDV/economics where a verified mapping exists; some project-specific gates still require an exact source before Final can unlock.
