# ALPHAFLOW OS v1.4.2 — UX QA + Evidence Integrity

Version: 1.4.2  
Android versionCode: 15

## What changed

### Macro Cockpit
- Headline CPI now uses CPIAUCNS (official CPI-U headline basis) with FRED year-over-year transformation; CPIAUCSL remains in the library as the seasonally-adjusted analytical index.
- Core CPI headline basis added as CPILFENS; CPILFESL remains analytical.
- Regime `confidence` renamed to `rule fit`; UI explicitly states it is a heuristic rule fit, not a statistical probability.
- Macro screen split into Overview / Calendar / Library to prevent one extremely long page.
- Two-column cards use actual screen width instead of percentage + gap sizing.
- Observation date remains visible separately from cache refresh time.

### Policy / News Desk
- Desk split into Brief / Feed / Sources.
- Feed initially renders a bounded 30 items and expands by 30 up to the existing hard cap.
- Undated feed entries are no longer treated as “recent” in Morning Brief.
- Official-source provenance remains distinct from secondary headline metadata.

### AI Copilot
- Android keyboard uses resize + KeyboardAvoidingView height behavior.
- Bottom app navigation hides while the Android keyboard is visible.
- Composer stays attached to the visible chat area; large evidence/header content collapses while typing.
- Macro regime evidence is labelled heuristic rule-fit instead of confidence.
- Macro evidence includes observation dates and stale state.

### Chart
- MA / RSI / MACD warm up on the full downloaded candle window before the visible 120-candle slice.
- Order-book imbalance is explicitly labelled as a REST snapshot, not continuous realtime or an independent predictive signal.
- Fetch timestamp is shown.

### Portfolio
- Transaction editor is collapsed by default and opened on demand.
- Asset/history deletion and transaction deletion require confirmation.
- Backup/Restore is moved out of the default Book view to reduce page length.

### Settings
- API setup and local alerts remain immediately available.
- Source health / cache / runtime / disclaimer are grouped under an expandable advanced section.

### Crypto
- Global CoinGecko cache shortened from 30 minutes to 10 minutes.
- UI shows cache/update context more clearly.
- Existing Research Score remains explicitly a heuristic research shortlist, not a buy/sell signal.

## Android safety contract
- No background service.
- No infinite polling loop.
- No 24/7 WebSocket.
- No foreground-service permission.
- No accessibility/location/storage-wide permission.
- Network requests remain bounded with timeout/cancel/retry policies.
- Existing cache caps and local-first behavior remain intact.

## Known professional gaps (not hidden)
- Crypto watchlist still renders rows inside a ScrollView; a future virtualization pass is desirable for 200+ visible coins.
- Policy PDF viewing keeps the official PDF intact; translated text is a parallel reading layer, not a layout-preserving translated PDF.
- Portfolio does not claim TWR/IRR because deposits/withdrawals/cash-flow ledger are not yet complete.
- Regime and Crypto Research Score are heuristic research aids, not probabilities or trade recommendations.
- Chart is a strong research snapshot but not yet TradingView-class (no full crosshair/zoom/drawing workspace).
