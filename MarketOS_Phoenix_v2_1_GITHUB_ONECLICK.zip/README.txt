MARKET OS PHOENIX v2.1 — ONECLICK

Focused patch over Phoenix v2.

1) Giải nén file ONECLICK này.
2) Upload TOÀN BỘ nội dung vào root repo GitHub.
3) Actions -> Build MarketOS Phoenix v2.1 APK -> Run workflow.
4) Workflow chạy static audit + JavaScript syntax check trước khi assembleDebug.
5) Tải artifact: MarketOS-Phoenix-v2.1-debug-APK.

Project Android nằm trong /projects/MarketOS_Phoenix_v2_1_ANDROID_SOURCE.zip
Audit hồi quy: /V2_1_FACTCHECK.md
