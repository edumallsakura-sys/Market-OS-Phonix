# Market OS Phoenix v2.1 — Code Fact-check / Regression Audit

## Scope
This is a **focused patch** over the exact Phoenix v2 source supplied by the user. It is not a rewrite.

- Baseline files: 29
- New files: 31
- Unchanged baseline files: 23
- Modified baseline files: 6
- Added files: 2
- Removed files: 0
- MainActivity text similarity: 94.72%
- index.html text similarity: 97.56%
- App icon byte-identical: True

### Modified baseline files
- `static_audit.py`
- `README.md`
- `app/build.gradle`
- `.github/workflows/build-apk.yml`
- `app/src/main/assets/index.html`
- `app/src/main/java/com/marketos/phoenix/MainActivity.java`

### Added files
- `V2_1_CHANGELOG.md`
- `V2_1_FACTCHECK.md`

### Removed files
- None

## Finding 1 — Gold card was a real source bug
Phoenix v2 used FRED series `GOLDAMGBD228NLBM`. FRED's own blog states that the gold fixing series used in its historical gold posts **have been removed from the FRED database**. Therefore a permanent `MISSING` card is expected; retrying the same FRED ID cannot fix it.

Fix in v2.1:
- Remove the dead FRED gold series from `METRICS`.
- Add `GOLD_USD` from Yahoo Finance public chart endpoint, symbol `GC=F`.
- Label it explicitly **COMEX Gold Futures**, `USD/oz`, delayed market proxy.
- Do **not** rename it LBMA fixing or spot gold.
- If Yahoo is unavailable, keep `MISSING`; never synthesize a price.

Fact-check URLs:
- FRED blog removal note: https://fredblog.stlouisfed.org/2018/12/gold-malleable-ductile-and-volatile/
- Yahoo GC=F quote: https://finance.yahoo.com/quote/GC%3DF/
- Yahoo chart endpoint used by code: https://query1.finance.yahoo.com/v8/finance/chart/GC%3DF?range=1mo&interval=1d&includePrePost=false

## Finding 2 — Quality / Margin was not a failed API
In v2 the fifth lens was hard-coded as `null`, so the dash was intentional, not a network failure. The lens depends on coin-specific MC/FDV, protocol economics and unlock evidence.

Fix in v2.1:
- No selected coin → `CHỌN COIN`.
- MC/FDV unavailable → `LOCKED`.
- MC/FDV present but unlock/economics incomplete → `PARTIAL`.
- No fabricated /100 score is introduced.

## Finding 3 — Watchlist removal
Added an `×` control per row. It:
- stops row click propagation;
- removes the symbol from `localStorage`;
- updates the list immediately;
- clears Deep View/decision state when the removed symbol is the selected coin;
- preserves an empty watchlist.

Native `fetchWatchlist()` was changed so an empty array no longer silently re-adds BTC/ETH.

## Regression guard
Unchanged in logic:
- Fed RSS + Recent Postings
- Fed document identity gate and body extraction
- local EN→VI translation
- FRED macro scoring/regime calculations
- Binance scan
- selected-coin order book ±0.5/1/2%
- candles 1H/4H/1D/1W/1M
- Binance Futures context
- CoinGecko MC/FDV
- DefiLlama economics
- Evidence Ledger / Decision gates
- bounded executor / cache / no background polling

Only the UA version string changed inside Fed/article network calls.

## Static verification
- `static_audit.py`: 40/40 PASS
- JavaScript `node --check`: PASS
- HTML IDs: 57/57 unique
- Java brace balance: PASS
- `while(true)`: absent

Runtime APK compile still belongs to GitHub Actions because the local environment does not contain a full Android SDK toolchain. The ONECLICK workflow runs static audit + JS syntax check before `assembleDebug`.
