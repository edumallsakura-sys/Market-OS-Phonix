MarketOS GitHub ONE-CLICK V35.1 — COMPILE HOTFIX

SỬA LỖI BUILD V35:
- Xóa duplicate Java method putFinite(JSONObject, String, double) gây :app:compileDebugJavaWithJavac FAILED.
- Không thay đổi Investment Engine / UI / scoring / track-record logic.
- App version 35.0.1 / versionCode 40; engineVersion vẫn 35.0.0 để giữ semantics/hash của V35.
- V35 audit bổ sung guard phát hiện duplicate Java method signature trước bước Gradle compile.

CÁCH DÙNG:
1. Upload TOÀN BỘ nội dung ZIP này vào root repo GitHub.
2. Commit/push lên main/master.
3. Actions -> Universal Android ZIP Builder V35.1 -> Run workflow.
4. Khi build xong tải artifact Android-APKs.

Workflow: safe extract -> detect project -> 193-check V35.1 audit -> JS/XML/HTML audit -> Android SDK -> Gradle 8.9 -> assembleDebug -> APK artifact.
