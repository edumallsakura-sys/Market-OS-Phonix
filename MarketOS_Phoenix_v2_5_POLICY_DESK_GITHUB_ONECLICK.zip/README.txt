Market OS Phoenix v2.5 — POLICY INTELLIGENCE DESK

BUILD:
1. Upload/extract this ONECLICK package into a GitHub repository.
2. Open Actions -> Build MarketOS Phoenix v2.5 APK -> Run workflow.
3. Download artifact: MarketOS-Phoenix-v2.5-POLICY-DESK-debug-APK.

The workflow auto-detects projects/MarketOS_Phoenix_v2_5_POLICY_DESK_ANDROID_SOURCE.zip,
runs static audit + JavaScript syntax audit, then builds app:assembleDebug.

v2.5 focus:
- Original-layout PDF viewer inside app (Android PdfRenderer).
- Dedicated FOMC Recent Documents + Recent Postings + official Fed RSS/data feeds.
- Optional FRED API metadata; official FRED email-alert and calendar links.
- Bilingual EN/VI Investor Source Extract.
- Only source/fact-check links intentionally leave the app.
