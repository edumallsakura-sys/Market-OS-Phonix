# Market OS Phoenix v2.5 — Professional Policy Intelligence Desk

## Scope
This release upgrades the **Policy / Federal Reserve** workflow only. Macro, Crypto, Coin Selection and Decision logic are intentionally left functionally unchanged.

## 1. Source-faithful PDF inside the app
- Added `PdfViewerActivity` using Android `PdfRenderer`.
- The viewer downloads the official PDF to bounded app cache and rasterises the **original PDF page**, preserving tables, numbers, spacing and page layout for visual verification.
- Only one page bitmap is held at a time; cache keeps at most four recent PDFs and expires old files.
- The old PDF text extraction remains available, but is explicitly labelled as a **text-analysis layer**, not the PDF representation.
- External navigation is reserved for `Nguồn PDF ↗` / source fact-check.

## 2. Faster, broader official Fed policy feed
Policy refresh now combines:
- Federal Reserve Recent Postings.
- Dedicated `monetarypolicy.htm` FOMC Recent Documents discovery.
- Beige Book official index.
- Board official RSS: monetary policy, press releases, speeches, testimony, Board meetings, FEDS Notes.
- Official data-release feeds: Z.1, H.4.1, H.8, H.15, Policy Rates, H.6, G.17, G.19, SLOOS, SCOOS, charge-offs/delinquencies, commercial paper and G.20.
- Optional user-owned FRED API key for release-date metadata and `series/updates` freshness.

No social-media feed is used as a source of truth.

## 3. Professional Policy Desk UI
- Policy KPI strip: new items in 24h, source health, latest FOMC item, latest data item.
- Separate FOMC, high-impact, liquidity/data, speech and research filters.
- Distinct pulse cards avoid showing the same release as every headline.
- Items published within 24 hours receive a `MỚI 24H` marker.
- Policy tab automatically refreshes when its live data is older than five minutes, with a bounded request guard; there is no background polling loop.

## 4. FRED/Fed notification discovery
The Policy Desk exposes official links for:
- Federal Reserve RSS directory.
- FRED per-series email notifications.
- FRED release calendar.

These are notification/setup links only. The app still retrieves and reads official documents directly.

## 5. Bilingual Investor Source Extract
- English excerpts remain exact source-only text selected deterministically from the verified official document.
- A Vietnamese translation is generated locally with ML Kit and displayed beside the English extract.
- Translation never replaces or modifies the original English evidence.

## 6. In-app workflow
`Official feed -> document identity gate -> original HTML -> bilingual source extract -> original-layout PDF -> source link for external fact-check`

Only source/fact-check links intentionally leave the app.

## Version
- Android versionName: `2.5.0`
- versionCode: `7`
