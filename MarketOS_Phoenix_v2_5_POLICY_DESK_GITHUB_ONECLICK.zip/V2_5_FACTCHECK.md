# v2.5 Policy Desk — fact-check / integrity notes

## Federal Reserve RSS
The Federal Reserve Board publishes official RSS feeds for press releases, speeches/testimony, research and statistical-data announcements. MarketOS consumes a bounded investor-relevant subset and retains a source-health report. It intentionally does not scrape social-media posts as a policy source.

## FRED notifications
FRED supports email notifications for individual series through a free FRED account. Phoenix v2.5 links to the official notification instructions but does not request mailbox access and does not embed a shared FRED credential.

## FRED API
FRED web-service endpoints require a user API key. The optional key is stored locally in app preferences and is used only for release-date / series-update metadata. The canonical Board document remains preferred when a Board mapping exists.

## PDF integrity
The previous PDF experience extracted text with PDFBox. That is useful for search and translation but destroys visual form. v2.5 separates the two concepts:
1. **PDF GỐC**: Android PdfRenderer renders the original PDF page inside the app.
2. **Text layer**: PDFBox extraction for local translation/search only.

This separation prevents extracted text from being presented as though it were the original table/layout.

## Resource safety
- PDF download hard cap: 28 MB.
- PDF cache: maximum four recent files; old files expire after 48 hours.
- One PDF render worker.
- One page bitmap at a time.
- Main network executor remains bounded.
- No infinite polling/reconnect loop was added.
- Policy auto-refresh is event-driven on tab entry and guarded by age/request windows.
