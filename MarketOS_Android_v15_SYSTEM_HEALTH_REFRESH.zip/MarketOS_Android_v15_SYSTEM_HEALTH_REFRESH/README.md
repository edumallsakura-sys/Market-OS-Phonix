# Market OS v15 — System Health + Deadline Refresh

- System Health: lifecycle, worker pool, bounded queue, in-flight requests, cache, disk free.
- Nút refresh deadline trên header.
- Crypto: 30 giây, chỉ Cockpit/Crypto.
- Market snapshot: 60 giây, chỉ Cockpit.
- Macro/FRED: 15 phút, chỉ tab liên quan.
- Chỉ đánh dấu refresh thành công khi callback dữ liệu trả về OK.
- Background: scheduler dừng; foreground mới resume.
- Dọn cache thủ công và xóa cache cũ quá 7 ngày.
- Universal FINAL GitHub Flow giữ nguyên.
