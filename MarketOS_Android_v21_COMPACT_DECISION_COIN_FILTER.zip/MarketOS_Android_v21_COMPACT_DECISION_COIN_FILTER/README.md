# Market OS v21 — Compact Decision UI + Reliable Coin Filter

## Major fixes
- Coin Selection Lab no longer downloads Binance `/exchangeInfo` or all-market ticker payloads.
- Stage A uses a bounded liquid research universe and verifies each pair against Binance public Spot ticker data.
- Requests are batched by 10 symbols; a failed batch is salvaged one symbol at a time, with invalid/delisted symbols skipped.
- No automatic scan retry loop.

## UI
- Removed duplicate top navigation tabs.
- Compact sticky header: Data Health, Refresh, Settings.
- Full source/freshness status moved into a tap-to-open Data Health drawer.
- Bottom navigation is the primary navigation.

## Cockpit research
- AI output is rendered into structured sections instead of a raw text wall.
- AI failure falls back to a structured local Decision Engine brief.
- Research prompt is constrained to concise decision-first headings.

## Coin DD
- Adds local liquidity/dilution risk flags.
- Final investment score remains locked until unlock/product/security/catalyst evidence is verified.

Version 21.0.0 / versionCode 24.
Universal FINAL GitHub workflow unchanged.
