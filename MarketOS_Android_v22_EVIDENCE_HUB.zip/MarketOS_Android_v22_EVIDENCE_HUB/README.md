# Market OS v22 — Evidence Hub

New:
- Project Identity Resolver using CoinGecko ID + platform/contract mapping.
- Protocol Economics using DefiLlama TVL/fees/revenue/holder revenue for mapped protocols.
- GoPlus Security/Holders integration, with optional encrypted Bearer token.
- Partial on-chain unlock windows from GoPlus locked_detail, explicitly labeled partial.
- Evidence Coverage + component scores; no fake final /100.
- Grounded Research expanded to full unlock and Catalyst Calendar.

Resource-safety:
- no new background polling
- evidence calls only for the selected coin
- bounded network responses remain enabled
- UNKNOWN remains UNKNOWN

Version 22.0.0 / versionCode 25.
Universal FINAL GitHub workflow unchanged.
