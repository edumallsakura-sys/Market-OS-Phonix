# ALPHAFLOW OS v1.4.1 — DATA INTEGRITY + IN-APP READER

## Purpose
Targeted correctness/safety release. It preserves the existing Macro, Crypto, Chart, Desk, AI, Portfolio and Settings flows from v1.4.0 while fixing verified macro-data interpretation issues and adding bounded in-app news/PDF reading + user-triggered translation.

## Verified macro corrections
- Morning Fed card now uses `DFF` (daily effective federal funds rate), not `FEDFUNDS` monthly average.
- A separate Fed Policy panel shows `DFEDTARL` + `DFEDTARU` target range and their actual observation date.
- `FEDFUNDS` remains available in Indicator Library, explicitly as monthly average.
- YoY indicators no longer use positional `points[i-12]`/`i-4` math. They request FRED's official `units=pc1` transformation and use a new `fred.v3.*` cache namespace.
- Macro cards display observation date separately from cache-refresh time.
- Regime detection uses `A191RL1Q225SBEA` real-GDP growth rate (SAAR), not the GDP level, and tightening/easing uses the Fed target upper bound trend.
- Detail-view horizon changes are frequency-aware: monthly/quarterly data no longer pretend to have a 1D/1W observation.

## Desk Reader
- Added `react-native-webview` 13.16.1 (Expo-compatible) for on-demand in-app reading.
- HTML/news pages render directly from the source/publisher. Secondary article bodies are still NOT scraped or copied into local cache.
- PDF pages can be viewed inside the app through a document viewer while the official source URL is retained and can always be opened externally.
- The PDF viewer is display-only; ALPHAFLOW does not rewrite the original file.

## Translation
- Official HTML text: Vietnamese translation in bounded ~6k-character chunks, only when the user presses the button.
- PDF: optional Gemini native-PDF translation, user-triggered only, max 4 MB and max 3 pages per request, finite timeout, PDF bytes are not persisted.
- HTML translation cache keeps at most 12 documents; PDF translation cache keeps at most 18 page-range results.
- AI translation is explicitly not promoted to primary evidence; the official original remains the verification source.

## Android safety contract
- No background service added.
- No infinite polling or `setInterval`.
- No always-on WebSocket.
- No background OCR.
- Existing bounded caches, AbortController timeouts, finite retries and local-first storage remain intact.
- Android permissions remain only `POST_NOTIFICATIONS` beyond normal network access.

## Version
- App version: 1.4.1
- Android versionCode: 14
