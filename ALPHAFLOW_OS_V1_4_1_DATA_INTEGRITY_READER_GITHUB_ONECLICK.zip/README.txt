ALPHAFLOW OS v1.4.1 — DATA INTEGRITY + IN-APP READER
Upload/extract all contents to the GitHub repository root. Required:
  .github/workflows/build-apk.yml
  projects/ALPHAFLOW_OS_SOURCE.zip
Run workflow: Build ALPHAFLOW OS v1.4.1 APK - DATA INTEGRITY + IN-APP READER
Artifact: ALPHAFLOW-OS-v1.4.1-STANDALONE-APK
