# Market OS v12 — Investment Framework

## Mục tiêu
Không tối ưu cho việc “đọc nhiều tin”. Tối ưu cho chuỗi quyết định:

Source → Data Quality → Regime → Cross-Asset Confirmation → Scenario → Fragility → Invalidation → Position sizing discipline.

## Các lăng kính
- Soros / Reflexivity: tìm divergence giữa narrative/regime và price action; divergence là câu hỏi cần điều tra, không phải tín hiệu tự động.
- Taleb / Antifragility: khi fragility tăng, ưu tiên survival, optionality, giới hạn leverage và downside mở.
- Graham / Margin of Safety: không có intrinsic-value/fundamental data thì không gắn nhãn “rẻ”. Với crypto không cash flow, margin of safety phải đến từ sizing, entry, liquidity và downside budget.
- Cycle / liquidity discipline: liquidity, credit, real yield và USD được dùng như các kênh xác nhận, không phải chân lý đơn biến.

## Nguồn v12
- Fed/FRED: policy, rates, balance sheet, reserves, TGA, RRP, credit stress, labor, inflation, US fiscal series.
- ECB/BoJ qua FRED series: policy/liquidity proxy.
- CoinGecko: crypto watchlist và price history.

## Giới hạn
- Chưa có PBoC/China fiscal primary-source live parser đủ tin cậy.
- Không có full fundamental/valuation engine cho equities.
- Không thay thế terminal institutional hoặc execution/risk infrastructure.
