# MarketOS Android Performance + Safety Contract (v14)

## Hard limits
- No infinite polling/retry/thread/queue/cache/history.
- Native worker pool: 2 core / 4 max threads, queue capped at 24.
- PDF worker queue capped at 4.
- Crypto watchlist capped at 20 assets; candle request capped at 240 bars.
- FRED UI history capped at 60 observations.
- Fed feed capped at 140 items.
- JSON network body capped at 2 MB.
- In-app PDF download capped at 30 MB and requires >=80 MB free cache space.

## Lifecycle
- Background: JavaScript refresh schedulers stop and Main WebView pauses.
- Foreground: schedulers restart.
- Crypto refresh runs only for Cockpit/Crypto page.
- Macro/FRED refresh runs only for Cockpit/Macro/Policy/Data pages; Fed feed only Cockpit/Policy.
- Executors, ML Kit translator and WebViews are closed in onDestroy.

## Memory/storage
- Previous PDF bitmap is recycled before replacing it.
- Temporary PDF is deleted on viewer destroy.
- onTrimMemory clears non-critical WebView cache/in-flight bookkeeping.

## Network
- Existing connect/read timeouts remain mandatory.
- AI retry remains finite with backoff.
- Duplicate FRED requests for the same series are coalesced while in flight.
- When the bounded worker queue is full, new non-critical work is rejected rather than growing RAM.

## Production security
- WebView debugging disabled.
- Universal/file cross-origin access disabled for the local app WebView.
- Android backup disabled because encrypted API configuration should not be copied/restored across devices.
- Release enables R8/resource shrinking; JS bridge members are explicitly kept.

## Pre-release checks
Build must still be validated on GitHub/real device for: ANR, process death/reopen, offline, background/foreground, low-memory, rotation, long-run RAM trend, network storm, API 429/5xx, and PDF cleanup.
