# Event Driven Sync Contract
1. No source failure may cause immediate periodic retry.
2. Each source has exponential backoff capped at 30 minutes.
3. Scheduler only checks deadlines every 30 seconds.
4. Network refresh occurs only when source is due and cooldown allows it.
5. Manual refresh may force a retry.
6. Macro refresh is successful only after the entire CORE batch returns without transport/parser failures.
7. FRED changes are displayed as deltas, not fake news.
8. Scheduled releases and observation freshness are separate from headline news.
