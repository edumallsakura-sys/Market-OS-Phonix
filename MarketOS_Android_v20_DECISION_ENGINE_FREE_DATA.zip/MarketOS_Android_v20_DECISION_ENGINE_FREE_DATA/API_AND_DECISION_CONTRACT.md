# API & Decision Contract

1. No shared/private API key is embedded in APK.
2. No reputable production LLM API is assumed to be unlimited-free.
3. AI quota failure must never disable the core investment engine.
4. HTTP 429 is not auto-retried.
5. Market/Fed/FRED/crypto data are primary inputs; AI is a synthesis layer.
6. Stablecoin supply from DefiLlama is used as a crypto-liquidity input, not as a buy signal.
7. Risk budget is a relative multiplier, not a personalized allocation instruction.
8. Every high-conviction action requires adequate data coverage and cross-asset confirmation.
