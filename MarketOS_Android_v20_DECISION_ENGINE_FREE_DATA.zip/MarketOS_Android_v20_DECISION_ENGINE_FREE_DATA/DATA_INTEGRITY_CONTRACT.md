# Data Integrity Contract

1. A successful request is not the same as fresh data.
2. A fresh observation is judged against the series publication frequency.
3. One successful series must never mark an entire macro batch as refreshed.
4. Full-batch timestamp changes only after all CORE requests return without transport/parser failure.
5. STALE data can remain visible for context but does not count toward fresh engine coverage.
6. MISSING/FAILED remains explicit. Never synthesize a value.
7. Every primary data card must expose source, observation date and fetch time.
8. TGA Wednesday Level and Weekly Average are distinct and must not be silently substituted.
9. Official macro series are not labeled tick-realtime when their release cadence is daily/weekly/monthly.
10. Any investment conclusion must degrade confidence when fresh data coverage is inadequate.
