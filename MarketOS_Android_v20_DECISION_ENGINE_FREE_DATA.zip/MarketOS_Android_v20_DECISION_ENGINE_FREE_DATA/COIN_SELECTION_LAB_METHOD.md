# Coin Selection Lab Method

Stage A — public market pre-screen:
- Binance Spot TRADING + USDT pair
- excludes stable bases and leveraged-token suffixes
- liquidity by quote volume
- timing sanity penalty when 24h move is already extreme
- pre-score max 30 only to prioritize research

Stage B — selected coin:
- Binance 24h market data
- order-book spread/depth
- CoinGecko MC/FDV/supply mapping
- funding/OI as derivatives crowding context

Stage C — grounded research:
- unlock 7/30/60/90D
- product/usage/TVL/fees/revenue/value capture
- security/audit/admin/holder concentration
- catalyst 7/30/90D
- sector/narrative and market regime
- invalidation and risk plan

Final investment score is forbidden unless evidence coverage is sufficient.
