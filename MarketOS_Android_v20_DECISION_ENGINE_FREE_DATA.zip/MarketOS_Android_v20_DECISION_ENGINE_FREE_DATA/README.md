# Market OS v20 — Decision Engine + Free Data

Core principle:
- AI is optional. Investment synthesis must remain useful with zero AI quota.
- No automatic retry on HTTP 429.
- Reliable/free data sources are used where practical:
  - Federal Reserve official RSS/HTML
  - FRED public CSV
  - Binance public Spot market data
  - CoinGecko public/demo market data
  - DefiLlama stablecoin supply (no key)
- Optional AI presets:
  - Groq Free: openai/gpt-oss-20b
  - Gemini: grounded search
  - OpenRouter Free Router
  - OpenAI-compatible custom endpoint

New Decision Stack:
- risk budget multiplier
- crypto stablecoin liquidity 7D/30D
- evidence supporting regime
- contradictions/invalidation
- actionable posture independent of AI
