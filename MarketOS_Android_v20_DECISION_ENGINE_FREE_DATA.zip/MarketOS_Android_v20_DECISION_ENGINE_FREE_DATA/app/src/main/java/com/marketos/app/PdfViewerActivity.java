package com.marketos.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.StatFs;
import android.view.ActionMode;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class PdfViewerActivity extends Activity {
    private final ThreadPoolExecutor executor=new ThreadPoolExecutor(1,1,20L,TimeUnit.SECONDS,new ArrayBlockingQueue<>(4),new ThreadPoolExecutor.DiscardOldestPolicy());
    private PdfRenderer renderer; private ParcelFileDescriptor descriptor; private PDDocument pdDocument; private int pageIndex=0;
    private ImageView image; private TextView pageText,status,textLayer; private Button prev,next,viewBtn; private ScrollView textScroll;
    private Bitmap currentBitmap; private File tempFile;
    private Translator translator;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        PDFBoxResourceLoader.init(getApplicationContext());
        TranslatorOptions opts=new TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.VIETNAMESE).build();
        translator= Translation.getClient(opts);
        String url=getIntent().getStringExtra("url");if(!isAllowed(url)){finish();return;}buildUi();status.setText("Đang tải PDF chính thức từ Federal Reserve…");executor.execute(()->load(url));
    }
    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,16,16,16);root.setBackgroundColor(0xff07111d);
        status=new TextView(this);status.setTextColor(0xffd9e5f0);status.setTextSize(15);root.addView(status,new LinearLayout.LayoutParams(-1,-2));
        image=new ImageView(this);image.setAdjustViewBounds(true);image.setBackgroundColor(Color.WHITE);image.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,0,1);ip.topMargin=12;root.addView(image,ip);
        textLayer=new TextView(this);textLayer.setTextColor(0xffeaf2fa);textLayer.setTextSize(17);textLayer.setLineSpacing(0,1.35f);textLayer.setPadding(10,10,10,30);textLayer.setTextIsSelectable(true);
        textLayer.setCustomSelectionActionModeCallback(new ActionMode.Callback(){
            public boolean onCreateActionMode(ActionMode mode,Menu menu){menu.add(0,9001,0,"Dịch VI");return true;}
            public boolean onPrepareActionMode(ActionMode mode,Menu menu){return false;}
            public boolean onActionItemClicked(ActionMode mode,MenuItem item){if(item.getItemId()!=9001)return false;int a=textLayer.getSelectionStart(),z=textLayer.getSelectionEnd();if(a<0||z<=a)return false;String selected=textLayer.getText().subSequence(a,z).toString();translateSelection(selected);mode.finish();return true;}
            public void onDestroyActionMode(ActionMode mode){}
        });
        textScroll=new ScrollView(this);textScroll.addView(textLayer,new ScrollView.LayoutParams(-1,-2));textScroll.setVisibility(View.GONE);root.addView(textScroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER);prev=new Button(this);prev.setText("← Trước");next=new Button(this);next.setText("Sau →");viewBtn=new Button(this);viewBtn.setText("Văn bản");pageText=new TextView(this);pageText.setTextColor(0xffffffff);pageText.setPadding(18,0,18,0);bar.addView(prev);bar.addView(pageText);bar.addView(next);bar.addView(viewBtn);root.addView(bar,new LinearLayout.LayoutParams(-1,-2));setContentView(root);
        prev.setOnClickListener(v->{if(pageIndex>0){pageIndex--;render();}});next.setOnClickListener(v->{if(renderer!=null&&pageIndex<renderer.getPageCount()-1){pageIndex++;render();}});
        viewBtn.setOnClickListener(v->{boolean textVisible=textScroll.getVisibility()==View.VISIBLE;textScroll.setVisibility(textVisible?View.GONE:View.VISIBLE);image.setVisibility(textVisible?View.VISIBLE:View.GONE);viewBtn.setText(textVisible?"Văn bản":"Trang PDF");if(!textVisible)loadPageText();});
    }
    private void load(String url){try{File f=new File(getCacheDir(),"marketos_document_"+System.currentTimeMillis()+".pdf");tempFile=f;StatFs stat=new StatFs(getCacheDir().getAbsolutePath());if(stat.getAvailableBytes()<80_000_000L)throw new IllegalStateException("Thiếu dung lượng trống an toàn để tải PDF");HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(45000);c.setRequestProperty("User-Agent","MarketOS/12 Android");int code=c.getResponseCode();if(code<200||code>=300)throw new IllegalStateException("PDF HTTP "+code);try(InputStream is=c.getInputStream();FileOutputStream os=new FileOutputStream(f)){byte[] buf=new byte[16384];int n;long total=0;while((n=is.read(buf))>0){os.write(buf,0,n);total+=n;if(total>30_000_000)throw new IllegalStateException("PDF vượt giới hạn 30 MB");}}c.disconnect();descriptor=ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY);renderer=new PdfRenderer(descriptor);pdDocument=PDDocument.load(f);runOnUiThread(()->{status.setText("PDF · federalreserve.gov · nền trắng · có lớp văn bản chọn lọc");render();});}catch(Exception e){runOnUiThread(()->status.setText("Không mở được PDF: "+e.getMessage()));}}
    private void render(){if(renderer==null||renderer.getPageCount()==0)return;try(PdfRenderer.Page page=renderer.openPage(pageIndex)){int target=Math.max(900,getResources().getDisplayMetrics().widthPixels-32);float ratio=(float)page.getHeight()/Math.max(1,page.getWidth());int h=Math.max(1200,(int)(target*ratio));Bitmap bmp=Bitmap.createBitmap(target,h,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(bmp);canvas.drawColor(Color.WHITE);page.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);Bitmap old=currentBitmap;currentBitmap=bmp;image.setImageBitmap(bmp);if(old!=null&&!old.isRecycled())old.recycle();pageText.setText((pageIndex+1)+" / "+renderer.getPageCount());prev.setEnabled(pageIndex>0);next.setEnabled(pageIndex<renderer.getPageCount()-1);if(textScroll.getVisibility()==View.VISIBLE)loadPageText();}catch(Exception e){status.setText("Lỗi render PDF: "+e.getMessage());}}
    private void loadPageText(){if(pdDocument==null)return;executor.execute(()->{try{PDFTextStripper s=new PDFTextStripper();s.setStartPage(pageIndex+1);s.setEndPage(pageIndex+1);String t=s.getText(pdDocument).trim();runOnUiThread(()->textLayer.setText(t.isEmpty()?"Trang này không có lớp text có thể trích xuất.":t));}catch(Exception e){runOnUiThread(()->textLayer.setText("Không trích được văn bản trang: "+e.getMessage()));}});}
    private void translateSelection(String selected){new AlertDialog.Builder(this).setTitle("Dịch đoạn đã chọn").setMessage("Đang dịch trên máy…").setPositiveButton("Đóng",null).show();executor.execute(()->{try{Tasks.await(translator.downloadModelIfNeeded(new DownloadConditions.Builder().build()),90,TimeUnit.SECONDS);String vi=Tasks.await(translator.translate(selected),60,TimeUnit.SECONDS);runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Bản dịch VI").setMessage(vi).setPositiveButton("Đóng",null).show());}catch(Exception e){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Không dịch được").setMessage(e.getMessage()).setPositiveButton("Đóng",null).show());}});}
    private boolean isAllowed(String url){try{Uri u=Uri.parse(url);String h=u.getHost();return "https".equalsIgnoreCase(u.getScheme())&&h!=null&&h.endsWith("federalreserve.gov")&&u.getPath()!=null&&u.getPath().toLowerCase().endsWith(".pdf");}catch(Exception e){return false;}}
    @Override protected void onDestroy(){executor.shutdownNow();try{if(renderer!=null)renderer.close();}catch(Exception ignored){}try{if(pdDocument!=null)pdDocument.close();}catch(Exception ignored){}try{if(descriptor!=null)descriptor.close();}catch(Exception ignored){}try{if(translator!=null)translator.close();}catch(Exception ignored){}try{if(currentBitmap!=null&&!currentBitmap.isRecycled())currentBitmap.recycle();}catch(Exception ignored){}try{if(tempFile!=null&&tempFile.exists())tempFile.delete();}catch(Exception ignored){}super.onDestroy();}
}
