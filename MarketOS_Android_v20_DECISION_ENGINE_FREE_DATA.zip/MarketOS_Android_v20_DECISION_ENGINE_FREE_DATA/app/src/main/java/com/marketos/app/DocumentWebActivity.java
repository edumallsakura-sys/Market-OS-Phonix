package com.marketos.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class DocumentWebActivity extends Activity {
    private WebView webView;
    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String url=getIntent().getStringExtra("url");
        if(!isAllowed(url)){finish();return;}
        webView=new WebView(this);setContentView(webView);
        WebView.setWebContentsDebuggingEnabled(false);
        WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setBuiltInZoomControls(true);s.setDisplayZoomControls(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setAllowFileAccess(false);s.setAllowContentAccess(false);
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest req){String u=req.getUrl().toString();if(isAllowed(u)){view.loadUrl(u);}return true;}
        });
        webView.loadUrl(url);
    }
    private boolean isAllowed(String url){try{Uri u=Uri.parse(url);String h=u.getHost();return "https".equalsIgnoreCase(u.getScheme())&&h!=null&&h.endsWith("federalreserve.gov");}catch(Exception e){return false;}}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onResume(){super.onResume();if(webView!=null)webView.onResume();}
    @Override protected void onPause(){if(webView!=null)webView.onPause();super.onPause();}
    @Override protected void onDestroy(){if(webView!=null){webView.stopLoading();webView.loadUrl("about:blank");webView.clearHistory();webView.removeAllViews();webView.destroy();webView=null;}super.onDestroy();}
}
