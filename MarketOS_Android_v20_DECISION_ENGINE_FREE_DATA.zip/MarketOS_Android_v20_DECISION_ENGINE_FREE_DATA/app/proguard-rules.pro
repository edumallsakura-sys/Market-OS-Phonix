# MarketOS v14 resource-safe release rules
-keepclassmembers class com.marketos.app.MainActivity$NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes *Annotation*
-dontwarn com.tom_roush.pdfbox.**
