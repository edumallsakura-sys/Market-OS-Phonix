MarketOS GitHub ONECLICK v35.3 — Regression Restore

Cách dùng:
1) Giải nén file ONECLICK này.
2) Upload TOÀN BỘ nội dung bên trong (bao gồm thư mục ẩn .github) lên repo GitHub.
3) Vào Actions -> Universal Android ZIP Builder V35.3 -> Run workflow.
4) Tải artifact Android-APKs.

Workflow tự giải nén project trong projects/, chạy v35_static_audit.py, kiểm tra cú pháp JavaScript rồi build APK với JDK 17 / Gradle 8.9.

Bản này giữ engine V29–V35, sửa hồi quy Coin Lab: progress Spot/Core/Nguồn/Gate, execution verdict sớm, next blocker/source, và giới hạn tail provider 58 giây. Core facts không phụ thuộc AI.
