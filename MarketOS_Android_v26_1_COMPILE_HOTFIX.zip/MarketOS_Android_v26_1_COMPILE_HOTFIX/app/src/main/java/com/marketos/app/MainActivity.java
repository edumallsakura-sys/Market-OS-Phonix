package com.marketos.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.StatFs;
import android.content.ComponentCallbacks2;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.LinkedHashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
    private WebView webView;
    // Bounded worker pool: no unbounded task queue is allowed.
    private final ThreadPoolExecutor executor = new ThreadPoolExecutor(
            2, 4, 30L, TimeUnit.SECONDS,
            new ArrayBlockingQueue<>(24),
            new ThreadPoolExecutor.AbortPolicy());
    private final Set<String> inFlight = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
    private final AtomicBoolean destroyed = new AtomicBoolean(false);
    private volatile boolean appForeground = true;
    private volatile long lastCleanupAt = 0L;
    private Translator enViTranslator;
    private SharedPreferences prefs;
    // Bounded metadata cache: one DefiLlama protocol directory, refreshed at most every 6h.
    private volatile JSONArray llamaProtocolsCache = null;
    private volatile long llamaProtocolsCacheAt = 0L;
    // Dynamic stablecoin symbol cache from DefiLlama; refreshed at most every 6h.
    private volatile Set<String> stableSymbolsCache = null;
    private volatile long stableSymbolsCacheAt = 0L;
    // DefiLlama chain directory for native L1/L2 context.
    private volatile JSONArray llamaChainsCache = null;
    private volatile long llamaChainsCacheAt = 0L;

    private static class FeedItem {
        String title = "", link = "", pubDate = "", description = "", source = "";
        long epoch = 0L;
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("marketos_secure_config", MODE_PRIVATE);
        PDFBoxResourceLoader.init(getApplicationContext());
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.VIETNAMESE)
                .build();
        enViTranslator = Translation.getClient(options);

        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        WebView.setWebContentsDebuggingEnabled(false);
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " MarketOS/26.1");
        webView.addJavascriptInterface(new NativeBridge(), "MarketNative");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean submitWork(Runnable task) {
        if (task == null || destroyed.get() || executor.isShutdown()) return false;
        try {
            executor.execute(() -> {
                if (destroyed.get()) return;
                try { task.run(); } catch (Throwable ignored) { /* boundary: never crash UI from worker */ }
            });
            return true;
        } catch (RejectedExecutionException ignored) {
            // Backpressure: when queue is full, reject new non-critical work instead of growing RAM.
            return false;
        }
    }

    private void submitUnique(String key, Runnable task) {
        if (key == null || !inFlight.add(key)) return;
        boolean accepted = submitWork(() -> {
            try { task.run(); } finally { inFlight.remove(key); }
        });
        if(!accepted) inFlight.remove(key);
    }

    private void notifyWebLifecycle(String fn) {
        if (webView == null || destroyed.get()) return;
        webView.evaluateJavascript("if(window." + fn + ") window." + fn + "();", null);
    }

    public class NativeBridge {
        @JavascriptInterface public void refreshFed() {
            submitUnique("fed:refresh", () -> {
                try {
                    List<FeedItem> all = new ArrayList<>();
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/press_monetary.xml", "Monetary Policy"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/speeches.xml", "Speech"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/testimony.xml", "Testimony"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/press_all.xml", "Press Release"));
                    all.addAll(fetchFeed("https://www.federalreserve.gov/feeds/clp.xml", "Liquidity/Balance Sheet"));
                    // Fallback/supplement: official HTML indexes. This prevents a stale or temporarily blocked RSS feed
                    // from making the app look frozen. Only federalreserve.gov pages are accepted.
                    try { all.addAll(scrapeFedIndex("https://www.federalreserve.gov/recentpostings.htm", "Fed Recent Posting")); } catch(Exception ignored) {}
                    try { all.addAll(scrapeFedIndex("https://www.federalreserve.gov/newsevents.htm", "Fed News")); } catch(Exception ignored) {}
                    try { all.addAll(scrapeFedIndex("https://www.federalreserve.gov/newsevents/2026-speeches.htm", "Speech")); } catch(Exception ignored) {}
                    try { all.addAll(scrapeFedIndex("https://www.federalreserve.gov/monetarypolicy.htm", "Monetary Policy")); } catch(Exception ignored) {}
                    List<FeedItem> unique = new ArrayList<>();
                    Set<String> seen = new HashSet<>();
                    for (FeedItem item : all) {
                        String key = item.link.isEmpty() ? item.title + item.pubDate : item.link;
                        if (seen.add(key)) unique.add(item);
                    }
                    Collections.sort(unique, (a,b) -> Long.compare(b.epoch, a.epoch));
                    JSONArray arr = new JSONArray();
                    for (int i=0;i<Math.min(unique.size(),140);i++) {
                        FeedItem x=unique.get(i); JSONObject o=new JSONObject();
                        o.put("title",x.title); o.put("link",x.link); o.put("pubDate",x.pubDate); o.put("epoch",x.epoch);
                        o.put("description",clean(x.description)); o.put("source",x.source); o.put("importance",importance(x));
                        arr.put(o);
                    }
                    JSONObject p=new JSONObject(); p.put("ok",true); p.put("updatedAt",isoNow()); p.put("items",arr);
                    p.put("itemCount", arr.length());
                    if(arr.length()>0){ JSONObject latest=arr.optJSONObject(0); if(latest!=null){ p.put("latestTitle",latest.optString("title")); p.put("latestPubDate",latest.optString("pubDate")); p.put("latestLink",latest.optString("link")); } }
                    p.put("sourceMode","Federal Reserve RSS + Recent Postings + official HTML fallback");
                    send("onFedPayload",p.toString());
                } catch(Exception e) { sendError("onFedPayload", e); }
            });
        }

        @JavascriptInterface public void fetchFedArticle(String requestId, String url) {
            submitWork(() -> {
                try {
                    assertOfficialFedUrl(url);
                    JSONObject article = fetchArticle(url);
                    String text = article.getString("text");
                    JSONObject p = new JSONObject();
                    p.put("ok", true); p.put("requestId", requestId); p.put("url", url);
                    p.put("title", article.optString("title"));
                    p.put("subtitle", article.optString("subtitle"));
                    p.put("byline", article.optString("byline"));
                    p.put("text", text);
                    p.put("paragraphs", article.optJSONArray("paragraphs"));
                    p.put("blocks", article.optJSONArray("blocks"));
                    p.put("sourcePageUrl", article.optString("sourcePageUrl", url));
                    p.put("contentUrl", article.optString("contentUrl", url));
                    p.put("htmlUrl", article.optString("htmlUrl", ""));
                    p.put("pdfUrl", article.optString("pdfUrl", ""));
                    p.put("contentKind", article.optString("contentKind", "HTML"));
                    p.put("wordCount", article.optInt("wordCount", 0));
                    p.put("readingMinutes", article.optInt("readingMinutes", 0));
                    p.put("bodyBlocks", article.optInt("bodyBlocks", 0));
                    p.put("boilerplateDropped", article.optInt("boilerplateDropped", 0));
                    p.put("documentQuality", article.optString("documentQuality", "UNKNOWN"));
                    p.put("analysis", analyzeTone(text));
                    p.put("investment", analyzeInvestmentChannels(text));
                    p.put("updatedAt", isoNow());
                    send("onFedArticlePayload", p.toString());
                } catch (Exception e) { sendReqError("onFedArticlePayload", requestId, e); }
            });
        }

        @JavascriptInterface public void translateToVietnamese(String requestId, String text) {
            submitWork(() -> {
                try {
                    if (text == null || text.trim().isEmpty()) throw new IllegalArgumentException("Không có văn bản để dịch");
                    DownloadConditions conditions = new DownloadConditions.Builder().build();
                    Tasks.await(enViTranslator.downloadModelIfNeeded(conditions), 90, TimeUnit.SECONDS);
                    String translated = translateChunks(text);
                    JSONObject p = new JSONObject(); p.put("ok", true); p.put("requestId", requestId);
                    p.put("provider", "ML Kit on-device"); p.put("translated", translated);
                    send("onTranslationPayload", p.toString());
                } catch (Exception localError) {
                    try {
                        AiCfg cfg=getAiCfg();
                        String translated=callFaithfulTranslation(cfg,text);
                        JSONObject p = new JSONObject(); p.put("ok", true); p.put("requestId", requestId);
                        p.put("provider", "AI API fallback"); p.put("translated", translated);
                        send("onTranslationPayload", p.toString());
                    } catch (Exception fallbackError) {
                        sendReqError("onTranslationPayload", requestId, new IllegalStateException("ML Kit: "+localError.getMessage()+" | AI fallback: "+fallbackError.getMessage()));
                    }
                }
            });
        }

        @JavascriptInterface public void saveAiTranslator(String provider, String endpoint, String model, String apiKey) {
            try {
                String pv = provider == null ? "AUTO" : provider.trim().toUpperCase(Locale.US);
                String ep = endpoint == null ? "" : endpoint.trim();
                if (pv.equals("GEMINI") && !ep.contains("generativelanguage.googleapis.com")) ep = "";
                if (pv.equals("GROQ_FREE") && ep.isEmpty()) ep = "https://api.groq.com/openai/v1/chat/completions";
                if (pv.equals("OPENROUTER_FREE") && ep.isEmpty()) ep = "https://openrouter.ai/api/v1/chat/completions";
                String md = model == null ? "" : model.trim();
                String key = apiKey == null ? "" : apiKey.trim();
                if (!ep.isEmpty()) {
                    Uri u=Uri.parse(ep);
                    if (!"https".equalsIgnoreCase(u.getScheme()) || u.getHost()==null) throw new IllegalArgumentException("Endpoint phải dùng HTTPS");
                }
                if (md.isEmpty() || md.equalsIgnoreCase("AUTO")) {
                    if (pv.equals("GEMINI")) md = "AUTO";
                    else if (pv.equals("GROQ_FREE")) md = "openai/gpt-oss-20b";
                    else if (pv.equals("OPENROUTER_FREE")) md = "openrouter/free";
                    else md = "openai/gpt-oss-20b";
                }
                prefs.edit().putString("ai_provider", pv).putString("ai_endpoint", ep).putString("ai_model", md)
                        .putString("ai_key_secure", encryptSecret(key)).remove("ai_key").apply();
                JSONObject p=new JSONObject(); p.put("ok",true); p.put("provider",pv); p.put("endpoint",ep); p.put("model",md); p.put("hasKey",!key.isEmpty());
                send("onAiConfigPayload",p.toString());
            } catch(Exception e){ sendError("onAiConfigPayload",e); }
        }

        @JavascriptInterface public void getAiTranslatorConfig() {
            try {
                String savedProvider=prefs.getString("ai_provider","");
                String savedEndpoint=prefs.getString("ai_endpoint","");
                String savedModel=prefs.getString("ai_model","");
                String pv=savedProvider;
                if(pv.isEmpty()) pv=(savedModel.toLowerCase(Locale.US).startsWith("gemini-")||savedEndpoint.contains("generativelanguage.googleapis.com"))?"GEMINI":(!savedEndpoint.isEmpty()?"OPENAI_COMPATIBLE":"GEMINI");
                if(pv.equals("GEMINI")&&!savedEndpoint.contains("generativelanguage.googleapis.com")) savedEndpoint="";
                JSONObject p=new JSONObject(); p.put("ok",true); p.put("provider",pv);
                String defaultEp=pv.equals("GEMINI")?"":pv.equals("OPENROUTER_FREE")?"https://openrouter.ai/api/v1/chat/completions":"https://api.groq.com/openai/v1/chat/completions";
                p.put("endpoint",savedEndpoint.isEmpty()?defaultEp:savedEndpoint);
                String defaultModel=pv.equals("GEMINI")?"AUTO":pv.equals("OPENROUTER_FREE")?"openrouter/free":"openai/gpt-oss-20b";
                p.put("model",savedModel.isEmpty()?defaultModel:savedModel); p.put("activeModel",prefs.getString("ai_last_model",""));
                p.put("hasKey",hasStoredAiKey());
                send("onAiConfigPayload",p.toString());
            }catch(Exception ignored){}
        }


        @JavascriptInterface public void saveGoPlusToken(String token) {
            try {
                String t = token == null ? "" : token.trim();
                SharedPreferences.Editor ed = prefs.edit();
                if (t.isEmpty()) ed.remove("goplus_token_secure");
                else ed.putString("goplus_token_secure", encryptSecret(t));
                ed.apply();
                JSONObject p = new JSONObject();
                p.put("ok", true);
                p.put("hasToken", !t.isEmpty());
                send("onSecurityConfigPayload", p.toString());
            } catch (Exception e) { sendError("onSecurityConfigPayload", e); }
        }

        @JavascriptInterface public void getSecurityConfig() {
            try {
                JSONObject p = new JSONObject();
                p.put("ok", true);
                p.put("hasToken", !getOptionalSecret("goplus_token_secure").isEmpty());
                send("onSecurityConfigPayload", p.toString());
            } catch (Exception ignored) {}
        }

        @JavascriptInterface public void testAiTranslator(String requestId) {
            submitWork(() -> {
                try {
                    AiCfg c = getAiCfg();
                    String out = callAi(c, "Bạn là bộ kiểm tra kết nối. Chỉ trả lời đúng: OK", "Trả lời OK.", 0.0);
                    JSONObject p=new JSONObject(); p.put("ok", out.toUpperCase(Locale.US).contains("OK")); p.put("requestId",requestId); p.put("provider",c.provider); p.put("model",c.model); p.put("message","Kết nối API hoạt động");
                    send("onAiTestPayload",p.toString());
                } catch(Exception e) { sendReqError("onAiTestPayload",requestId,e); }
            });
        }

        @JavascriptInterface public void translateWithAi(String requestId, String text) {
            submitWork(() -> {
                try {
                    AiCfg c=getAiCfg();
                    String translated=callFaithfulTranslation(c,text);
                    JSONObject p=new JSONObject(); p.put("ok",true);p.put("requestId",requestId);p.put("provider",c.provider+(c.provider.equals("GEMINI")?" · "+c.model:""));p.put("translated",translated);
                    send("onTranslationPayload",p.toString());
                }catch(Exception e){sendReqError("onTranslationPayload",requestId,e);}
            });
        }

        @JavascriptInterface public void analyzeWithAi(String requestId, String title, String text) {
            submitWork(() -> {
                try {
                    AiCfg c=getAiCfg();
                    String prompt = "TITLE: "+(title==null?"":title)+"\n\nSOURCE:\n"+(text==null?"":text);
                    String analysis = callInvestmentAi(c, prompt);
                    JSONObject p=new JSONObject(); p.put("ok",true); p.put("requestId",requestId); p.put("provider",c.provider+(c.provider.equals("GEMINI")?" · "+c.model:"")); p.put("analysisText",analysis);
                    send("onAiInvestmentPayload",p.toString());
                } catch(Exception e) { sendReqError("onAiInvestmentPayload",requestId,e); }
            });
        }

        @JavascriptInterface public void compareWithPrevious(String requestId, String currentUrl, String title, String source) {
            submitWork(() -> {
                try {
                    assertOfficialFedUrl(currentUrl);
                    JSONObject current=fetchArticle(currentUrl);
                    String previousUrl=findPreviousComparableUrl(currentUrl,title,source);
                    if(previousUrl==null||previousUrl.isEmpty()) throw new IllegalStateException("Không tìm thấy bản gần nhất trước đó cùng loại trong nguồn Fed");
                    JSONObject previous=fetchArticle(previousUrl);
                    validateComparableDocuments(title,current,previous);
                    AiCfg cfg=getAiCfg();
                    String comparison=callComparisonAi(cfg, previous, current);
                    JSONObject p=new JSONObject(); p.put("ok",true);p.put("requestId",requestId);p.put("provider",cfg.provider+(cfg.provider.equals("GEMINI")?" · "+cfg.model:""));
                    p.put("previousTitle",previous.optString("title"));p.put("previousUrl",previousUrl);p.put("currentTitle",current.optString("title"));p.put("comparisonText",comparison);
                    send("onComparisonPayload",p.toString());
                }catch(Exception e){sendReqError("onComparisonPayload",requestId,e);}
            });
        }

        @JavascriptInterface public void openHtmlInApp(String url) {
            try { assertOfficialFedUrl(url); Intent i=new Intent(MainActivity.this, DocumentWebActivity.class); i.putExtra("url",url); startActivity(i); } catch(Exception ignored){}
        }

        @JavascriptInterface public void openPdfInApp(String url) {
            try { assertOfficialFedUrl(url); Intent i=new Intent(MainActivity.this, PdfViewerActivity.class); i.putExtra("url",url); startActivity(i); } catch(Exception ignored){}
        }



        private long directorySize(File root, int maxEntries) {
            if (root == null || !root.exists() || maxEntries <= 0) return 0L;
            long total = 0L;
            ArrayList<File> stack = new ArrayList<>();
            stack.add(root);
            int seen = 0;
            while (!stack.isEmpty() && seen < maxEntries) {
                File f = stack.remove(stack.size() - 1);
                seen++;
                if (f.isFile()) {
                    long len = f.length();
                    if (len > 0) total += len;
                } else {
                    File[] children = f.listFiles();
                    if (children != null) {
                        for (File c : children) {
                            if (seen + stack.size() >= maxEntries) break;
                            stack.add(c);
                        }
                    }
                }
            }
            return total;
        }

        private void cleanupOldCacheFiles(File root, long olderThan, int maxEntries) {
            if (root == null || !root.exists() || maxEntries <= 0) return;
            ArrayList<File> stack = new ArrayList<>();
            stack.add(root);
            int seen = 0;
            while (!stack.isEmpty() && seen < maxEntries) {
                File f = stack.remove(stack.size() - 1);
                seen++;
                if (f.isDirectory()) {
                    File[] children = f.listFiles();
                    if (children != null) {
                        for (File c : children) {
                            if (seen + stack.size() >= maxEntries) break;
                            stack.add(c);
                        }
                    }
                } else if (f.lastModified() > 0 && f.lastModified() < olderThan) {
                    try { f.delete(); } catch (Throwable ignored) {}
                }
            }
        }

        @JavascriptInterface public void getSystemHealth() {
            try {
                JSONObject p = new JSONObject();
                p.put("ok", true);
                p.put("foreground", appForeground);
                p.put("activeWorkers", executor.getActiveCount());
                p.put("poolSize", executor.getPoolSize());
                p.put("queueSize", executor.getQueue().size());
                p.put("queueCapacity", 24);
                p.put("inFlight", inFlight.size());
                p.put("completedTasks", executor.getCompletedTaskCount());
                p.put("cacheBytes", directorySize(getCacheDir(), 4000));
                StatFs stat = new StatFs(getCacheDir().getAbsolutePath());
                p.put("freeBytes", stat.getAvailableBytes());
                p.put("lastCleanupAt", lastCleanupAt);
                p.put("updatedAt", isoNow());
                send("onSystemHealthPayload", p.toString());
            } catch(Exception e) { sendError("onSystemHealthPayload", e); }
        }

        @JavascriptInterface public void cleanupCacheNow() {
            runOnUiThread(() -> {
                try {
                    if (webView != null) webView.clearCache(false);
                    cleanupOldCacheFiles(getCacheDir(), System.currentTimeMillis() - 7L*24L*60L*60L*1000L, 4000);
                    lastCleanupAt = System.currentTimeMillis();
                    getSystemHealth();
                } catch(Exception ignored) {}
            });
        }

        @JavascriptInterface public void fetchFredSeries(String id) {
            String safeId = id == null ? "" : id.trim().toUpperCase(Locale.US);
            submitUnique("fred:" + safeId, () -> {
                try { send("onFredSeriesPayload", fetchFred(safeId).toString()); }
                catch(Exception e) { sendFredError(safeId,e); }
            });
        }

        @JavascriptInterface public void fetchFredSeriesBatch(String id, String batchId) {
            String safeId = id == null ? "" : id.trim().toUpperCase(Locale.US);
            String safeBatch = batchId == null ? "" : batchId.replaceAll("[^A-Za-z0-9_.:-]", "");
            submitUnique("fred:" + safeId, () -> {
                try {
                    JSONObject p = fetchFred(safeId);
                    p.put("batchId", safeBatch);
                    send("onFredSeriesPayload", p.toString());
                } catch(Exception e) { sendFredBatchError(safeId, safeBatch, e); }
            });
        }

        @JavascriptInterface public void refreshCrypto() {
            submitWork(() -> {
                try {
                    JSONObject out = new JSONObject();
                    JSONObject simple = httpJson("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd&include_24hr_change=true");
                    JSONObject global = httpJson("https://api.coingecko.com/api/v3/global").optJSONObject("data");
                    JSONObject btc = simple.optJSONObject("bitcoin");
                    JSONObject eth = simple.optJSONObject("ethereum");
                    if (btc == null || eth == null) throw new IllegalStateException("CoinGecko thiếu dữ liệu BTC/ETH");
                    out.put("ok", true);
                    out.put("btcUsd", btc.optDouble("usd", Double.NaN));
                    out.put("btc24", btc.optDouble("usd_24h_change", Double.NaN));
                    out.put("ethUsd", eth.optDouble("usd", Double.NaN));
                    out.put("eth24", eth.optDouble("usd_24h_change", Double.NaN));
                    if (global != null) {
                        JSONObject pct = global.optJSONObject("market_cap_percentage");
                        JSONObject tmc = global.optJSONObject("total_market_cap");
                        if (pct != null) out.put("btcDominance", pct.optDouble("btc", Double.NaN));
                        if (tmc != null) out.put("totalMarketCapUsd", tmc.optDouble("usd", Double.NaN));
                        out.put("marketCap24", global.optDouble("market_cap_change_percentage_24h_usd", Double.NaN));
                    }
                    out.put("updatedAt", isoNow());
                    out.put("source", "CoinGecko");
                    send("onCryptoPayload", out.toString());
                } catch (Exception e) { sendError("onCryptoPayload", e); }
            });
        }

        @JavascriptInterface public void refreshCryptoWatchlist(String idsCsv) {
            submitWork(() -> {
                try {
                    String raw=idsCsv==null?"":idsCsv.trim().toLowerCase(Locale.US);
                    if(raw.isEmpty()) raw="bitcoin,ethereum,solana,binancecoin,ripple";
                    String[] parts=raw.split(",");
                    LinkedHashSet<String> cleanIds=new LinkedHashSet<>();
                    for(String x:parts){String id=x.trim();if(id.matches("[a-z0-9-]{1,64}"))cleanIds.add(id);if(cleanIds.size()>=20)break;}
                    if(cleanIds.isEmpty()) throw new IllegalArgumentException("Danh sách crypto không hợp lệ");
                    String joined=android.text.TextUtils.join(",",cleanIds);
                    String url="https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids="+URLEncoder.encode(joined,"UTF-8")+"&order=market_cap_desc&per_page=20&page=1&sparkline=false&price_change_percentage=24h,7d";
                    JSONArray arr=httpJsonArray(url);
                    JSONObject out=new JSONObject();out.put("ok",true);out.put("source","CoinGecko");out.put("updatedAt",isoNow());out.put("items",arr);
                    send("onCryptoWatchlistPayload",out.toString());
                }catch(Exception e){sendError("onCryptoWatchlistPayload",e);}
            });
        }

        @JavascriptInterface public void fetchCryptoChart(String requestId,String coinId,int days) {
            submitWork(() -> {
                try {
                    String id=coinId==null?"":coinId.trim().toLowerCase(Locale.US);
                    if(!id.matches("[a-z0-9-]{1,64}")) throw new IllegalArgumentException("Coin ID không hợp lệ");
                    int d=Math.max(1,Math.min(days,365));
                    String url="https://api.coingecko.com/api/v3/coins/"+URLEncoder.encode(id,"UTF-8")+"/market_chart?vs_currency=usd&days="+d+"&interval=daily";
                    JSONObject j=httpJson(url);JSONObject out=new JSONObject();out.put("ok",true);out.put("requestId",requestId);out.put("coinId",id);out.put("days",d);out.put("prices",j.optJSONArray("prices"));out.put("volumes",j.optJSONArray("total_volumes"));out.put("source","CoinGecko");out.put("updatedAt",isoNow());
                    send("onCryptoChartPayload",out.toString());
                }catch(Exception e){sendReqError("onCryptoChartPayload",requestId,e);}
            });
        }


        @JavascriptInterface public void scanBinanceSpotUniverse(String requestId, double minQuoteVolumeUsd, int maxResults, String sectorFilter, boolean includeMeme) {
            submitUnique("spot-scan", () -> {
                try {
                    double minVol = Math.max(0.0, minQuoteVolumeUsd);
                    int max = Math.max(10, Math.min(maxResults, 60));
                    String wantedSector = sectorFilter == null ? "ALL" : sectorFilter.trim().toUpperCase(Locale.US);
                    if (wantedSector.isEmpty()) wantedSector = "ALL";

                    /*
                     * v23: discover the live Binance Spot universe from exchangeInfo.
                     * This is manual/event-driven only: no polling, no background retry loop.
                     * showPermissionSets=false keeps the response materially smaller while preserving
                     * symbol/status/base/quote/isSpotTradingAllowed needed for the scan.
                     */
                    JSONObject exchange;
                    String exchangeUrl = "https://data-api.binance.vision/api/v3/exchangeInfo?permissions=SPOT&showPermissionSets=false&symbolStatus=TRADING";
                    try {
                        exchange = httpJsonBounded(exchangeUrl, 8_000_000);
                    } catch (Exception first) {
                        exchangeUrl = "https://api.binance.com/api/v3/exchangeInfo?permissions=SPOT&showPermissionSets=false&symbolStatus=TRADING";
                        exchange = httpJsonBounded(exchangeUrl, 8_000_000);
                    }

                    JSONArray symbols = exchange.optJSONArray("symbols");
                    if (symbols == null) throw new IllegalStateException("Binance exchangeInfo không có symbols");

                    LinkedHashMap<String, JSONObject> byBase = new LinkedHashMap<>();
                    JSONArray rejected = new JSONArray();
                    Set<String> dynamicStable = getDynamicStableSymbols();
                    int rawTradingSpot = 0, excludedStable = 0, excludedWrapped = 0, excludedMeme = 0, excludedSector = 0;

                    for (int i = 0; i < symbols.length(); i++) {
                        JSONObject x = symbols.optJSONObject(i);
                        if (x == null) continue;
                        if (!"TRADING".equalsIgnoreCase(x.optString("status", ""))) continue;
                        if (!x.optBoolean("isSpotTradingAllowed", true)) continue;

                        String symbol = x.optString("symbol", "").toUpperCase(Locale.US);
                        String base = x.optString("baseAsset", "").toUpperCase(Locale.US);
                        String quote = x.optString("quoteAsset", "").toUpperCase(Locale.US);
                        if (symbol.isEmpty() || base.isEmpty()) continue;
                        if (quotePreference(quote) >= 99) continue;
                        rawTradingSpot++;

                        String exclusion = baseExclusionReason(base, dynamicStable);
                        if (!exclusion.isEmpty()) {
                            if ("STABLE".equals(exclusion)) excludedStable++;
                            else excludedWrapped++;
                            if (rejected.length() < 60) rejected.put(new JSONObject().put("symbol", symbol).put("reason", exclusion));
                            continue;
                        }

                        String sector = sectorOf(base);
                        if (!includeMeme && "MEME".equals(sector)) {
                            excludedMeme++;
                            if (rejected.length() < 60) rejected.put(new JSONObject().put("symbol", symbol).put("reason", "MEME_FILTER"));
                            continue;
                        }
                        if (!"ALL".equals(wantedSector) && !wantedSector.equals(sector)) {
                            excludedSector++;
                            continue;
                        }

                        JSONObject old = byBase.get(base);
                        if (old == null || quotePreference(quote) < quotePreference(old.optString("quoteAsset", ""))) {
                            byBase.put(base, x);
                        }
                    }

                    List<String> universe = new ArrayList<>();
                    LinkedHashMap<String, JSONObject> symbolMeta = new LinkedHashMap<>();
                    for (JSONObject x : byBase.values()) {
                        String symbol = x.optString("symbol", "");
                        if (symbol.isEmpty()) continue;
                        universe.add(symbol);
                        symbolMeta.put(symbol, x);
                    }

                    LinkedHashMap<String, JSONObject> tickerMap = new LinkedHashMap<>();
                    int batchRequests = 0;
                    int fallbackRequests = 0;
                    final int CHUNK = 20; // Binance 24hr ticker: 1-20 symbols stays in the lowest batch weight tier.

                    for (int from = 0; from < universe.size(); from += CHUNK) {
                        int to = Math.min(from + CHUNK, universe.size());
                        List<String> chunk = universe.subList(from, to);
                        JSONArray reqSymbols = new JSONArray();
                        for (String sym : chunk) reqSymbols.put(sym);
                        try {
                            String url = "https://data-api.binance.vision/api/v3/ticker/24hr?symbols=" +
                                    URLEncoder.encode(reqSymbols.toString(), "UTF-8") + "&type=FULL&symbolStatus=TRADING";
                            JSONArray batch = httpJsonArrayBounded(url, 2_000_000);
                            batchRequests++;
                            for (int j = 0; j < batch.length(); j++) {
                                JSONObject t = batch.optJSONObject(j);
                                if (t != null) tickerMap.put(t.optString("symbol", ""), t);
                            }
                        } catch (Exception batchError) {
                            // One failed batch must not create a retry storm. Salvage each member once only.
                            for (String sym : chunk) {
                                try {
                                    JSONObject t = httpJson("https://data-api.binance.vision/api/v3/ticker/24hr?symbol=" +
                                            URLEncoder.encode(sym, "UTF-8") + "&symbolStatus=TRADING");
                                    fallbackRequests++;
                                    if (sym.equalsIgnoreCase(t.optString("symbol", ""))) tickerMap.put(sym, t);
                                } catch (Exception ignored) {}
                            }
                        }
                    }

                    List<JSONObject> candidates = new ArrayList<>();
                    int belowVolume = 0;
                    for (String symbol : universe) {
                        JSONObject t = tickerMap.get(symbol);
                        JSONObject meta = symbolMeta.get(symbol);
                        if (t == null || meta == null) continue;

                        String base = meta.optString("baseAsset", "");
                        String quote = meta.optString("quoteAsset", "");
                        double qv = parseDoubleSafe(t.optString("quoteVolume", "0"));
                        double px = parseDoubleSafe(t.optString("lastPrice", "0"));
                        double ch = parseDoubleSafe(t.optString("priceChangePercent", "0"));
                        long trades = t.optLong("count", 0L);

                        if (!(qv >= minVol) || !(px > 0)) {
                            belowVolume++;
                            if (rejected.length() < 60) rejected.put(new JSONObject()
                                    .put("symbol", symbol).put("reason", "LOW_VOLUME")
                                    .put("quoteVolume24", qv));
                            continue;
                        }

                        // Stage A base screen. Do not infer investment quality from 24h ticker alone.
                        int liquidity = qv >= 250_000_000 ? 8 :
                                qv >= 100_000_000 ? 7 :
                                qv >= 25_000_000 ? 6 :
                                qv >= 10_000_000 ? 5 :
                                qv >= 5_000_000 ? 4 :
                                qv >= 1_000_000 ? 3 : 1;
                        int activity = trades >= 150_000 ? 4 : trades >= 50_000 ? 3 : trades >= 10_000 ? 2 : trades > 0 ? 1 : 0;
                        int eligibility = 6;

                        JSONObject o = new JSONObject();
                        o.put("symbol", symbol);
                        o.put("base", base);
                        o.put("quote", quote);
                        o.put("sector", sectorOf(base));
                        o.put("price", px);
                        o.put("change24", ch);
                        o.put("quoteVolume24", qv);
                        o.put("trades24", trades);
                        o.put("eligibilityScore", eligibility);
                        o.put("liquidityScore", liquidity);
                        o.put("activityScore", activity);
                        o.put("trendScore", 0);
                        o.put("volumeExpansionScore", 0);
                        o.put("timingScore", 0);
                        o.put("preScore", eligibility + liquidity + activity);
                        o.put("screenCoverage", "TICKER_ONLY");
                        o.put("fomoRisk", Math.abs(ch) > 15);
                        o.put("spotVerifiedByExchangeInfo", true);
                        o.put("sourceUrl", "https://www.binance.com/en/trade/" + base + "_" + quote + "?type=spot");
                        candidates.add(o);
                    }

                    // Enrich only a bounded liquid pool with daily candles. This makes Stage A useful without
                    // turning a manual scan into hundreds of requests. No retry loop is used here.
                    candidates.sort((a,b)->Double.compare(b.optDouble("quoteVolume24"),a.optDouble("quoteVolume24")));
                    int enrichLimit=Math.min(candidates.size(), Math.max(30, Math.min(40, max+10)));
                    int enriched=0, enrichmentFailed=0;
                    for(int i=0;i<enrichLimit;i++){
                        JSONObject o=candidates.get(i);
                        try{
                            JSONObject s=fetchSpotScreen1d(o.optString("symbol",""));
                            if("OK".equals(s.optString("status"))){
                                double r7=s.optDouble("return7d",Double.NaN), r30=s.optDouble("return30d",Double.NaN),
                                        vr=s.optDouble("volumeRatio20d",Double.NaN), rsi=s.optDouble("rsi14",Double.NaN);
                                String trend=s.optString("trend","MIXED");
                                int trendScore="BULL".equals(trend)?4:"MIXED".equals(trend)?2:0;
                                if(Double.isFinite(r7)&&r7>0)trendScore++;
                                if(Double.isFinite(r30)&&r30>0)trendScore++;
                                trendScore=Math.min(6,trendScore);
                                int volScore=Double.isFinite(vr)?(vr>=1.8?3:vr>=1.25?2:vr>=0.9?1:0):0;
                                double abs7=Double.isFinite(r7)?Math.abs(r7):999;
                                int timing=(abs7<=12?3:abs7<=25?2:abs7<=40?1:0);
                                if(Double.isFinite(rsi)&&(rsi>78||rsi<22))timing=Math.max(0,timing-1);
                                int pre=o.optInt("eligibilityScore")+o.optInt("liquidityScore")+o.optInt("activityScore")+trendScore+volScore+timing;
                                o.put("trendScore",trendScore);o.put("volumeExpansionScore",volScore);o.put("timingScore",timing);
                                o.put("preScore",Math.min(30,pre));o.put("return7d",r7);o.put("return30d",r30);
                                o.put("volumeRatio20d",vr);o.put("rsi14",rsi);o.put("trendState",trend);
                                o.put("screenCoverage","TICKER+1D_60");
                                o.put("fomoRisk",(Double.isFinite(r7)&&r7>35)||(Math.abs(o.optDouble("change24"))>15)||(Double.isFinite(rsi)&&rsi>80));
                                enriched++;
                            }
                        }catch(Exception ignored){enrichmentFailed++;}
                    }
                    candidates.sort((a, b) -> {
                        int sc = Integer.compare(b.optInt("preScore"), a.optInt("preScore"));
                        if (sc != 0) return sc;
                        return Double.compare(b.optDouble("quoteVolume24"), a.optDouble("quoteVolume24"));
                    });

                    JSONArray outItems = new JSONArray();
                    for (int i = 0; i < Math.min(max, candidates.size()); i++) outItems.put(candidates.get(i));

                    JSONObject out = new JSONObject();
                    out.put("ok", true);
                    out.put("requestId", requestId);
                    out.put("items", outItems);
                    out.put("rejected", rejected);
                    out.put("totalEligible", candidates.size());
                    out.put("rawTradingSpot", rawTradingSpot);
                    out.put("universeSize", universe.size());
                    out.put("belowVolume", belowVolume);
                    out.put("excludedStable", excludedStable);
                    out.put("excludedWrapped", excludedWrapped);
                    out.put("excludedMeme", excludedMeme);
                    out.put("excludedSector", excludedSector);
                    out.put("sectorFilter", wantedSector);
                    out.put("minQuoteVolumeUsd", minVol);
                    out.put("batchRequests", batchRequests);
                    out.put("fallbackRequests", fallbackRequests); out.put("enrichedCandles", enriched); out.put("enrichmentFailed", enrichmentFailed);
                    out.put("scoreType", "RESEARCH PRIORITY /30 = Spot 6 + Liquidity 8 + Activity 4 + Trend/RS 6 + Volume expansion 3 + Timing/FOMO 3 · KHÔNG phải investment score");
                    out.put("source", "Binance exchangeInfo + Spot 24hr ticker + bounded 1D kline enrichment");
                    out.put("sourceUrl", exchangeUrl);
                    out.put("updatedAt", isoNow());
                    send("onSpotScanPayload", out.toString());
                } catch (Exception e) {
                    sendReqError("onSpotScanPayload", requestId, e);
                }
            });
        }

        @JavascriptInterface public void fetchCoinDueDiligence(String requestId, String symbol, String coinGeckoOverride) {
            submitWork(() -> {
                try {
                    String sym = symbol == null ? "" : symbol.trim().toUpperCase(Locale.US).replaceAll("[^A-Z0-9]", "");
                    if (sym.isEmpty()) throw new IllegalArgumentException("Thiếu symbol");
                    String quote = quoteFromSymbol(sym);
                    if (quote.isEmpty()) {
                        sym += "USDT";
                        quote = "USDT";
                    }
                    String base = sym.substring(0, sym.length() - quote.length());

                    JSONObject out = new JSONObject();
                    out.put("ok", true);
                    out.put("requestId", requestId);
                    out.put("symbol", sym);
                    out.put("base", base);
                    out.put("quote", quote);
                    out.put("updatedAt", isoNow());

                    // 1) Binance Spot fact: selected pair only.
                    JSONObject ticker = httpJson("https://data-api.binance.vision/api/v3/ticker/24hr?symbol=" +
                            URLEncoder.encode(sym, "UTF-8") + "&symbolStatus=TRADING");
                    JSONObject spot = new JSONObject();
                    double spotPrice = parseDoubleSafe(ticker.optString("lastPrice", "0"));
                    spot.put("price", spotPrice);
                    spot.put("change24", parseDoubleSafe(ticker.optString("priceChangePercent", "0")));
                    spot.put("quoteVolume24", parseDoubleSafe(ticker.optString("quoteVolume", "0")));
                    spot.put("trades24", ticker.optLong("count", 0L));
                    spot.put("high24", parseDoubleSafe(ticker.optString("highPrice", "0")));
                    spot.put("low24", parseDoubleSafe(ticker.optString("lowPrice", "0")));
                    spot.put("sourceTimestamp", ticker.optLong("closeTime", 0L));
                    out.put("spot", spot);

                    // 2) Order book: selected coin only.
                    try {
                        JSONObject book = httpJson("https://data-api.binance.vision/api/v3/depth?symbol=" +
                                URLEncoder.encode(sym, "UTF-8") + "&limit=500");
                        JSONArray bids = book.optJSONArray("bids"), asks = book.optJSONArray("asks");
                        double bestBid = bookPrice(bids, 0), bestAsk = bookPrice(asks, 0);
                        JSONObject depth = new JSONObject();
                        if (bestBid > 0 && bestAsk > 0) {
                            double mid = (bestBid + bestAsk) / 2.0;
                            depth.put("bestBid", bestBid);
                            depth.put("bestAsk", bestAsk);
                            depth.put("spreadBps", (bestAsk - bestBid) / mid * 10000.0);
                            depth.put("bid05", depthUsd(bids, mid * 0.995, true));
                            depth.put("ask05", depthUsd(asks, mid * 1.005, false));
                            depth.put("bid1", depthUsd(bids, mid * 0.99, true));
                            depth.put("ask1", depthUsd(asks, mid * 1.01, false));
                            depth.put("bid2", depthUsd(bids, mid * 0.98, true));
                            depth.put("ask2", depthUsd(asks, mid * 1.02, false));
                        }
                        out.put("depth", depth);
                    } catch (Exception ignored) {}

                    // 3) Spot multi-timeframe technical evidence: never infer chart without candles.
                    try {
                        out.put("technical", fetchSpotTechnical(sym));
                    } catch (Exception ignored) {}

                    // 4) CoinGecko identity resolver. Ambiguous ticker => STOP contract/fundamental mapping.
                    String override = coinGeckoOverride == null ? "" : coinGeckoOverride.trim().toLowerCase(Locale.US);
                    String cgId = "";
                    JSONObject identity = null;

                    try {
                        if (!override.isEmpty()) {
                            JSONObject detail = httpJson("https://api.coingecko.com/api/v3/coins/" +
                                    URLEncoder.encode(override, "UTF-8") +
                                    "?localization=false&tickers=false&market_data=false&community_data=false&developer_data=false&sparkline=false");
                            String ds = detail.optString("symbol", "").toUpperCase(Locale.US);
                            if (!base.equalsIgnoreCase(ds)) {
                                identity = new JSONObject().put("status", "OVERRIDE_MISMATCH")
                                        .put("requestedId", override).put("expectedSymbol", base).put("actualSymbol", ds);
                            } else {
                                cgId = override;
                                identity = resolveProjectIdentity(base, cgId, detail);
                                identity.put("identityConfidence", "MANUAL_OVERRIDE");
                            }
                        } else {
                            JSONObject search = httpJson("https://api.coingecko.com/api/v3/search?query=" + URLEncoder.encode(base, "UTF-8"));
                            JSONArray coins = search.optJSONArray("coins");
                            JSONArray exact = new JSONArray();
                            if (coins != null) for (int i = 0; i < coins.length(); i++) {
                                JSONObject c = coins.optJSONObject(i);
                                if (c == null || !base.equalsIgnoreCase(c.optString("symbol", ""))) continue;
                                exact.put(new JSONObject()
                                        .put("id", c.optString("id", ""))
                                        .put("name", c.optString("name", ""))
                                        .put("rank", c.isNull("market_cap_rank") ? JSONObject.NULL : c.opt("market_cap_rank")));
                            }

                            if (exact.length() == 1) {
                                cgId = exact.getJSONObject(0).optString("id", "");
                                JSONObject detail = httpJson("https://api.coingecko.com/api/v3/coins/" +
                                        URLEncoder.encode(cgId, "UTF-8") +
                                        "?localization=false&tickers=false&market_data=false&community_data=false&developer_data=false&sparkline=false");
                                identity = resolveProjectIdentity(base, cgId, detail);
                                identity.put("identityConfidence", "HIGH_EXACT_SYMBOL_UNIQUE");
                            } else if (exact.length() > 1) {
                                identity = new JSONObject();
                                identity.put("status", "AMBIGUOUS");
                                identity.put("identityConfidence", "LOW");
                                identity.put("symbol", base);
                                identity.put("exactMatches", exact.length());
                                identity.put("candidates", exact);
                                identity.put("scopeNote", "Nhiều CoinGecko ID có cùng ticker. Không tự chọn project/contract.");
                            } else {
                                identity = new JSONObject().put("status", "UNKNOWN")
                                        .put("identityConfidence", "NONE").put("symbol", base);
                            }
                        }
                    } catch (Exception e) {
                        identity = new JSONObject().put("status", "SOURCE_UNAVAILABLE")
                                .put("identityConfidence", "NONE").put("error", safeMsg(e));
                    }
                    if (identity != null) out.put("identity", identity);

                    // Only use CoinGecko market/fundamental mapping after identity is unambiguous.
                    if (!cgId.isEmpty() && identity != null &&
                            !"AMBIGUOUS".equals(identity.optString("status")) &&
                            !"OVERRIDE_MISMATCH".equals(identity.optString("status"))) {
                        try {
                            JSONArray ma = httpJsonArray("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=" +
                                    URLEncoder.encode(cgId, "UTF-8") +
                                    "&sparkline=false&price_change_percentage=7d,30d");
                            if (ma.length() > 0) {
                                JSONObject m = ma.getJSONObject(0);
                                JSONObject token = new JSONObject();
                                token.put("coinGeckoId", cgId);
                                token.put("name", m.optString("name", base));
                                putFinite(token, "marketCap", m.optDouble("market_cap", Double.NaN));
                                putFinite(token, "fdv", m.optDouble("fully_diluted_valuation", Double.NaN));
                                putFinite(token, "circulatingSupply", m.optDouble("circulating_supply", Double.NaN));
                                putFinite(token, "totalSupply", m.optDouble("total_supply", Double.NaN));
                                putFinite(token, "maxSupply", m.optDouble("max_supply", Double.NaN));
                                putFinite(token, "change7d", m.optDouble("price_change_percentage_7d_in_currency", Double.NaN));
                                putFinite(token, "change30d", m.optDouble("price_change_percentage_30d_in_currency", Double.NaN));
                                double mc = m.optDouble("market_cap", Double.NaN), fdv = m.optDouble("fully_diluted_valuation", Double.NaN);
                                if (Double.isFinite(mc) && Double.isFinite(fdv) && fdv > 0) token.put("mcFdv", mc / fdv);
                                token.put("marketCapRank", m.optInt("market_cap_rank", 0));
                                token.put("sourceUrl", "https://www.coingecko.com/en/coins/" + cgId);
                                out.put("token", token);
                            }
                        } catch (Exception ignored) {}
                    }

                    // 5) Derivatives context only. Futures never substitutes for Spot.
                    try {
                        String perpSym = base + "USDT";
                        JSONObject prem = httpJson("https://fapi.binance.com/fapi/v1/premiumIndex?symbol=" + URLEncoder.encode(perpSym, "UTF-8"));
                        JSONObject oi = httpJson("https://fapi.binance.com/fapi/v1/openInterest?symbol=" + URLEncoder.encode(perpSym, "UTF-8"));
                        JSONObject deriv = new JSONObject();
                        deriv.put("fundingRate", parseDoubleSafe(prem.optString("lastFundingRate", "0")));
                        deriv.put("markPrice", parseDoubleSafe(prem.optString("markPrice", "0")));
                        deriv.put("openInterest", parseDoubleSafe(oi.optString("openInterest", "0")));
                        deriv.put("sourceUrl", "https://www.binance.com/en/futures/" + perpSym);
                        out.put("derivatives", deriv);
                    } catch (Exception ignored) {}

                    // 6) DefiLlama dynamic mapping by gecko_id, not hard-coded ticker list.
                    if (!cgId.isEmpty()) {
                        String llamaSlug = findDefiLlamaSlug(cgId, base);
                        if (!llamaSlug.isEmpty()) {
                            try {
                                JSONObject eco = fetchProtocolEconomics(llamaSlug);
                                if (out.has("token")) {
                                    double mc = out.getJSONObject("token").optDouble("marketCap", Double.NaN);
                                    double rev30 = eco.optDouble("revenue30d", Double.NaN);
                                    if (Double.isFinite(mc) && Double.isFinite(rev30) && rev30 > 0) {
                                        eco.put("mcAnnualizedRevenue", mc / (rev30 / 30.0 * 365.0));
                                    }
                                }
                                out.put("economics", eco);
                            } catch (Exception e) {
                                out.put("economics", new JSONObject().put("status", "SOURCE_UNAVAILABLE")
                                        .put("slug", llamaSlug).put("error", safeMsg(e)));
                            }
                        } else {
                            // Native L1/L2 assets often map to a chain, not to a DefiLlama protocol.
                            // Chain TVL is ecosystem context only; it is NOT protocol revenue/value capture.
                            try {
                                JSONObject chainCtx = findDefiLlamaChainContext(cgId);
                                if (chainCtx != null) out.put("economics", chainCtx);
                                else out.put("economics", new JSONObject().put("status", "NO_GECKO_ID_MAPPING"));
                            } catch (Exception e) {
                                out.put("economics", new JSONObject().put("status", "NO_GECKO_ID_MAPPING")
                                        .put("error", safeMsg(e)));
                            }
                        }
                    }

                    // 7) GoPlus security only when project identity/contract is unambiguous.
                    if (identity != null && !"AMBIGUOUS".equals(identity.optString("status"))) {
                        String chainId = identity.optString("goPlusChainId", "");
                        String contract = identity.optString("selectedContract", "");
                        if (!chainId.isEmpty() && !contract.isEmpty()) {
                            try {
                                JSONObject sec = fetchGoPlusSecurity(chainId, contract, spotPrice);
                                out.put("security", sec);
                                if (sec.has("unlockEvidence")) out.put("unlockEvidence", sec.optJSONObject("unlockEvidence"));
                            } catch (Exception e) {
                                out.put("security", new JSONObject()
                                        .put("status", safeMsg(e).contains("401") || safeMsg(e).contains("403") ? "AUTH_REQUIRED" : "SOURCE_UNAVAILABLE")
                                        .put("scope", identity.optString("selectedPlatform", "") + " contract")
                                        .put("error", safeMsg(e))
                                        .put("sourceUrl", "https://docs.gopluslabs.io/reference/tokensecurityusingget_1"));
                            }
                        } else if (identity.optBoolean("nativeAsset", false)) {
                            out.put("security", new JSONObject().put("status", "NATIVE_ASSET")
                                    .put("scope", "Không có EVM token contract để áp dụng GoPlus Token Security."));
                        }
                    }

                    JSONArray sources = new JSONArray();
                    sources.put(new JSONObject().put("tier","A").put("name","Binance Spot")
                            .put("url","https://www.binance.com/en/trade/"+base+"_"+quote+"?type=spot"));
                    sources.put(new JSONObject().put("tier","A").put("name","Binance Spot API")
                            .put("url","https://developers.binance.com/en/docs/catalog/core-trading-spot-trading/api/rest-api/market"));
                    if (out.has("token")) sources.put(new JSONObject().put("tier","B").put("name","CoinGecko")
                            .put("url",out.getJSONObject("token").optString("sourceUrl")));
                    if (identity != null) {
                        String home = identity.optString("homepage", "");
                        if (!home.isEmpty()) sources.put(new JSONObject().put("tier","A").put("name","Official project").put("url",home));
                        String repo = identity.optString("github", "");
                        if (!repo.isEmpty()) sources.put(new JSONObject().put("tier","A").put("name","Official GitHub").put("url",repo));
                    }
                    if (out.has("economics") && !out.getJSONObject("economics").optString("slug","").isEmpty()) {
                        String slug = out.getJSONObject("economics").optString("slug");
                        sources.put(new JSONObject().put("tier","B").put("name","DefiLlama economics")
                                .put("url","https://defillama.com/protocol/"+slug));
                    }
                    if (out.has("security")) sources.put(new JSONObject().put("tier","B").put("name","GoPlus Security")
                            .put("url","https://docs.gopluslabs.io/reference/tokensecurityusingget_1"));
                    out.put("sources", sources);

                    JSONObject coverage = new JSONObject();
                    coverage.put("binanceSpot", spotPrice > 0);
                    coverage.put("liquidity", out.has("depth"));
                    coverage.put("technical", out.has("technical"));
                    coverage.put("marketCapFdvSupply", out.has("token"));
                    coverage.put("identity", identity != null &&
                            ("CONTRACT_RESOLVED".equals(identity.optString("status")) || "NATIVE_ASSET".equals(identity.optString("status"))));
                    coverage.put("identityAmbiguous", identity != null && "AMBIGUOUS".equals(identity.optString("status")));
                    coverage.put("derivatives", out.has("derivatives"));
                    coverage.put("economics", out.has("economics") && "OK".equals(out.getJSONObject("economics").optString("status")));
                    coverage.put("securityAuto", out.has("security") && "OK".equals(out.getJSONObject("security").optString("status")));
                    coverage.put("unlockPartial", out.has("unlockEvidence") &&
                            out.getJSONObject("unlockEvidence").optInt("records",0) > 0);
                    coverage.put("unlockVerifiedFull", false);
                    coverage.put("productUsage", false);
                    coverage.put("narrativeFlow", false);
                    coverage.put("catalystNews", false);
                    coverage.put("teamBacker", false);
                    coverage.put("specialRisk", false);
                    coverage.put("riskPlan", false);
                    coverage.put("finalInvestmentScoreAllowed", false);
                    out.put("coverage", coverage);

                    send("onCoinDueDiligencePayload", out.toString());
                } catch (Exception e) {
                    sendReqError("onCoinDueDiligencePayload", requestId, e);
                }
            });
        }

        @JavascriptInterface public void researchCoinWithAi(String requestId, String contextJson) {
            submitWork(() -> {
                try {
                    AiCfg cfg = getAiCfg();
                    JSONObject p = new JSONObject();
                    p.put("ok", true);
                    p.put("requestId", requestId);

                    String system =
                            "Bạn là senior crypto spot due-diligence analyst. Không bịa, không dùng futures thay spot, không quảng cáo. " +
                            "Phân biệt VERIFIED FACT / SOURCE_BACKED / PARTIAL / UNVERIFIED / INFERENCE. " +
                            "Bắt buộc đối chiếu prompt: Binance Spot; MC/FDV/supply; full unlock 7/30/60/90D; " +
                            "spot volume/spread/depth; product/usage; fees/revenue/value capture; narrative/sector flow; " +
                            "catalyst 7/30/90D; contract/audit/admin/hack/holder concentration; team/backer/ecosystem; " +
                            "spot chart/timing; special/legal/monitoring risks; market regime; invalidation và risk plan. " +
                            "Không đủ full unlock/news/risk/action/source thì FINAL SCORE phải LOCKED. " +
                            "Mỗi claim thay đổi nhanh phải có ngày/thời gian. Không nói chắc thắng, không all-in. " +
                            "Viết tiếng Việt ngắn theo heading: [GATE 0 HARD REJECT], [FACT CHECK], [TOKENOMICS & UNLOCK], " +
                            "[PRODUCT & VALUE CAPTURE], [LIQUIDITY], [NARRATIVE & SECTOR FLOW], [CATALYST CALENDAR], " +
                            "[SECURITY], [TEAM / BACKER / ECOSYSTEM], [MARKET REGIME & TIMING], [SPECIAL RISK], " +
                            "[STATUS], [INVALIDATION], [RISK PLAN], [SOURCES]. " +
                            "CUỐI CÙNG bắt buộc thêm đúng marker [STRUCTURED_EVIDENCE_JSON], sau đó một JSON object hợp lệ, rồi [/STRUCTURED_EVIDENCE_JSON]. " +
                            "JSON schema: {\"unlock\":{\"status\":\"VERIFIED|PARTIAL|UNVERIFIED\",\"applicability\":\"VESTING|EMISSION_SCHEDULE|NO_SCHEDULED_UNLOCK|UNKNOWN\",\"source_url\":\"\",\"next_date\":\"\",\"schedule_summary\":\"\",\"risk\":\"LOW|MEDIUM|HIGH|UNKNOWN\",\"window_7d\":\"\",\"window_30d\":\"\",\"window_60d\":\"\",\"window_90d\":\"\"}," +
                            "\"product_usage\":{\"status\":\"SOURCE_BACKED|UNVERIFIED\",\"quality\":\"STRONG|MEDIUM|WEAK|UNKNOWN\",\"summary\":\"\",\"source_url\":\"\"}," +
                            "\"economics_context\":{\"status\":\"SOURCE_BACKED|UNVERIFIED\",\"quality\":\"STRONG|MEDIUM|WEAK|UNKNOWN\",\"scope\":\"PROTOCOL|NETWORK|TOKEN|UNKNOWN\",\"summary\":\"\",\"source_url\":\"\"}," +
                            "\"narrative\":{\"status\":\"SOURCE_BACKED|UNVERIFIED\",\"quality\":\"STRONG|MEDIUM|WEAK|UNKNOWN\",\"sector\":\"\",\"summary\":\"\",\"source_url\":\"\"}," +
                            "\"catalyst\":{\"status\":\"SOURCE_BACKED|UNVERIFIED\",\"quality\":\"STRONG|MEDIUM|WEAK|UNKNOWN\",\"items\":[{\"date\":\"\",\"event\":\"\",\"impact\":\"POSITIVE|NEGATIVE|MIXED\",\"source_url\":\"\"}]}," +
                            "\"security_context\":{\"status\":\"SOURCE_BACKED|UNVERIFIED\",\"quality\":\"STRONG|MEDIUM|WEAK|UNKNOWN\",\"summary\":\"\",\"source_url\":\"\"}," +
                            "\"team_backer\":{\"status\":\"SOURCE_BACKED|UNVERIFIED\",\"quality\":\"STRONG|MEDIUM|WEAK|UNKNOWN\",\"summary\":\"\",\"source_url\":\"\"}," +
                            "\"special_risk\":{\"status\":\"SOURCE_BACKED|UNVERIFIED\",\"severity\":\"LOW|MEDIUM|HIGH|UNKNOWN\",\"summary\":\"\",\"source_url\":\"\"}," +
                            "\"hard_reject\":{\"status\":\"YES|NO|UNKNOWN\",\"reasons\":[]}," +
                            "\"invalidation\":\"\",\"risk_plan\":\"\"}. " +
                            "Không dùng markdown fence cho JSON.";

                    if ("GEMINI".equals(cfg.provider)) {
                        JSONObject g = callGeminiGrounded(cfg, system,
                                "Dữ liệu tự động từ MarketOS:\n" + (contextJson == null ? "{}" : contextJson) +
                                "\n\nResearch web mới nhất để hoàn thiện các trường thiếu. Full unlock phải dùng nguồn vesting/unlock hoặc tài liệu chính thức; " +
                                "không suy từ GoPlus top-holder lock. News/catalyst phải có ngày và nguồn.");
                        String full = g.optString("text", "");
                        JSONObject ev = extractAndValidateCoinEvidence(full, g.optJSONArray("sources"), contextJson);
                        p.put("provider", "Gemini Grounded Search · " + g.optString("model"));
                        p.put("analysisText", stripStructuredEvidence(full));
                        p.put("sources", g.optJSONArray("sources"));
                        p.put("evidence", ev);
                    } else {
                        String text = callAi(cfg,
                                system,
                                "Dữ liệu MarketOS:\n" + (contextJson == null ? "{}" : contextJson) +
                                "\n\nProvider này không có web grounding. Chỉ diễn giải dữ liệu đã cung cấp. Mọi trường bên ngoài phải UNVERIFIED.",
                                0.10);
                        p.put("provider", cfg.provider + " · NO WEB GROUNDING");
                        p.put("analysisText", stripStructuredEvidence(text));
                        p.put("sources", new JSONArray());
                        p.put("evidence", new JSONObject().put("validationNote",
                                "Provider không có web grounding; evidence ngoài automatic facts không được phép đóng gate."));
                    }
                    send("onCoinResearchPayload", p.toString());
                } catch (Exception e) {
                    sendReqError("onCoinResearchPayload", requestId, e);
                }
            });
        }


        @JavascriptInterface public void refreshCryptoLiquidity() {
            submitUnique("defillama-stablecoins", () -> {
                try {
                    JSONObject raw = httpJson("https://stablecoins.llama.fi/stablecoins?includePrices=true");
                    JSONArray assets = raw.optJSONArray("peggedAssets");
                    double now = 0.0, prevDay = 0.0, prevWeek = 0.0, prevMonth = 0.0;
                    int counted = 0;
                    if (assets != null) for (int i = 0; i < assets.length(); i++) {
                        JSONObject a = assets.optJSONObject(i);
                        if (a == null) continue;
                        double n = stableUsd(a.optJSONObject("circulating"));
                        double d = stableUsd(a.optJSONObject("circulatingPrevDay"));
                        double w = stableUsd(a.optJSONObject("circulatingPrevWeek"));
                        double m = stableUsd(a.optJSONObject("circulatingPrevMonth"));
                        if (n > 0) { now += n; counted++; }
                        if (d > 0) prevDay += d;
                        if (w > 0) prevWeek += w;
                        if (m > 0) prevMonth += m;
                    }
                    JSONObject p = new JSONObject();
                    p.put("ok", now > 0);
                    p.put("currentUsd", now);
                    p.put("change1dPct", prevDay > 0 ? (now / prevDay - 1.0) * 100.0 : JSONObject.NULL);
                    p.put("change7dPct", prevWeek > 0 ? (now / prevWeek - 1.0) * 100.0 : JSONObject.NULL);
                    p.put("change30dPct", prevMonth > 0 ? (now / prevMonth - 1.0) * 100.0 : JSONObject.NULL);
                    p.put("assetsCount", counted);
                    p.put("source", "DefiLlama Stablecoins");
                    p.put("sourceUrl", "https://defillama.com/stablecoins");
                    p.put("updatedAt", isoNow());
                    send("onCryptoLiquidityPayload", p.toString());
                } catch (Exception e) {
                    sendError("onCryptoLiquidityPayload", e);
                }
            });
        }

        @JavascriptInterface public void refreshMarketSnapshot() {
            submitWork(() -> {
                JSONObject out=new JSONObject();
                try {
                    out.put("ok",true); out.put("updatedAt",isoNow());
                    try {
                        JSONObject y=httpJson("https://query1.finance.yahoo.com/v8/finance/chart/GC%3DF?interval=1m&range=1d");
                        JSONObject chart=y.getJSONObject("chart"); JSONArray result=chart.optJSONArray("result");
                        if(result!=null&&result.length()>0){
                            JSONObject meta=result.getJSONObject(0).optJSONObject("meta");
                            if(meta!=null){
                                double px=meta.optDouble("regularMarketPrice",Double.NaN);
                                double prev=meta.optDouble("chartPreviousClose",meta.optDouble("previousClose",Double.NaN));
                                if(Double.isFinite(px)){out.put("goldOk",true);out.put("gold",px);if(Double.isFinite(prev)&&prev!=0)out.put("goldPct",(px/prev-1.0)*100.0);}
                                out.put("goldTs",meta.optLong("regularMarketTime",0));
                                out.put("goldSource","Yahoo Finance · COMEX Gold futures GC=F · delayed/near-live");
                                out.put("goldSourceUrl","https://finance.yahoo.com/quote/GC%3DF/");
                            }
                        }
                    } catch(Exception ge){out.put("goldOk",false);out.put("goldError",String.valueOf(ge.getMessage()));}
                    send("onMarketSnapshotPayload",out.toString());
                } catch(Exception e){sendError("onMarketSnapshotPayload",e);}
            });
        }

        @JavascriptInterface public void fetchCryptoCandles(String requestId,String coinId,String symbol,String interval) {
            submitWork(() -> {
                try {
                    String iv=interval==null?"1h":interval.trim();
                    if(!Arrays.asList("1h","4h","1w","1M").contains(iv)) iv="1h";
                    String sym=(symbol==null?"":symbol.trim().toUpperCase(Locale.US)).replaceAll("[^A-Z0-9]","");
                    if(sym.isEmpty()) throw new IllegalArgumentException("Thiếu symbol");
                    if(!sym.endsWith("USDT")) sym += "USDT";
                    String url="https://api.binance.com/api/v3/klines?symbol="+URLEncoder.encode(sym,"UTF-8")+"&interval="+URLEncoder.encode(iv,"UTF-8")+"&limit=240";
                    JSONArray rows=httpJsonArray(url); JSONArray candles=new JSONArray();
                    for(int i=0;i<rows.length();i++){
                        JSONArray a=rows.getJSONArray(i); JSONObject c=new JSONObject();
                        c.put("t",a.getLong(0));c.put("o",Double.parseDouble(a.getString(1)));c.put("h",Double.parseDouble(a.getString(2)));c.put("l",Double.parseDouble(a.getString(3)));c.put("c",Double.parseDouble(a.getString(4)));c.put("v",Double.parseDouble(a.getString(5)));candles.put(c);
                    }
                    JSONObject p=new JSONObject();p.put("ok",true);p.put("requestId",requestId);p.put("coinId",coinId);p.put("symbol",sym);p.put("interval",iv);p.put("candles",candles);p.put("source","Binance Spot market data");p.put("sourceUrl","https://www.binance.com/en/trade/"+sym.replace("USDT","_USDT")+"?type=spot");p.put("updatedAt",isoNow());send("onCryptoCandlesPayload",p.toString());
                }catch(Exception e){sendReqError("onCryptoCandlesPayload",requestId,e);}
            });
        }

        @JavascriptInterface public void researchMarketWithAi(String requestId,String contextJson) {
            submitWork(() -> {
                try {
                    AiCfg cfg=getAiCfg();
                    String sys="Bạn là senior macro/cross-asset research analyst. Phân biệt FACT và INFERENCE, không bịa số liệu, ưu tiên primary/official source. Trả lời NGẮN, quyết định-first, mỗi mục tối đa 3 bullet. BẮT BUỘC dùng đúng các heading trên dòng riêng: [TÓM TẮT], [DÒNG TIỀN], [RATES & CREDIT], [GROWTH & INFLATION], [CROSS-ASSET], [CATALYST 7D], [BULL / BASE / BEAR], [TRIGGER], [INVALIDATION], [TAIL RISK]. TÓM TẮT phải nói rõ posture, risk budget tương đối và điều kiện đổi bias. Nếu có web grounding phải nêu nguồn; nếu không chắc phải ghi UNKNOWN.";
                    JSONObject p=new JSONObject();p.put("ok",true);p.put("requestId",requestId);
                    if("GEMINI".equals(cfg.provider)){
                        JSONObject g=callGeminiGrounded(cfg,sys,"Dữ liệu nội bộ Market OS:\n"+(contextJson==null?"{}":contextJson)+"\n\nHãy research thêm thông tin mới nhất cần thiết để fact-check và đánh giá regime.");
                        p.put("provider","Gemini Grounded Search · "+g.optString("model"));p.put("analysisText",g.optString("text"));p.put("sources",g.optJSONArray("sources"));
                    } else {
                        p.put("provider",cfg.provider+" · không web-grounding");p.put("analysisText",callAi(cfg,sys,"Dữ liệu Market OS:\n"+contextJson,0.08));p.put("sources",new JSONArray());
                    }
                    send("onMarketResearchPayload",p.toString());
                }catch(Exception e){sendReqError("onMarketResearchPayload",requestId,e);}
            });
        }

        @JavascriptInterface public void openExternal(String url) {
            try {
                Uri u=Uri.parse(url);
                if ("https".equalsIgnoreCase(u.getScheme()) && u.getHost()!=null) {
                    // External sources always open in the system browser, never inside the privileged app WebView.
                    startActivity(new Intent(Intent.ACTION_VIEW,u));
                }
            } catch(Exception ignored) {}
        }
    }

    private String translateChunks(String text) throws Exception {
        String normalized=text.replace("\r","").trim();
        List<String> chunks=new ArrayList<>(); int start=0;
        while(start<normalized.length()){
            int end=Math.min(start+2800,normalized.length());
            if(end<normalized.length()){
                int cut=Math.max(normalized.lastIndexOf(". ",end), normalized.lastIndexOf("\n",end));
                if(cut>start+1200) end=cut+1;
            }
            chunks.add(normalized.substring(start,end).trim()); start=end;
        }
        StringBuilder out=new StringBuilder();
        for(String c:chunks){ if(c.isEmpty())continue; String t=Tasks.await(enViTranslator.translate(c),45,TimeUnit.SECONDS); if(out.length()>0)out.append("\n\n");out.append(t); }
        return out.toString();
    }

    private static class AiCfg { String provider, endpoint, model, key; }

    private static final String KEYSTORE_ALIAS="MarketOS_AI_KEY_V1";
    private boolean hasStoredAiKey(){try{return !getStoredAiKey().isEmpty();}catch(Exception e){return false;}}
    private String getStoredAiKey() throws Exception {
        String enc=prefs.getString("ai_key_secure","");
        if(!enc.isEmpty()) return decryptSecret(enc);
        String legacy=prefs.getString("ai_key","");
        if(!legacy.isEmpty()){prefs.edit().putString("ai_key_secure",encryptSecret(legacy)).remove("ai_key").apply();return legacy;}
        return "";
    }
    private SecretKey getOrCreateSecretKey() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(ks.containsAlias(KEYSTORE_ALIAS)) return ((KeyStore.SecretKeyEntry)ks.getEntry(KEYSTORE_ALIAS,null)).getSecretKey();
        KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(KEYSTORE_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return kg.generateKey();
    }
    private String encryptSecret(String plain) throws Exception {if(plain==null||plain.isEmpty())return"";Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,getOrCreateSecretKey());byte[] iv=c.getIV(),ct=c.doFinal(plain.getBytes(StandardCharsets.UTF_8));return Base64.encodeToString(iv,Base64.NO_WRAP)+"."+Base64.encodeToString(ct,Base64.NO_WRAP);}
    private String decryptSecret(String enc) throws Exception {String[] a=enc.split("\\.",2);if(a.length!=2)throw new IllegalStateException("Secret format invalid");byte[] iv=Base64.decode(a[0],Base64.NO_WRAP),ct=Base64.decode(a[1],Base64.NO_WRAP);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,getOrCreateSecretKey(),new GCMParameterSpec(128,iv));return new String(c.doFinal(ct),StandardCharsets.UTF_8);}

    private AiCfg getAiCfg() throws Exception {
        AiCfg c=new AiCfg(); c.provider=prefs.getString("ai_provider","GEMINI").trim().toUpperCase(Locale.US);
        c.endpoint=prefs.getString("ai_endpoint","").trim(); c.model=prefs.getString("ai_model","").trim(); c.key=getStoredAiKey().trim();
        if(c.key.isEmpty()) throw new IllegalStateException("Chưa có API key");
        if(c.provider.equals("GROQ_FREE")){
            if(c.endpoint.isEmpty()) c.endpoint="https://api.groq.com/openai/v1/chat/completions";
            if(c.model.isEmpty()||c.model.equalsIgnoreCase("AUTO")) c.model="openai/gpt-oss-20b";
        } else if(c.provider.equals("OPENROUTER_FREE")){
            if(c.endpoint.isEmpty()) c.endpoint="https://openrouter.ai/api/v1/chat/completions";
            if(c.model.isEmpty()||c.model.equalsIgnoreCase("AUTO")) c.model="openrouter/free";
        } else if(c.model.isEmpty()) c.model=c.provider.equals("GEMINI")?"AUTO":"openai/gpt-oss-20b";
        if(c.provider.equals("AUTO")) c.provider=(c.model.equalsIgnoreCase("AUTO") || c.model.toLowerCase(Locale.US).startsWith("gemini-") || c.endpoint.isEmpty() || c.endpoint.contains("generativelanguage.googleapis.com"))?"GEMINI":"OPENAI_COMPATIBLE";
        if(c.provider.equals("GROQ_FREE")||c.provider.equals("OPENROUTER_FREE")) c.provider="OPENAI_COMPATIBLE";
        return c;
    }

    private String callAi(AiCfg cfg,String system,String user,double temperature) throws Exception {
        if("GEMINI".equals(cfg.provider)) return callGemini(cfg,user,system,temperature);
        return callOpenAiCompatible(cfg,user,system,temperature);
    }

    private String callGemini(AiCfg cfg,String user,String system,double temperature) throws Exception {
        LinkedHashSet<String> models=new LinkedHashSet<>();
        String requested=cfg.model==null?"":cfg.model.trim();
        boolean auto=requested.isEmpty()||requested.equalsIgnoreCase("AUTO")||requested.equalsIgnoreCase("LATEST");
        if(!auto) models.add(requested.replace("models/",""));
        // Current stable Flash ladder. If Google retires one model, 404 automatically falls through.
        models.add("gemini-3.8-flash");
        models.add("gemini-3.7-flash");
        models.add("gemini-3.6-flash");
        models.add("gemini-3.5-flash");
        Exception last=null;
        for(String model:models){
            try {
                String out=callGeminiModelResilient(cfg,model,user,system,temperature);
                cfg.model=model;
                prefs.edit().putString("ai_last_model",model).apply();
                return out;
            } catch(Exception e){
                last=e;
                String m=String.valueOf(e.getMessage()).toLowerCase(Locale.US);
                // 404 = model retired/unavailable; 503/5xx = temporary capacity/server issue.
                // After bounded retries on the same model, continue down the stable model ladder.
                boolean fallback=m.contains("http 404")||m.contains("not_found")||m.contains("no longer available")||
                        m.contains("http 503")||m.contains("unavailable")||m.contains("http 500")||
                        m.contains("http 502")||m.contains("http 504");
                if(!fallback) throw e;
            }
        }
        throw new IllegalStateException("Gemini tạm thời không có model khả dụng. App đã thử các model dự phòng. "+(last==null?"":friendlyAiError(last)));
    }


    private String callGeminiModelResilient(AiCfg cfg,String model,String user,String system,double temperature) throws Exception {
        Exception last=null;
        long[] waits={900L,1800L,3600L};
        for(int attempt=0;attempt<waits.length;attempt++){
            try { return callGeminiModel(cfg,model,user,system,temperature); }
            catch(Exception e){
                last=e; String m=String.valueOf(e.getMessage()).toLowerCase(Locale.US);
                boolean retryable=m.contains("http 500")||
                        m.contains("http 502")||m.contains("http 503")||m.contains("http 504")||m.contains("unavailable")||m.contains("timeout");
                if(!retryable || attempt==waits.length-1) throw e;
                long jitter=(long)(Math.random()*350L);
                try { Thread.sleep(waits[attempt]+jitter); } catch(InterruptedException ie){Thread.currentThread().interrupt();throw e;}
            }
        }
        throw last==null?new IllegalStateException("Gemini unavailable"):last;
    }

    private String callGeminiModel(AiCfg cfg,String model,String user,String system,double temperature) throws Exception {
        String ep=cfg.endpoint;
        if(ep!=null&&!ep.isEmpty()){try{Uri u=Uri.parse(ep);if(u.getHost()==null||!u.getHost().equalsIgnoreCase("generativelanguage.googleapis.com"))ep="";}catch(Exception e){ep="";}}
        // A custom Gemini endpoint is accepted only as a base; the selected model is always injected here.
        if(ep==null||ep.isEmpty()||ep.contains("/models/")) ep="https://generativelanguage.googleapis.com/v1beta/models/"+URLEncoder.encode(model,"UTF-8")+":generateContent";
        else { if(ep.endsWith("/")) ep=ep.substring(0,ep.length()-1); ep=ep+"/v1beta/models/"+URLEncoder.encode(model,"UTF-8")+":generateContent"; }
        HttpURLConnection c=(HttpURLConnection)new URL(ep).openConnection(); c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setConnectTimeout(15000); c.setReadTimeout(90000); c.setRequestProperty("x-goog-api-key",cfg.key); c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Accept","application/json");c.setRequestProperty("Cache-Control","no-cache, no-store, max-age=0");c.setRequestProperty("Pragma","no-cache");
        JSONObject body=new JSONObject(); JSONArray contents=new JSONArray(); JSONObject content=new JSONObject(); JSONArray parts=new JSONArray();
        parts.put(new JSONObject().put("text", system+"\n\n"+user)); content.put("role","user"); content.put("parts",parts); contents.put(content); body.put("contents",contents);
        body.put("generationConfig",new JSONObject().put("temperature",temperature));
        String raw=postJson(c,body); JSONObject r=new JSONObject(raw); JSONArray cand=r.optJSONArray("candidates");
        if(cand==null||cand.length()==0) throw new IllegalStateException("Gemini không trả về nội dung");
        JSONArray outParts=cand.getJSONObject(0).getJSONObject("content").getJSONArray("parts"); StringBuilder out=new StringBuilder();
        for(int i=0;i<outParts.length();i++){String t=outParts.getJSONObject(i).optString("text","");if(!t.isEmpty()){if(out.length()>0)out.append("\n");out.append(t);}}
        if(out.length()==0) throw new IllegalStateException("Gemini trả về nội dung rỗng"); return out.toString().trim();
    }

    private JSONObject callGeminiGrounded(AiCfg cfg,String system,String user) throws Exception {
        LinkedHashSet<String> models=new LinkedHashSet<>();String requested=cfg.model==null?"":cfg.model.trim();if(!requested.isEmpty()&&!requested.equalsIgnoreCase("AUTO")&&!requested.equalsIgnoreCase("LATEST"))models.add(requested.replace("models/",""));models.add("gemini-3.8-flash");models.add("gemini-3.7-flash");models.add("gemini-3.6-flash");Exception last=null;
        for(String model:models){try{return callGeminiGroundedModel(cfg,model,system,user);}catch(Exception e){last=e;String m=String.valueOf(e.getMessage()).toLowerCase(Locale.US);if(!(m.contains("404")||m.contains("500")||m.contains("502")||m.contains("503")||m.contains("504")||m.contains("unavailable")))throw e;}}
        throw last==null?new IllegalStateException("Grounded research unavailable"):last;
    }

    private JSONObject callGeminiGroundedModel(AiCfg cfg,String model,String system,String user) throws Exception {
        String ep="https://generativelanguage.googleapis.com/v1beta/models/"+URLEncoder.encode(model,"UTF-8")+":generateContent";HttpURLConnection c=(HttpURLConnection)new URL(ep).openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(15000);c.setReadTimeout(90000);c.setRequestProperty("x-goog-api-key",cfg.key);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Accept","application/json");
        JSONObject body=new JSONObject();JSONArray contents=new JSONArray();JSONObject content=new JSONObject();JSONArray parts=new JSONArray();parts.put(new JSONObject().put("text",system+"\n\n"+user));content.put("role","user");content.put("parts",parts);contents.put(content);body.put("contents",contents);body.put("tools",new JSONArray().put(new JSONObject().put("google_search",new JSONObject())));body.put("generationConfig",new JSONObject().put("temperature",0.08));
        String raw=postJson(c,body);JSONObject r=new JSONObject(raw);JSONArray cand=r.optJSONArray("candidates");if(cand==null||cand.length()==0)throw new IllegalStateException("Gemini grounded search không trả nội dung");JSONObject first=cand.getJSONObject(0);JSONArray op=first.getJSONObject("content").getJSONArray("parts");StringBuilder text=new StringBuilder();for(int i=0;i<op.length();i++){String t=op.getJSONObject(i).optString("text","");if(!t.isEmpty()){if(text.length()>0)text.append("\n");text.append(t);}}
        JSONArray sources=new JSONArray();JSONObject gm=first.optJSONObject("groundingMetadata");if(gm!=null){JSONArray chunks=gm.optJSONArray("groundingChunks");if(chunks!=null){LinkedHashSet<String> seen=new LinkedHashSet<>();for(int i=0;i<chunks.length();i++){JSONObject web=chunks.getJSONObject(i).optJSONObject("web");if(web==null)continue;String uri=web.optString("uri","");if(uri.isEmpty()||seen.contains(uri))continue;seen.add(uri);sources.put(new JSONObject().put("title",web.optString("title",uri)).put("url",uri));}}}
        return new JSONObject().put("text",text.toString().trim()).put("sources",sources).put("model",model);
    }

    private String callOpenAiCompatible(AiCfg cfg,String user,String system,double temperature) throws Exception {
        String ep=cfg.endpoint; if(ep==null||ep.isEmpty()) throw new IllegalStateException("Thiếu endpoint OpenAI-compatible");
        HttpURLConnection c=(HttpURLConnection)new URL(ep).openConnection(); c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setConnectTimeout(15000); c.setReadTimeout(90000); c.setRequestProperty("Authorization","Bearer "+cfg.key); c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Accept","application/json");
        JSONObject body=new JSONObject(); body.put("model",cfg.model); body.put("temperature",temperature); JSONArray msgs=new JSONArray();
        msgs.put(new JSONObject().put("role","system").put("content",system)); msgs.put(new JSONObject().put("role","user").put("content",user)); body.put("messages",msgs);
        String raw=postJson(c,body); JSONObject r=new JSONObject(raw); return r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim();
    }

    private String postJson(HttpURLConnection c,JSONObject body) throws Exception {
        byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8); c.setFixedLengthStreamingMode(bytes.length); try(OutputStream os=c.getOutputStream()){os.write(bytes);} int code=c.getResponseCode();
        InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream(); BufferedReader br=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8)); StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null)sb.append(line);br.close();c.disconnect();
        if(code<200||code>=300)throw new IllegalStateException("AI API HTTP "+code+": "+sb.substring(0,Math.min(700,sb.length()))); return sb.toString();
    }

    private String callFaithfulTranslation(AiCfg cfg,String text) throws Exception {
        String norm=text==null?"":text.replace("\r","").trim();
        if(norm.isEmpty()) throw new IllegalArgumentException("Không có văn bản để dịch");
        List<String> chunks=splitText(norm,11000); StringBuilder out=new StringBuilder();
        String sys="Bạn là biên dịch viên tài chính-vĩ mô Anh→Việt. Dịch SÁT NGHĨA toàn bộ nguồn, giữ nguyên số liệu, ngày, tên riêng, thuật ngữ chính sách, mức độ bất định và cấu trúc heading/bullet. Không tóm tắt, không thêm nhận định, không bỏ câu. Với thuật ngữ khó, ưu tiên tiếng Việt chuẩn và có thể giữ thuật ngữ Anh trong ngoặc ở lần xuất hiện đầu.";
        for(String ch:chunks){String t=callAi(cfg,sys,ch,0.05);if(out.length()>0)out.append("\n\n");out.append(t);} return out.toString();
    }

    private List<String> splitText(String text,int max){
        List<String> out=new ArrayList<>();int start=0;
        while(start<text.length()){
            int end=Math.min(start+max,text.length());
            if(end<text.length()){
                int cut=Math.max(text.lastIndexOf("\n\n",end),text.lastIndexOf(". ",end));
                if(cut>start+max/2)end=cut+1;
            }
            out.add(text.substring(start,end).trim());start=end;
        }
        return out;
    }



    private static double stableUsd(JSONObject x) {
        if (x == null) return 0.0;
        if (x.has("peggedUSD")) return x.optDouble("peggedUSD", 0.0);
        double total = 0.0;
        Iterator<String> keys = x.keys();
        while (keys.hasNext()) {
            String k = keys.next();
            Object v = x.opt(k);
            if (v instanceof Number) total += ((Number) v).doubleValue();
        }
        return total;
    }

    private static double parseDoubleSafe(String value) {
        try { return Double.parseDouble(value == null || value.isEmpty() ? "0" : value); }
        catch (Exception e) { return 0.0; }
    }

    private static int quotePreference(String quote) {
        if ("USDT".equals(quote)) return 0;
        if ("USDC".equals(quote)) return 1;
        if ("FDUSD".equals(quote)) return 2;
        return 99;
    }

    private static String quoteFromSymbol(String symbol) {
        if (symbol == null) return "";
        String s = symbol.toUpperCase(Locale.US);
        for (String q : Arrays.asList("FDUSD","USDT","USDC")) if (s.endsWith(q) && s.length() > q.length()) return q;
        return "";
    }

    private static String baseExclusionReason(String base, Set<String> dynamicStable) {
        if (base == null) return "INVALID";
        String b = base.toUpperCase(Locale.US);
        Set<String> stable = new HashSet<>(Arrays.asList(
                "USDT","USDC","FDUSD","TUSD","DAI","USDP","PYUSD","USDS","BUSD","USD1","USDE","USDD",
                "FRAX","LUSD","GUSD","RLUSD","GHO","EURC","EUR","EURI","AEUR","TRY","BRL","GBP","JPY","AUD"));
        if (stable.contains(b) || (dynamicStable != null && dynamicStable.contains(b))) return "STABLE";
        Set<String> wrapped = new HashSet<>(Arrays.asList(
                "WBTC","WETH","WBNB","BTCB","STETH","WSTETH","WBETH","BETH","RETH","CBETH","WEETH","EZETH",
                "SUSDE","SDAI","SFRAX","WUSDM"));
        if (wrapped.contains(b)) return "WRAPPED";
        if (b.endsWith("UP") || b.endsWith("DOWN") || b.endsWith("BULL") || b.endsWith("BEAR")) return "LEVERAGED_TOKEN";
        return "";
    }

    private Set<String> getDynamicStableSymbols() {
        long now = System.currentTimeMillis();
        Set<String> cached = stableSymbolsCache;
        if (cached != null && now - stableSymbolsCacheAt < 6L * 60L * 60L * 1000L) return cached;
        synchronized (this) {
            cached = stableSymbolsCache;
            if (cached != null && now - stableSymbolsCacheAt < 6L * 60L * 60L * 1000L) return cached;
            Set<String> out = new HashSet<>();
            try {
                JSONObject raw = httpJsonBounded("https://stablecoins.llama.fi/stablecoins?includePrices=false", 4_000_000);
                JSONArray arr = raw.optJSONArray("peggedAssets");
                if (arr != null) for (int i=0;i<arr.length();i++) {
                    JSONObject x = arr.optJSONObject(i); if (x == null) continue;
                    String sym = x.optString("symbol","").trim().toUpperCase(Locale.US);
                    if (sym.matches("[A-Z0-9]{2,16}")) out.add(sym);
                }
            } catch (Exception ignored) {}
            out.addAll(Arrays.asList("USDT","USDC","FDUSD","TUSD","DAI","USDP","PYUSD","USDS","BUSD","USD1","USDE","USDD","FRAX","LUSD","GUSD","RLUSD","GHO","EURC"));
            stableSymbolsCache = Collections.unmodifiableSet(out);
            stableSymbolsCacheAt = now;
            return stableSymbolsCache;
        }
    }

    private static String sectorOf(String base) {
        String b = base == null ? "" : base.toUpperCase(Locale.US);
        if (Arrays.asList("DOGE","SHIB","PEPE","WIF","BONK","FLOKI","1000SATS","BOME","MEME","BRETT","TURBO").contains(b)) return "MEME";
        if (Arrays.asList("AAVE","UNI","CRV","COMP","MKR","LDO","PENDLE","SNX","GMX","RUNE","DYDX","ENA","JUP").contains(b)) return "DEFI";
        if (Arrays.asList("BTC","ETH","SOL","SUI","APT","SEI","AVAX","ADA","TRX","TON","NEAR","ATOM","DOT","HBAR","XRP","ALGO","EGLD").contains(b)) return "L1";
        if (Arrays.asList("ARB","OP","STRK","ZK","MANTA","METIS","IMX").contains(b)) return "L2";
        if (Arrays.asList("FET","TAO","RENDER","WLD","ARKM","NEAR","AIOZ").contains(b)) return "AI";
        if (Arrays.asList("ONDO","POLYX","OM","CFG","MPL").contains(b)) return "RWA";
        if (Arrays.asList("FIL","AR","STORJ").contains(b)) return "STORAGE";
        if (Arrays.asList("LINK","PYTH","BAND","API3").contains(b)) return "ORACLE";
        if (Arrays.asList("GALA","SAND","MANA","AXS","RONIN","PIXEL","YGG").contains(b)) return "GAMING";
        if (Arrays.asList("BNB","CRO","OKB","GT").contains(b)) return "EXCHANGE";
        if (Arrays.asList("GRT","TIA","JTO","JUP","STX","THETA","VET","ICP").contains(b)) return "INFRA";
        if (Arrays.asList("ZEC","DASH","XMR").contains(b)) return "PRIVACY";
        if (Arrays.asList("HNT","IOTX","DIMO","AIOZ").contains(b)) return "DEPIN";
        return "UNCLASSIFIED";
    }

    private JSONObject httpJsonBounded(String urlString, int maxChars) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlString).openConnection();
        c.setConnectTimeout(12000); c.setReadTimeout(22000);
        c.setRequestProperty("User-Agent", "MarketOS/26.1 Android");
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("Cache-Control", "no-cache, no-store, max-age=0");
        c.setRequestProperty("Pragma", "no-cache");
        int code = c.getResponseCode();
        String body = readLimited(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream(), maxChars);
        c.disconnect();
        if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + ": " + body.substring(0, Math.min(240, body.length())));
        return new JSONObject(body);
    }

    private JSONArray httpJsonArrayBounded(String urlString, int maxChars) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlString).openConnection();
        c.setConnectTimeout(12000); c.setReadTimeout(22000);
        c.setRequestProperty("User-Agent", "MarketOS/26.1 Android");
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("Cache-Control", "no-cache, no-store, max-age=0");
        int code = c.getResponseCode();
        String body = readLimited(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream(), maxChars);
        c.disconnect();
        if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + ": " + body.substring(0, Math.min(240, body.length())));
        return new JSONArray(body);
    }

    private static double sma(List<Double> values, int period) {
        if (values == null || values.size() < period || period <= 0) return Double.NaN;
        double sum = 0.0;
        for (int i = values.size() - period; i < values.size(); i++) sum += values.get(i);
        return sum / period;
    }

    private static double rsi14(List<Double> close) {
        if (close == null || close.size() < 15) return Double.NaN;
        double gain = 0.0, loss = 0.0;
        for (int i = close.size() - 14; i < close.size(); i++) {
            double d = close.get(i) - close.get(i - 1);
            if (d > 0) gain += d; else loss -= d;
        }
        if (loss == 0) return 100.0;
        double rs = (gain / 14.0) / (loss / 14.0);
        return 100.0 - (100.0 / (1.0 + rs));
    }

    private static double avgRange14(List<Double> high, List<Double> low, List<Double> close) {
        if (close == null || high == null || low == null || close.size() < 15) return Double.NaN;
        double sum = 0.0;
        for (int i = close.size() - 14; i < close.size(); i++) {
            double prev = close.get(i - 1);
            double tr = Math.max(high.get(i) - low.get(i), Math.max(Math.abs(high.get(i) - prev), Math.abs(low.get(i) - prev)));
            sum += tr;
        }
        return sum / 14.0;
    }

    private JSONObject analyzeKlines(JSONArray klines) throws Exception {
        List<Double> close = new ArrayList<>(), high = new ArrayList<>(), low = new ArrayList<>(), vol = new ArrayList<>();
        if (klines != null) for (int i = 0; i < klines.length(); i++) {
            JSONArray k = klines.optJSONArray(i);
            if (k == null || k.length() < 6) continue;
            close.add(parseDoubleSafe(k.optString(4, "0")));
            high.add(parseDoubleSafe(k.optString(2, "0")));
            low.add(parseDoubleSafe(k.optString(3, "0")));
            vol.add(parseDoubleSafe(k.optString(5, "0")));
        }
        JSONObject o = new JSONObject();
        if (close.size() < 20) return o.put("status", "INSUFFICIENT_CANDLES");
        double last = close.get(close.size()-1);
        double s20 = sma(close,20), s50 = sma(close,50), rsi = rsi14(close), atr = avgRange14(high,low,close);
        double ret20 = close.size() > 20 && close.get(close.size()-21) > 0 ? (last/close.get(close.size()-21)-1.0)*100.0 : Double.NaN;
        double last5=0, prev20=0;
        for(int i=Math.max(0,vol.size()-5); i<vol.size(); i++) last5 += vol.get(i);
        int prevStart=Math.max(0,vol.size()-25), prevEnd=Math.max(prevStart,vol.size()-5);
        for(int i=prevStart;i<prevEnd;i++) prev20 += vol.get(i);
        double volRatio = (prevEnd-prevStart)>0 && prev20>0 ? (last5/Math.min(5,vol.size())) / (prev20/(prevEnd-prevStart)) : Double.NaN;
        String trend = Double.isFinite(s50) && last > s20 && s20 > s50 ? "BULL" :
                Double.isFinite(s50) && last < s20 && s20 < s50 ? "BEAR" : "MIXED";
        o.put("status","OK"); o.put("candles",close.size()); o.put("last",last); putFinite(o,"sma20",s20); putFinite(o,"sma50",s50);
        putFinite(o,"rsi14",rsi); if(last>0&&Double.isFinite(atr)) o.put("atrPct",atr/last*100.0);
        putFinite(o,"return20",ret20); putFinite(o,"volumeRatio",volRatio); o.put("trend",trend);
        return o;
    }


    private JSONObject fetchSpotScreen1d(String symbol) throws Exception {
        String url="https://data-api.binance.vision/api/v3/klines?symbol="+URLEncoder.encode(symbol,"UTF-8")+
                "&interval=1d&limit=60";
        JSONArray k=httpJsonArrayBounded(url,900_000);
        List<Double> close=new ArrayList<>(), quoteVol=new ArrayList<>();
        for(int i=0;i<k.length();i++){
            JSONArray row=k.optJSONArray(i); if(row==null||row.length()<8)continue;
            double c=parseDoubleSafe(row.optString(4,"0"));
            double q=parseDoubleSafe(row.optString(7,"0"));
            if(c>0){close.add(c);quoteVol.add(q);}
        }
        JSONObject o=new JSONObject();
        if(close.size()<31)return o.put("status","INSUFFICIENT_CANDLES");
        double last=close.get(close.size()-1);
        double r7=(last/close.get(close.size()-8)-1.0)*100.0;
        double r30=(last/close.get(close.size()-31)-1.0)*100.0;
        double s20=sma(close,20),s50=sma(close,50),rsi=rsi14(close);
        double recent=quoteVol.get(quoteVol.size()-1),base=0;
        int n=0;
        for(int i=Math.max(0,quoteVol.size()-21);i<quoteVol.size()-1;i++){base+=quoteVol.get(i);n++;}
        double vr=n>0&&base>0?recent/(base/n):Double.NaN;
        String trend=Double.isFinite(s50)&&last>s20&&s20>s50?"BULL":
                Double.isFinite(s50)&&last<s20&&s20<s50?"BEAR":"MIXED";
        o.put("status","OK");o.put("trend",trend);
        putFinite(o,"return7d",r7);putFinite(o,"return30d",r30);putFinite(o,"volumeRatio20d",vr);
        putFinite(o,"rsi14",rsi);putFinite(o,"sma20",s20);putFinite(o,"sma50",s50);
        return o;
    }

    private JSONObject fetchSpotTechnical(String symbol) throws Exception {
        JSONObject out = new JSONObject();
        String[] intervals = {"4h","1d","1w","1M"};
        for (String tf : intervals) {
            try {
                String url = "https://data-api.binance.vision/api/v3/klines?symbol=" + URLEncoder.encode(symbol,"UTF-8") +
                        "&interval=" + URLEncoder.encode(tf,"UTF-8") + "&limit=120";
                JSONArray k = httpJsonArrayBounded(url, 1_500_000);
                out.put(tf, analyzeKlines(k));
            } catch (Exception e) {
                out.put(tf, new JSONObject().put("status","SOURCE_UNAVAILABLE").put("error",safeMsg(e)));
            }
        }
        out.put("sourceUrl","https://developers.binance.com/en/docs/catalog/core-trading-spot-trading/api/rest-api/market");
        out.put("updatedAt",isoNow());
        return out;
    }


    private static double bookPrice(JSONArray side, int index) {
        try {
            if (side == null || side.length() <= index) return 0.0;
            JSONArray row = side.getJSONArray(index);
            return Double.parseDouble(row.getString(0));
        } catch (Exception e) { return 0.0; }
    }

    private static double depthUsd(JSONArray side, double boundary, boolean bids) {
        if (side == null) return 0.0;
        double total = 0.0;
        for (int i = 0; i < side.length(); i++) {
            try {
                JSONArray row = side.getJSONArray(i);
                double p = Double.parseDouble(row.getString(0));
                double q = Double.parseDouble(row.getString(1));
                if (bids && p < boundary) break;
                if (!bids && p > boundary) break;
                total += p * q;
            } catch (Exception ignored) {}
        }
        return total;
    }


    private String getOptionalSecret(String prefKey) {
        try {
            String enc = prefs.getString(prefKey, "");
            return enc.isEmpty() ? "" : decryptSecret(enc);
        } catch (Exception e) { return ""; }
    }

    private static String safeMsg(Exception e) {
        String m = e == null ? "" : String.valueOf(e.getMessage());
        return m.length() > 240 ? m.substring(0, 240) : m;
    }

    private static String firstNonEmpty(JSONArray a) {
        if (a == null) return "";
        for (int i = 0; i < a.length(); i++) {
            String x = a.optString(i, "").trim();
            if (!x.isEmpty()) return x;
        }
        return "";
    }

    private static String preferredPlatformFor(String base) {
        String b = base == null ? "" : base.toUpperCase(Locale.US);
        if (b.equals("ARB")) return "arbitrum-one";
        if (b.equals("OP")) return "optimistic-ethereum";
        if (b.equals("AVAX")) return "avalanche";
        if (b.equals("BNB")) return "binance-smart-chain";
        if (b.equals("MATIC") || b.equals("POL")) return "polygon-pos";
        if (b.equals("SOL")) return "solana";
        return "ethereum";
    }

    private static String nativeChainFor(String base) {
        String b = base == null ? "" : base.toUpperCase(Locale.US);
        if (Arrays.asList("BTC","ETH","SOL","SUI","APT","SEI","ATOM","NEAR","ICP","FIL","ADA","TRX","TON","DOT","AVAX","BNB","XRP","HBAR","XLM","ALGO","VET","THETA","EGLD","ETC","BCH","LTC","ZEC").contains(b)) return b;
        return "";
    }

    private static String goPlusChainIdFor(String platform) {
        if (platform == null) return "";
        switch (platform) {
            case "ethereum": return "1";
            case "binance-smart-chain": return "56";
            case "arbitrum-one": return "42161";
            case "polygon-pos": return "137";
            case "zksync": return "324";
            case "linea": return "59144";
            case "base": return "8453";
            case "scroll": return "534352";
            case "optimistic-ethereum": return "10";
            case "avalanche": return "43114";
            case "fantom": return "250";
            case "cronos": return "25";
            case "gnosis": return "100";
            case "mantle": return "5000";
            case "blast": return "81457";
            default: return "";
        }
    }

    private JSONObject resolveProjectIdentity(String base, String cgId, JSONObject detail) throws Exception {
        JSONObject out = new JSONObject();
        out.put("coinGeckoId", cgId);
        out.put("name", detail.optString("name", base));
        out.put("symbol", detail.optString("symbol", base).toUpperCase(Locale.US));

        JSONObject links = detail.optJSONObject("links");
        if (links != null) {
            out.put("homepage", firstNonEmpty(links.optJSONArray("homepage")));
                        JSONObject repos = links.optJSONObject("repos_url");
            if (repos != null) out.put("github", firstNonEmpty(repos.optJSONArray("github")));
            out.put("forum", firstNonEmpty(links.optJSONArray("official_forum_url")));
        }

        JSONObject platforms = detail.optJSONObject("platforms");
        JSONArray contracts = new JSONArray();
        String preferred = preferredPlatformFor(base);
        String selectedPlatform = "";
        String selectedContract = "";
        int nonEmpty = 0;

        if (platforms != null) {
            Iterator<String> keys = platforms.keys();
            while (keys.hasNext()) {
                String platform = keys.next();
                String address = platforms.optString(platform, "").trim();
                if (address.isEmpty()) continue;
                nonEmpty++;
                JSONObject c = new JSONObject();
                c.put("platform", platform);
                c.put("contract", address);
                c.put("goPlusChainId", goPlusChainIdFor(platform));
                contracts.put(c);
                if (selectedContract.isEmpty() || platform.equals(preferred)) {
                    selectedPlatform = platform;
                    selectedContract = address;
                    if (platform.equals(preferred)) {
                        // Keep preferred scope, but continue collecting all platforms.
                    }
                }
            }
        }

        String nativeChain = nativeChainFor(base);
        boolean nativeAsset = nonEmpty == 0 && !nativeChain.isEmpty();
        JSONArray categories = detail.optJSONArray("categories");
        if (categories != null) out.put("categories", categories);
        out.put("platformCount", nonEmpty);
        out.put("multichain", nonEmpty > 1);
        out.put("contracts", contracts);
        out.put("nativeAsset", nativeAsset);
        if (nativeAsset) {
            out.put("status", "NATIVE_ASSET");
            out.put("nativeChain", nativeChain);
        } else if (!selectedContract.isEmpty()) {
            out.put("status", "CONTRACT_RESOLVED");
            out.put("selectedPlatform", selectedPlatform);
            out.put("selectedContract", selectedContract);
            out.put("goPlusChainId", goPlusChainIdFor(selectedPlatform));
            out.put("scopeNote", nonEmpty > 1 ? "Security được chấm theo contract đã chọn; token là multichain." : "Contract mapping từ CoinGecko.");
        } else {
            out.put("status", "UNKNOWN");
        }
        return out;
    }

    private synchronized JSONArray getDefiLlamaProtocols() throws Exception {
        long now = System.currentTimeMillis();
        if (llamaProtocolsCache != null && now - llamaProtocolsCacheAt < 6L * 60L * 60L * 1000L) return llamaProtocolsCache;
        JSONArray arr = httpJsonArrayBounded("https://api.llama.fi/protocols", 8_000_000);
        if (arr.length() > 5000) throw new IllegalStateException("DefiLlama protocol directory vượt giới hạn an toàn");
        llamaProtocolsCache = arr;
        llamaProtocolsCacheAt = now;
        return arr;
    }

    private synchronized JSONArray getDefiLlamaChains() throws Exception {
        long now = System.currentTimeMillis();
        if (llamaChainsCache != null && now - llamaChainsCacheAt < 6L * 60L * 60L * 1000L) return llamaChainsCache;
        JSONArray arr = httpJsonArrayBounded("https://api.llama.fi/v2/chains", 2_000_000);
        if (arr.length() > 1000) throw new IllegalStateException("DefiLlama chain directory vượt giới hạn an toàn");
        llamaChainsCache = arr;
        llamaChainsCacheAt = now;
        return arr;
    }

    private JSONObject findDefiLlamaChainContext(String cgId) throws Exception {
        if (cgId == null || cgId.trim().isEmpty()) return null;
        JSONArray arr = getDefiLlamaChains();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject c = arr.optJSONObject(i);
            if (c == null || !cgId.equalsIgnoreCase(c.optString("gecko_id", ""))) continue;
            JSONObject out = new JSONObject();
            out.put("status", "CHAIN_CONTEXT");
            out.put("scope", "CHAIN");
            out.put("chain", c.optString("name", ""));
            out.put("tokenSymbol", c.optString("tokenSymbol", ""));
            putFinite(out, "chainTvl", c.optDouble("tvl", Double.NaN));
            out.put("valueCapture", "UNKNOWN");
            String n = c.optString("name", "");
            if (!n.isEmpty()) out.put("sourceUrl", "https://defillama.com/chain/" + URLEncoder.encode(n, "UTF-8").replace("+", "%20"));
            out.put("methodNote", "Chain TVL là bối cảnh hệ sinh thái, không phải revenue của token. Cần network economics (fees/issuance/burn/staking/value capture) từ nguồn có căn cứ để chấm điểm.");
            return out;
        }
        return null;
    }

    private String findDefiLlamaSlug(String cgId, String base) {
        if (cgId == null || cgId.trim().isEmpty()) return "";
        try {
            JSONArray arr = getDefiLlamaProtocols();
            String match = "";
            for (int i=0;i<arr.length();i++) {
                JSONObject p=arr.optJSONObject(i); if(p==null)continue;
                if (!cgId.equalsIgnoreCase(p.optString("gecko_id",""))) continue;
                String slug=p.optString("slug","");
                if (slug.isEmpty()) continue;
                if (match.isEmpty()) match=slug;
                else {
                    // Multiple protocols can share a token. Prefer exact token symbol/name relation only if clear.
                    String sym=p.optString("symbol","");
                    if (base != null && base.equalsIgnoreCase(sym)) match=slug;
                }
            }
            return match;
        } catch (Exception e) { return ""; }
    }

    private String httpText(String urlString, int maxChars) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlString).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(18000);
        c.setRequestProperty("User-Agent", "MarketOS/26.1 Android");
        c.setRequestProperty("Accept", "text/plain,application/json");
        c.setRequestProperty("Cache-Control", "no-cache, no-store, max-age=0");
        int code = c.getResponseCode();
        String body = readLimited(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream(), maxChars);
        c.disconnect();
        if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + ": " + body.substring(0, Math.min(180, body.length())));
        return body.trim();
    }

    private static double metric(JSONObject x, String key) {
        if (x == null || !x.has(key) || x.isNull(key)) return Double.NaN;
        return x.optDouble(key, Double.NaN);
    }

    private static void putFinite(JSONObject out, String key, double value) throws Exception {
        if (Double.isFinite(value)) out.put(key, value);
    }

    private JSONObject fetchProtocolEconomics(String slug) throws Exception {
        String enc = URLEncoder.encode(slug, "UTF-8");
        JSONObject out = new JSONObject();
        out.put("slug", slug);
        boolean any = false;

        try {
            String tvlRaw = httpText("https://api.llama.fi/tvl/" + enc, 100_000);
            double tvl = Double.parseDouble(tvlRaw.replace("\"","").trim());
            if (Double.isFinite(tvl)) { out.put("tvl", tvl); any = true; }
        } catch (Exception ignored) {}

        JSONObject fees = null, revenue = null, holders = null;
        try {
            fees = httpJson("https://api.llama.fi/summary/fees/" + enc +
                    "?excludeTotalDataChart=true&excludeTotalDataChartBreakdown=true&dataType=dailyFees");
            putFinite(out, "fees24h", metric(fees, "total24h"));
            putFinite(out, "fees7d", metric(fees, "total7d"));
            putFinite(out, "fees30d", metric(fees, "total30d"));
            putFinite(out, "feesChange7d", metric(fees, "change_7d"));
            any = true;
        } catch (Exception ignored) {}

        try {
            revenue = httpJson("https://api.llama.fi/summary/fees/" + enc +
                    "?excludeTotalDataChart=true&excludeTotalDataChartBreakdown=true&dataType=dailyRevenue");
            putFinite(out, "revenue24h", metric(revenue, "total24h"));
            putFinite(out, "revenue7d", metric(revenue, "total7d"));
            putFinite(out, "revenue30d", metric(revenue, "total30d"));
            putFinite(out, "revenueChange7d", metric(revenue, "change_7d"));
            any = true;
        } catch (Exception ignored) {}

        try {
            holders = httpJson("https://api.llama.fi/summary/fees/" + enc +
                    "?excludeTotalDataChart=true&excludeTotalDataChartBreakdown=true&dataType=dailyHoldersRevenue");
            putFinite(out, "holdersRevenue24h", metric(holders, "total24h"));
            putFinite(out, "holdersRevenue30d", metric(holders, "total30d"));
            any = true;
        } catch (Exception ignored) {}

        double holder30 = out.optDouble("holdersRevenue30d", Double.NaN);
        double rev30 = out.optDouble("revenue30d", Double.NaN);
        if (Double.isFinite(holder30) && holder30 > 0) out.put("valueCapture", "DIRECT_TO_TOKEN_HOLDERS");
        else if (Double.isFinite(rev30) && rev30 > 0) out.put("valueCapture", "PROTOCOL_REVENUE_ONLY_OR_UNKNOWN");
        else out.put("valueCapture", "UNKNOWN");

        out.put("status", any ? "OK" : "NO_DATA");
        out.put("sourceUrl", "https://defillama.com/protocol/" + slug);
        out.put("methodNote", "Fees ≠ Revenue; holder revenue is tracked separately when DefiLlama exposes it.");
        return out;
    }

    private JSONObject httpJsonOptionalBearer(String urlString, String bearer) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlString).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(18000);
        c.setRequestProperty("User-Agent", "MarketOS/26.1 Android");
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("Cache-Control", "no-cache, no-store, max-age=0");
        if (bearer != null && !bearer.trim().isEmpty()) c.setRequestProperty("Authorization", "Bearer " + bearer.trim());
        int code = c.getResponseCode();
        String body = readLimited(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream(), 2_000_000);
        c.disconnect();
        if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + ": " + body.substring(0, Math.min(240, body.length())));
        return new JSONObject(body);
    }

    private static boolean one(JSONObject x, String key) { return "1".equals(x == null ? "" : x.optString(key, "")); }

    private static long parseEpoch(String raw) {
        try {
            long v = Long.parseLong(raw == null ? "" : raw.trim());
            if (v > 10_000_000_000L) v /= 1000L;
            return v;
        } catch (Exception e) { return 0L; }
    }

    private JSONObject fetchGoPlusSecurity(String chainId, String contract, double spotPrice) throws Exception {
        String url = "https://api.gopluslabs.io/api/v1/token_security/" +
                URLEncoder.encode(chainId, "UTF-8") + "?contract_addresses=" +
                URLEncoder.encode(contract, "UTF-8");
        JSONObject raw = httpJsonOptionalBearer(url, getOptionalSecret("goplus_token_secure"));
        JSONObject result = raw.optJSONObject("result");
        if (result == null) throw new IllegalStateException("GoPlus: no result");

        JSONObject sec = result.optJSONObject(contract.toLowerCase(Locale.US));
        if (sec == null) sec = result.optJSONObject(contract);
        if (sec == null) {
            Iterator<String> keys = result.keys();
            if (keys.hasNext()) sec = result.optJSONObject(keys.next());
        }
        if (sec == null) throw new IllegalStateException("GoPlus: token not found");

        JSONObject out = new JSONObject();
        out.put("status", "OK");
        out.put("chainId", chainId);
        out.put("contract", contract);
        out.put("holderCount", parseDoubleSafe(sec.optString("holder_count", "0")));
        out.put("isOpenSource", sec.optString("is_open_source", ""));
        out.put("isProxy", sec.optString("is_proxy", ""));
        out.put("isMintable", sec.optString("is_mintable", ""));
        out.put("honeypot", sec.optString("is_honeypot", ""));
        out.put("cannotBuy", sec.optString("cannot_buy", ""));
        out.put("cannotSellAll", sec.optString("cannot_sell_all", ""));
        out.put("ownerChangeBalance", sec.optString("owner_change_balance", ""));
        out.put("canTakeBackOwnership", sec.optString("can_take_back_ownership", ""));
        out.put("blacklist", sec.optString("is_blacklisted", ""));
        out.put("whitelist", sec.optString("is_whitelisted", ""));
        out.put("transferPausable", sec.optString("transfer_pausable", ""));
        out.put("buyTax", sec.optString("buy_tax", ""));
        out.put("sellTax", sec.optString("sell_tax", ""));
        out.put("otherPotentialRisks", sec.optString("other_potential_risks", ""));
        out.put("note", sec.optString("note", ""));

        JSONArray holders = sec.optJSONArray("holders");
        double top10Raw = 0.0, top10NonBurn = 0.0;
        int lockedHolders = 0;
        JSONArray holderSummary = new JSONArray();

        long now = System.currentTimeMillis() / 1000L;
        long d7 = now + 7L*86400L, d30 = now + 30L*86400L, d60 = now + 60L*86400L, d90 = now + 90L*86400L;
        double u7=0,u30=0,u60=0,u90=0;
        long nextUnlock = 0L;
        int lockRecords = 0;

        if (holders != null) for (int i=0; i<Math.min(10, holders.length()); i++) {
            JSONObject ho = holders.optJSONObject(i);
            if (ho == null) continue;
            double pct = parseDoubleSafe(ho.optString("percent", "0"));
            top10Raw += pct;
            String tag = ho.optString("tag", "");
            String tagLow = tag.toLowerCase(Locale.US);
            boolean burn = tagLow.contains("burn") || tagLow.contains("dead") || tagLow.contains("black hole");
            if (!burn) top10NonBurn += pct;
            if ("1".equals(ho.optString("is_locked", ""))) lockedHolders++;

            JSONObject hs = new JSONObject();
            hs.put("tag", tag);
            hs.put("percent", pct);
            hs.put("isContract", ho.optString("is_contract", ""));
            hs.put("isLocked", ho.optString("is_locked", ""));
            holderSummary.put(hs);

            JSONArray ld = ho.optJSONArray("locked_detail");
            if (ld != null) for (int j=0; j<ld.length(); j++) {
                JSONObject rec = ld.optJSONObject(j);
                if (rec == null) continue;
                long end = parseEpoch(rec.optString("end_time", ""));
                double amount = parseDoubleSafe(rec.optString("amount", "0"));
                if (end <= now || amount <= 0) continue;
                lockRecords++;
                if (nextUnlock == 0 || end < nextUnlock) nextUnlock = end;
                if (end <= d7) u7 += amount;
                if (end <= d30) u30 += amount;
                if (end <= d60) u60 += amount;
                if (end <= d90) u90 += amount;
            }
        }

        out.put("top10RawPct", top10Raw * 100.0);
        out.put("top10NonBurnPct", top10NonBurn * 100.0);
        out.put("lockedTop10Holders", lockedHolders);
        out.put("holders", holderSummary);

        JSONArray riskFlags = new JSONArray();
        if (one(sec,"is_honeypot")) riskFlags.put("HONEYPOT");
        if (one(sec,"cannot_sell_all")) riskFlags.put("CANNOT_SELL_ALL");
        if (one(sec,"owner_change_balance")) riskFlags.put("OWNER_CAN_CHANGE_BALANCE");
        if (one(sec,"can_take_back_ownership")) riskFlags.put("TAKE_BACK_OWNERSHIP");
        if (one(sec,"is_mintable")) riskFlags.put("MINTABLE");
        if (one(sec,"is_blacklisted")) riskFlags.put("BLACKLIST");
        if (one(sec,"transfer_pausable")) riskFlags.put("TRANSFER_PAUSABLE");
        if ("0".equals(sec.optString("is_open_source",""))) riskFlags.put("CLOSED_SOURCE");
        out.put("riskFlags", riskFlags);
        out.put("riskLevel", riskFlags.length() >= 3 || one(sec,"is_honeypot") || one(sec,"owner_change_balance") ? "HIGH" :
                riskFlags.length() > 0 ? "MEDIUM" : "LOW");

        JSONObject unlock = new JSONObject();
        unlock.put("coverage", lockRecords > 0 ? "PARTIAL_TOP10_SUPPORTED_LOCKERS" : "NO_SUPPORTED_LOCK_RECORD");
        unlock.put("records", lockRecords);
        unlock.put("nextUnlockEpoch", nextUnlock);
        unlock.put("amount7d", u7);
        unlock.put("amount30d", u30);
        unlock.put("amount60d", u60);
        unlock.put("amount90d", u90);
        if (spotPrice > 0) {
            unlock.put("usd7d", u7 * spotPrice);
            unlock.put("usd30d", u30 * spotPrice);
            unlock.put("usd60d", u60 * spotPrice);
            unlock.put("usd90d", u90 * spotPrice);
        }
        double totalSupply = parseDoubleSafe(sec.optString("total_supply", "0"));
        if (totalSupply > 0) {
            unlock.put("pctSupply7d", u7/totalSupply*100.0);
            unlock.put("pctSupply30d", u30/totalSupply*100.0);
            unlock.put("pctSupply60d", u60/totalSupply*100.0);
            unlock.put("pctSupply90d", u90/totalSupply*100.0);
        }
        unlock.put("limitation", "Chỉ phản ánh lock addresses mà GoPlus hỗ trợ trong top holders; không thay thế lịch vesting đầy đủ.");
        out.put("unlockEvidence", unlock);
        out.put("sourceUrl", "https://docs.gopluslabs.io/reference/tokensecurityusingget_1");
        return out;
    }


    private static String hostOf(String rawUrl) {
        try {
            Uri u = Uri.parse(rawUrl == null ? "" : rawUrl.trim());
            String h = u.getHost();
            if (h == null) return "";
            h = h.toLowerCase(Locale.US);
            return h.startsWith("www.") ? h.substring(4) : h;
        } catch (Exception e) { return ""; }
    }

    private static boolean sameOrSubdomain(String a, String b) {
        if (a == null || b == null || a.isEmpty() || b.isEmpty()) return false;
        return a.equals(b) || a.endsWith("." + b) || b.endsWith("." + a);
    }

    private static boolean sourceHostGrounded(String url, JSONArray sources) {
        String h = hostOf(url);
        if (h.isEmpty() || sources == null) return false;
        for (int i=0;i<sources.length();i++) {
            JSONObject x=sources.optJSONObject(i); if(x==null)continue;
            if (sameOrSubdomain(h, hostOf(x.optString("url","")))) return true;
        }
        return false;
    }

    private static boolean trustedUnlockHost(String host, String officialHost) {
        if (host == null || host.isEmpty()) return false;
        if (sameOrSubdomain(host,"tokenomist.ai") || sameOrSubdomain(host,"defillama.com") ||
                sameOrSubdomain(host,"cryptorank.io")) return true;
        return officialHost != null && !officialHost.isEmpty() && sameOrSubdomain(host, officialHost);
    }

    private static String stripStructuredEvidence(String text) {
        if (text == null) return "";
        int a=text.indexOf("[STRUCTURED_EVIDENCE_JSON]");
        if(a<0)return text.trim();
        return text.substring(0,a).trim();
    }

    private static JSONObject extractStructuredEvidenceObject(String text) {
        try {
            if(text==null)return new JSONObject();
            String a="[STRUCTURED_EVIDENCE_JSON]", b="[/STRUCTURED_EVIDENCE_JSON]";
            int i=text.indexOf(a); if(i<0)return new JSONObject();
            int j=text.indexOf(b,i+a.length()); if(j<0)j=text.length();
            String raw=text.substring(i+a.length(),j).trim();
            if(raw.startsWith("```")) {
                int nl=raw.indexOf('\n'); if(nl>=0)raw=raw.substring(nl+1);
                if(raw.endsWith("```"))raw=raw.substring(0,raw.length()-3).trim();
            }
            int p=raw.indexOf('{'), q=raw.lastIndexOf('}');
            if(p<0||q<=p)return new JSONObject();
            return new JSONObject(raw.substring(p,q+1));
        } catch(Exception e){return new JSONObject();}
    }

    private JSONObject extractAndValidateCoinEvidence(String text, JSONArray groundingSources, String contextJson) {
        JSONObject ev=extractStructuredEvidenceObject(text);
        try {
            JSONObject ctx=contextJson==null?new JSONObject():new JSONObject(contextJson);
            JSONObject facts=ctx.optJSONObject("automaticFacts");
            JSONObject identity=facts==null?null:facts.optJSONObject("identity");
            String officialHost=identity==null?"":hostOf(identity.optString("homepage",""));

            String[] blocks={"unlock","product_usage","economics_context","narrative","security_context","team_backer","special_risk"};
            for(String key:blocks){
                JSONObject x=ev.optJSONObject(key); if(x==null)continue;
                String u=x.optString("source_url","");
                String st=x.optString("status","UNVERIFIED").toUpperCase(Locale.US);
                if(!sourceHostGrounded(u,groundingSources)){
                    x.put("status","UNVERIFIED");
                    x.put("validation","SOURCE_URL_NOT_IN_GROUNDING");
                }else{
                    x.put("validation","SOURCE_GROUNDED");
                    if("unlock".equals(key) && "VERIFIED".equals(st)){
                        String host=hostOf(u);
                        String app=x.optString("applicability","UNKNOWN").toUpperCase(Locale.US);
                        boolean vesting="VESTING".equals(app);
                        boolean noUnlock="NO_SCHEDULED_UNLOCK".equals(app)||"EMISSION_SCHEDULE".equals(app);
                        boolean hasWindows=!x.optString("window_30d","").isEmpty() && !x.optString("window_90d","").isEmpty();
                        boolean hasSchedule=!x.optString("schedule_summary","").isEmpty();
                        boolean strictEnough=(vesting&&hasWindows)||(noUnlock&&hasSchedule);
                        if(!trustedUnlockHost(host,officialHost) || !strictEnough){
                            x.put("status","PARTIAL");
                            x.put("validation","GROUNDING_OK_BUT_SUPPLY_SCHEDULE_NOT_STRICTLY_VERIFIED");
                        }
                    }
                }
            }
            JSONObject cat=ev.optJSONObject("catalyst");
            if(cat!=null){
                JSONArray items=cat.optJSONArray("items"); int good=0;
                if(items!=null)for(int i=0;i<items.length();i++){
                    JSONObject x=items.optJSONObject(i); if(x==null)continue;
                    if(sourceHostGrounded(x.optString("source_url",""),groundingSources)){good++;x.put("validation","SOURCE_GROUNDED");}
                    else x.put("validation","UNVERIFIED_SOURCE");
                }
                if(good==0)cat.put("status","UNVERIFIED");
                cat.put("groundedItems",good);
            }
            ev.put("validationNote","Chỉ source URL xuất hiện trong grounding metadata mới được SOURCE_BACKED; full unlock còn kiểm host + 30/90D.");
        }catch(Exception ignored){}
        return ev;
    }

    private JSONObject fetchArticle(String urlString) throws Exception {
        assertOfficialFedUrl(urlString);
        if (isStaticFedLanding(urlString, "")) throw new IllegalArgumentException("Đây là trang điều hướng Fed, không phải tài liệu/bài phát hành để đọc sâu.");
        Document wrapper = connectFed(urlString);
        String htmlUrl = ""; String pdfUrl = "";
        for(Element a:wrapper.select("a[href]")){
            String href=a.absUrl("href"); if(href==null||href.isEmpty())continue; Uri u=Uri.parse(href); String h=u.getHost(); if(h==null||!h.endsWith("federalreserve.gov"))continue;
            String label=clean(a.text()).toLowerCase(Locale.US); String low=href.toLowerCase(Locale.US);
            if(pdfUrl.isEmpty() && (low.endsWith(".pdf") || label.equals("pdf") || label.contains("attachment (pdf)"))) pdfUrl=href;
            if(htmlUrl.isEmpty() && !href.equals(urlString) && (label.equals("html") || low.contains("fomcminutes") || low.contains("fomcstatement") || low.contains("monetarypolicy/fomc"))) htmlUrl=href;
        }
        Document contentDoc=wrapper; String contentUrl=urlString; String contentKind="HTML";
        if(!htmlUrl.isEmpty()) { try { contentDoc=connectFed(htmlUrl); contentUrl=htmlUrl; } catch(Exception ignored){} }
        JSONObject parsed=parseHtmlDocument(contentDoc);
        String text=parsed.optString("text","");
        boolean looksWrapper=text.length()<1200 || text.toLowerCase(Locale.US).contains("for media inquiries");
        if(!pdfUrl.isEmpty() && looksWrapper){
            try {
                String pdfText=extractPdfText(pdfUrl);
                if(pdfText.length()>Math.max(900,text.length()*2)){
                    parsed=buildTextArticle(pdfText, parsed.optString("title",clean(wrapper.title()))); contentKind="PDF"; contentUrl=pdfUrl;
                }
            } catch(Exception ignored){}
        }
        parsed.put("sourcePageUrl",urlString); parsed.put("contentUrl",contentUrl); parsed.put("htmlUrl",htmlUrl.isEmpty()?urlString:htmlUrl); parsed.put("pdfUrl",pdfUrl); parsed.put("contentKind",contentKind);
        return parsed;
    }

    private Document connectFed(String url) throws Exception { return Jsoup.connect(url).userAgent("MarketOS/26.1 Android").timeout(25000).maxBodySize(3_000_000).get(); }

    private JSONObject parseHtmlDocument(Document doc) throws Exception {
        doc=doc.clone();
        doc.select("script,style,noscript,nav,header,footer,.breadcrumb,.breadcrumbs,.share,.social,.social-links,.skip-link,.btn,.button,.watch-live,.related,.related-links").remove();
        Element root=doc.selectFirst("#content");if(root==null)root=doc.selectFirst("main");if(root==null)root=doc.body();if(root==null)throw new IllegalStateException("Không tìm thấy vùng nội dung tài liệu");
        String pageTitle=clean(doc.title()),title="",subtitle="",byline="";
        JSONArray paragraphs=new JSONArray(),blocks=new JSONArray();StringBuilder text=new StringBuilder();Elements nodes=root.select("h1,h2,h3,h4,p,li");
        LinkedHashSet<String> seenBlockText=new LinkedHashSet<>(); int boilerplateDropped=0;
        for(Element el:nodes){
            String t=clean(el.text());if(t.isEmpty())continue;String low=t.toLowerCase(Locale.US);
            if(isFedBoilerplate(low)){boilerplateDropped++;continue;}if(t.length()<18&&!el.tagName().matches("h[1-4]"))continue;
            String dedupeKey=low.replaceAll("\\s+"," ").trim();
            if(!seenBlockText.add(dedupeKey))continue;
            if(title.isEmpty()&&el.tagName().matches("h[1-4]")&&!isGenericFedHeading(low))title=t;
            else if(subtitle.isEmpty()&&el.tagName().matches("h[2-4]")&&!isGenericFedHeading(low)&&!t.equals(title))subtitle=t;
            if(byline.isEmpty()&&(low.startsWith("chair ")||low.startsWith("governor ")||low.startsWith("vice chair ")))byline=t;
            if(el.tagName().equals("li")&&el.parents().select("li").size()>0)continue;
            paragraphs.put(t);String type=el.tagName().matches("h[1-4]")?"heading":(el.tagName().equals("li")?"bullet":"paragraph");blocks.put(new JSONObject().put("type",type).put("text",t));
            if(text.length()>0)text.append("\n\n");text.append(t);if(text.length()>=90000)break;
        }
        String out=text.toString().trim();if(out.length()<120)throw new IllegalStateException("Không trích được phần thân tài liệu Fed");if(title.isEmpty())title=pageTitle.replace(" - Federal Reserve Board","").trim();
        int words=out.isEmpty()?0:out.split("\\s+").length;
        String quality=(words>=180&&blocks.length()>=6)?"ARTICLE_BODY":"THIN_BODY";
        JSONObject r=new JSONObject();r.put("title",title);r.put("subtitle",subtitle);r.put("byline",byline);r.put("text",out);r.put("paragraphs",paragraphs);r.put("blocks",blocks);
        r.put("wordCount",words);r.put("readingMinutes",Math.max(1,(int)Math.ceil(words/220.0)));r.put("bodyBlocks",blocks.length());r.put("boilerplateDropped",boilerplateDropped);r.put("documentQuality",quality);return r;
    }

    private String extractPdfText(String pdfUrl) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(pdfUrl).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(45000);c.setRequestProperty("User-Agent","MarketOS/26.1 Android");int code=c.getResponseCode();if(code<200||code>=300)throw new IllegalStateException("PDF HTTP "+code);
        ByteArrayOutputStream bos=new ByteArrayOutputStream();try(InputStream is=c.getInputStream()){byte[] buf=new byte[16384];int n;while((n=is.read(buf))>0){bos.write(buf,0,n);if(bos.size()>20_000_000)throw new IllegalStateException("PDF quá lớn");}}c.disconnect();
        try(PDDocument doc=PDDocument.load(new ByteArrayInputStream(bos.toByteArray()))){PDFTextStripper stripper=new PDFTextStripper();stripper.setSortByPosition(true);String t=stripper.getText(doc);return normalizePdfText(t);}
    }

    private String normalizePdfText(String t){
        if(t==null)return"";
        return t.replace("\r","").replaceAll("(?m)^\\s*Page \\d+\\s*$","").replaceAll("[ \\t]+"," ").replaceAll("\\n{3,}","\n\n").trim();
    }

    private JSONObject buildTextArticle(String text,String fallbackTitle) throws Exception {
        JSONArray paras=new JSONArray(),blocks=new JSONArray();String[] ps=text.split("\\n\\s*\\n");String title=fallbackTitle;StringBuilder all=new StringBuilder();
        for(String raw:ps){String t=clean(raw);if(t.length()<12)continue;paras.put(t);blocks.put(new JSONObject().put("type","paragraph").put("text",t));if(all.length()>0)all.append("\n\n");all.append(t);if(all.length()>100000)break;}
        String out=all.toString();int words=out.isEmpty()?0:out.split("\\s+").length;
        JSONObject r=new JSONObject();r.put("title",title);r.put("subtitle","");r.put("byline","");r.put("text",out);r.put("paragraphs",paras);r.put("blocks",blocks);
        r.put("wordCount",words);r.put("readingMinutes",Math.max(1,(int)Math.ceil(words/220.0)));r.put("bodyBlocks",blocks.length());r.put("boilerplateDropped",0);r.put("documentQuality",words>=180?"ARTICLE_BODY":"THIN_BODY");return r;
    }

    private void assertOfficialFedUrl(String url){Uri u=Uri.parse(url);String h=u.getHost();if(!"https".equalsIgnoreCase(u.getScheme())||h==null||!h.endsWith("federalreserve.gov"))throw new IllegalArgumentException("Chỉ cho phép tài liệu chính thức federalreserve.gov");}

    private boolean isGenericFedHeading(String low) {
        return low.equals("speech") || low.equals("testimony") || low.equals("press release") ||
                low.equals("federal reserve board") || low.equals("monetary policy") || low.equals("news & events");
    }

    private boolean isFedBoilerplate(String low) {
        String[] bad = {
                "skip to main content", "subscribe to rss", "subscribe to email", "please enable javascript",
                "back to home", "search button", "facebook", "linkedin", "youtube", "flickr", "contact us",
                "accessibility", "foia", "privacy program", "information quality", "open government",
                "last update:", "return to text", "board of governors of the federal reserve system",
                "accessible keys for video", "[space bar] toggles play/pause", "[right/left arrows]",
                "[up/down arrows]", "[m] toggles mute", "[f] toggles fullscreen", "the [tab] key may be used"
        };
        for (String x : bad) if (low.contains(x)) return true;
        return low.equals("pdf") || low.equals("html") || low.equals("watch live") || low.equals("more information");
    }

    private JSONObject analyzeTone(String text) throws Exception {
        String t=text.toLowerCase(Locale.US); String[] hawk={"inflation remains elevated","inflation is still elevated","upside risks to inflation","restrictive","higher for longer","not appropriate to reduce","not yet confident","tight labor market","further tightening"};
        String[] dove={"disinflation","downside risks to employment","labor market has cooled","easing","reduce the target range","rate cuts","less restrictive","inflation has eased","risks are roughly in balance"}; int hs=0,ds=0;JSONArray hm=new JSONArray(),dm=new JSONArray();
        for(String k:hawk)if(t.contains(k)){hs++;hm.put(k);}for(String k:dove)if(t.contains(k)){ds++;dm.put(k);} JSONObject o=new JSONObject();o.put("hawk",hs);o.put("dove",ds);o.put("label",hs>ds?"HAWKISH":ds>hs?"DOVISH":"NEUTRAL/MIXED");o.put("hawkMatches",hm);o.put("doveMatches",dm);return o;
    }

    private JSONObject analyzeInvestmentChannels(String text) throws Exception {
        String t = text.toLowerCase(Locale.US);
        JSONObject o = new JSONObject();
        JSONArray themes = new JSONArray();
        JSONArray channels = new JSONArray();
        int evidence = 0;

        evidence += addTheme(themes, t, "Lạm phát", new String[]{"inflation","prices","price stability","pce"});
        evidence += addTheme(themes, t, "Lao động", new String[]{"employment","unemployment","labor market","payroll","wages"});
        evidence += addTheme(themes, t, "Tăng trưởng", new String[]{"growth","gdp","economic activity","consumption","investment"});
        evidence += addTheme(themes, t, "Lãi suất", new String[]{"federal funds","target range","policy rate","restrictive","easing"});
        evidence += addTheme(themes, t, "Thanh khoản/QT", new String[]{"balance sheet","quantitative tightening","securities holdings","reserves","liquidity"});
        evidence += addTheme(themes, t, "Tín dụng/Ngân hàng", new String[]{"credit","lending","banks","financial conditions","delinquency"});

        JSONObject tone = analyzeTone(text);
        String label = tone.optString("label", "NEUTRAL/MIXED");
        if (label.equals("HAWKISH")) {
            channels.put("Nếu thị trường diễn giải là hawkish: lợi suất ngắn hạn và USD có thể chịu áp lực tăng; tài sản duration cao/risk assets có thể chịu sức ép. Cần xác nhận bằng US2Y, DXY và credit spreads.");
        } else if (label.equals("DOVISH")) {
            channels.put("Nếu thị trường diễn giải là dovish: lợi suất ngắn hạn có thể giảm và điều kiện tài chính có thể nới; cần xác nhận bằng US2Y, real yield, USD và breadth của risk assets.");
        } else {
            channels.put("Thông điệp hiện mang tính pha trộn; không nên suy ra hướng giao dịch chỉ từ văn bản. Ưu tiên phản ứng của rates, USD, credit và liquidity.");
        }
        if (t.contains("balance sheet") || t.contains("liquidity") || t.contains("reserves")) {
            channels.put("Theo dõi kênh thanh khoản: WALCL, reserves, TGA và ON RRP để kiểm tra xem thông điệp có đi cùng thay đổi thanh khoản thực tế hay không.");
        }
        if (t.contains("labor market") || t.contains("employment") || t.contains("unemployment")) {
            channels.put("Theo dõi kênh lao động: unemployment, initial claims và payrolls để xác nhận độ bền của tăng trưởng và xác suất thay đổi chính sách.");
        }
        if (t.contains("inflation") || t.contains("price stability")) {
            channels.put("Theo dõi kênh lạm phát: CPI/Core PCE cùng real yield; một phát biểu không thay thế dữ liệu công bố chính thức.");
        }

        o.put("themes", themes);
        o.put("channels", channels);
        o.put("evidenceCount", evidence);
        o.put("confidence", evidence >= 10 ? "HIGH" : evidence >= 5 ? "MEDIUM" : "LOW");
        o.put("note", "Bản đồ truyền dẫn theo kịch bản, không phải khuyến nghị mua/bán.");
        return o;
    }

    private int addTheme(JSONArray themes, String text, String name, String[] keys) throws Exception {
        int count = 0;
        for (String k : keys) {
            int pos = 0;
            while ((pos = text.indexOf(k, pos)) >= 0) { count++; pos += k.length(); }
        }
        if (count > 0) themes.put(new JSONObject().put("name", name).put("count", count));
        return count;
    }

    private String callInvestmentAi(AiCfg cfg,String source) throws Exception {
        String sys="Bạn là CIO macro/risk analyst. Chỉ dùng tài liệu Federal Reserve được cung cấp; không bịa số liệu, không tạo trích dẫn giả. Mục tiêu là tạo decision-quality research, không phải tóm tắt báo. Trả tiếng Việt theo cấu trúc: 1) POLICY DELTA: điều gì thực sự mới/quan trọng 2) FACTS vs INFERENCE 3) TRANSMISSION: tác động có điều kiện qua US2Y/US10Y/real yield/USD/credit/liquidity rồi mới tới equity/gold/BTC 4) SOROS/REFLEXIVITY: narrative nào có thể tự củng cố hoặc bị price action phủ định 5) TALEB/FRAGILITY: tail risk, leverage/crowding nào cần tránh; điều gì tạo convexity/optionality 6) GRAHAM/MARGIN OF SAFETY: nếu không có dữ liệu định giá thì nói rõ KHÔNG ĐỦ CƠ SỞ để kết luận rẻ/đắt 7) SCENARIOS bull/base/bear, mỗi scenario có trigger và invalidation 8) DATA TO CONFIRM trong 1-4 tuần tới 9) DECISION IMPACT: bias điều kiện, conviction LOW/MEDIUM/HIGH và lý do; không đưa lệnh mua/bán cá nhân. Ưu tiên sự thay đổi biên (delta) hơn câu chữ lặp lại.";
        return callAi(cfg,sys,source.length()>50000?source.substring(0,50000):source,0.05);
    }

    private void validateComparableDocuments(String expectedCurrentTitle,JSONObject current,JSONObject previous) throws Exception {
        String ct=current.optString("text","").trim(), pt=previous.optString("text","").trim();
        if(ct.length()<500||pt.length()<500) throw new IllegalStateException("Một trong hai tài liệu quá ngắn sau khi làm sạch; không đủ an toàn để so sánh.");
        String cls=docClass(expectedCurrentTitle);
        if("OTHER".equals(cls)) throw new IllegalStateException("Không xác định được họ tài liệu hiện tại.");
        String prevTitle=previous.optString("title","");
        // Generic navigation/about pages are never accepted as a previous policy document.
        String low=prevTitle.toLowerCase(Locale.US);
        if(low.equals("federal open market committee")||low.equals("monetary policy")||low.equals("federal reserve board"))
            throw new IllegalStateException("Bản trước nhận diện thành trang giới thiệu/navigation, không phải tài liệu chính sách. App đã chặn kết quả sai.");
        if(!isComparableIdentity(expectedCurrentTitle,prevTitle,cls) && !"SPEECH".equals(cls) && !"TESTIMONY".equals(cls))
            throw new IllegalStateException("Bản trước không cùng họ tài liệu với bản hiện tại. App đã chặn so sánh sai nguồn.");
    }

    private String callComparisonAi(AiCfg cfg,JSONObject prev,JSONObject cur) throws Exception {
        String p=prev.optString("text","");String c=cur.optString("text","");if(p.length()>38000)p=p.substring(0,38000);if(c.length()>38000)c=c.substring(0,38000);
        String sys="So sánh HAI tài liệu Federal Reserve gần nhất cùng loại. Chỉ dùng nội dung cung cấp. Trả tiếng Việt với các mục: 1) TÓM TẮT KHÁC BIỆT 2) ĐIỂM MỚI/ĐƯỢC THÊM 3) ĐIỂM BỊ GIẢM/NHẤN MẠNH ÍT HƠN 4) THAY ĐỔI VỀ LẠM PHÁT 5) LAO ĐỘNG 6) TĂNG TRƯỞNG 7) LÃI SUẤT/QT/THANH KHOẢN 8) HAWKISH↔DOVISH SHIFT 9) KÊNH TÁC ĐỘNG THỊ TRƯỜNG 10) CÂU/Ý BẰNG CHỨNG. Phân biệt fact và inference, không bịa trích dẫn hoặc số liệu.";
        String user="BẢN TRƯỚC: "+prev.optString("title")+"\n"+p+"\n\n===== BẢN MỚI =====\n"+cur.optString("title")+"\n"+c;
        return callAi(cfg,sys,user,0.05);
    }

    private String findPreviousComparableUrl(String currentUrl,String title,String source) throws Exception {
        String feed="https://www.federalreserve.gov/feeds/press_monetary.xml";
        String src=source==null?"":source.toLowerCase(Locale.US);
        if(src.contains("speech"))feed="https://www.federalreserve.gov/feeds/speeches.xml";
        else if(src.contains("testimony"))feed="https://www.federalreserve.gov/feeds/testimony.xml";
        else if(src.contains("liquidity"))feed="https://www.federalreserve.gov/feeds/clp.xml";

        String cls=docClass(title);
        if("OTHER".equals(cls)) throw new IllegalStateException("Chưa xác định được họ tài liệu để so sánh an toàn. App sẽ không ghép một bài Fed khác loại.");
        List<FeedItem> items=fetchFeed(feed,source==null?"":source);
        int pos=-1;
        for(int i=0;i<items.size();i++){if(items.get(i).link.equals(currentUrl)){pos=i;break;}}
        int startAt=pos>=0?pos+1:0;
        for(int i=startAt;i<items.size();i++){
            FeedItem x=items.get(i);
            if(x.link.equals(currentUrl))continue;
            if(!docClass(x.title).equals(cls))continue;
            if(!isComparableIdentity(title,x.title,cls))continue;
            return x.link;
        }
        throw new IllegalStateException("Không tìm thấy bản trước cùng họ "+cls+" trong nguồn Fed hiện có. App đã từ chối so sánh với tài liệu khác loại để tránh kết luận sai.");
    }

    private boolean isComparableIdentity(String currentTitle,String previousTitle,String cls){
        String a=(currentTitle==null?"":currentTitle).toLowerCase(Locale.US);
        String b=(previousTitle==null?"":previousTitle).toLowerCase(Locale.US);
        if("DISCOUNT_MINUTES".equals(cls)) return a.contains("discount rate")&&b.contains("discount rate")&&a.contains("minutes")&&b.contains("minutes");
        if("FOMC_MINUTES".equals(cls)) return a.contains("minutes")&&b.contains("minutes")&&(a.contains("federal open market committee")||a.contains("fomc"))&&(b.contains("federal open market committee")||b.contains("fomc"));
        if("FOMC_STATEMENT".equals(cls)) return (a.contains("statement")||a.contains("fomc"))&&(b.contains("statement")||b.contains("fomc"));
        if("MPR".equals(cls)) return a.contains("monetary policy report")&&b.contains("monetary policy report");
        return true;
    }

    private String docClass(String title){
        String t=(title==null?"":title).toLowerCase(Locale.US);
        if(t.contains("discount rate")&&t.contains("minutes"))return"DISCOUNT_MINUTES";
        if(t.contains("minutes")&&(t.contains("federal open market committee")||t.contains("fomc")))return"FOMC_MINUTES";
        if((t.contains("statement")||t.contains("press release"))&&(t.contains("fomc")||t.contains("federal open market committee")))return"FOMC_STATEMENT";
        if(t.contains("monetary policy report"))return"MPR";
        if(t.contains("beige book"))return"BEIGE_BOOK";
        if(t.contains("financial stability report"))return"FIN_STABILITY";
        if(t.contains("speech")||t.contains("remarks")||t.contains("address"))return"SPEECH";
        if(t.contains("testimony"))return"TESTIMONY";
        return"OTHER";
    }

    private String readLimited(InputStream input, int maxChars) throws Exception {
        if(input==null) return "";
        try(BufferedReader br=new BufferedReader(new InputStreamReader(input,StandardCharsets.UTF_8))){
            StringBuilder sb=new StringBuilder(Math.min(maxChars,16384));
            char[] buf=new char[8192]; int n;
            while((n=br.read(buf))!=-1){
                if(sb.length()+n>maxChars) throw new IllegalStateException("Phản hồi nguồn quá lớn; request đã bị dừng an toàn, không retry liên tục");
                sb.append(buf,0,n);
            }
            return sb.toString();
        }
    }

    private JSONObject httpJson(String urlString) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlString).openConnection();
        c.setConnectTimeout(12000); c.setReadTimeout(18000);
        c.setRequestProperty("User-Agent", "MarketOS/26.1 Android");
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("Cache-Control", "no-cache, no-store, max-age=0");
        c.setRequestProperty("Pragma", "no-cache");
        int code = c.getResponseCode();
        String body = readLimited(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream(), 2_000_000);
        c.disconnect();
        StringBuilder sb = new StringBuilder(body);
        if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + ": " + sb.substring(0, Math.min(240, sb.length())));
        return new JSONObject(sb.toString());
    }

    private JSONArray httpJsonArray(String urlString) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(urlString).openConnection();
        c.setConnectTimeout(12000);c.setReadTimeout(18000);c.setRequestProperty("User-Agent","MarketOS/26.1 Android");c.setRequestProperty("Accept","application/json");
        int code=c.getResponseCode();String body=readLimited(code>=200&&code<300?c.getInputStream():c.getErrorStream(),2_000_000);StringBuilder sb=new StringBuilder(body);c.disconnect();
        if(code<200||code>=300)throw new IllegalStateException("HTTP "+code+": "+sb.substring(0,Math.min(240,sb.length())));
        return new JSONArray(sb.toString());
    }

    private JSONObject fetchFred(String rawId) throws Exception {
        String id=(rawId==null?"":rawId.trim().toUpperCase(Locale.US)); if(!id.matches("[A-Z0-9_.-]{1,64}")) throw new IllegalArgumentException("FRED series ID không hợp lệ");
        java.util.Calendar cal=java.util.Calendar.getInstance();cal.add(java.util.Calendar.YEAR,-2);String cosd=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(cal.getTime());
        String url="https://fred.stlouisfed.org/graph/fredgraph.csv?id="+URLEncoder.encode(id,"UTF-8")+"&cosd="+cosd+"&_ts="+System.currentTimeMillis();HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(18000);c.setRequestProperty("User-Agent","MarketOS/26.1 Android");c.setRequestProperty("Cache-Control","no-cache, no-store, max-age=0");c.setRequestProperty("Pragma","no-cache");int code=c.getResponseCode();if(code<200||code>=300)throw new IllegalStateException("FRED HTTP "+code);
        BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));String line=br.readLine();if(line==null||!line.toUpperCase(Locale.US).contains(id))throw new IllegalStateException("Không tìm thấy series "+id);List<String> dates=new ArrayList<>();List<Double> vals=new ArrayList<>();
        while((line=br.readLine())!=null){String[] a=line.split(",",-1);if(a.length<2)continue;String v=a[1].replace("\"","").trim();if(v.isEmpty()||".".equals(v)||"NA".equalsIgnoreCase(v))continue;try{dates.add(a[0].replace("\"","").trim());vals.add(Double.parseDouble(v));}catch(Exception ignored){}}br.close();c.disconnect();if(vals.isEmpty())throw new IllegalStateException("Series chưa có dữ liệu khả dụng");
        int n=vals.size();double value=vals.get(n-1);Double previous=n>1?vals.get(n-2):null;JSONObject p=new JSONObject();p.put("ok",true);p.put("id",id);p.put("date",dates.get(n-1));p.put("value",value);if(previous!=null){double delta=value-previous;p.put("previous",previous);p.put("delta",delta);if(previous!=0)p.put("pct",delta/Math.abs(previous)*100.0);}JSONArray hist=new JSONArray();int start=Math.max(0,n-60);for(int i=start;i<n;i++){JSONObject x=new JSONObject();x.put("date",dates.get(i));x.put("value",vals.get(i));hist.put(x);}p.put("history",hist);p.put("updatedAt",isoNow());p.put("source","FRED");p.put("sourceUrl","https://fred.stlouisfed.org/series/"+id);return p;
    }

    private List<FeedItem> scrapeFedIndex(String urlString, String source) throws Exception {
        assertOfficialFedUrl(urlString);
        Document doc=Jsoup.connect(urlString).userAgent("MarketOS/26.1 Android").timeout(18000).maxBodySize(2_000_000)
                .header("Cache-Control","no-cache, no-store, max-age=0").header("Pragma","no-cache").get();
        Element scope=doc.selectFirst("#content"); if(scope==null)scope=doc.selectFirst("main"); if(scope==null)scope=doc.body();
        List<FeedItem> out=new ArrayList<>();
        Set<String> seen=new HashSet<>();
        for(org.jsoup.nodes.Element a:scope.select("a[href]")){
            String abs=a.absUrl("href"); String title=clean(a.text());
            if(abs==null||abs.isEmpty()||title.length()<8)continue;
            if(!abs.startsWith("https://www.federalreserve.gov/"))continue;
            if(isStaticFedLanding(abs,title))continue;
            String low=abs.toLowerCase(Locale.US);
            boolean relevant=low.contains("/newsevents/speech/")||low.contains("/newsevents/pressreleases/")||
                    low.contains("/monetarypolicy/fomc")||low.contains("/monetarypolicy/beigebook")||low.contains("/monetarypolicy/mpr")||
                    low.contains("/releases/")||low.contains("/econres/")||low.contains("/publications/")||low.contains("/supervisionreg/srletters/");
            if(!relevant||!seen.add(abs))continue;
            String date=extractFedDateTight(a);
            // Index fallback must be tied to a visible publication date; otherwise it is probably navigation/static content.
            if(date.isEmpty())continue;
            String typedSource=source;
            if(low.contains("/releases/")) typedSource="Statistical Release";
            else if(low.contains("/newsevents/speech/")) typedSource="Speech";
            else if(low.contains("/newsevents/pressreleases/")) typedSource="Press Release";
            else if(low.contains("/monetarypolicy/")) typedSource="Monetary Policy";
            else if(low.contains("/econres/")) typedSource="Fed Research";
            else if(low.contains("/supervisionreg/srletters/")) typedSource="Supervision";
            else if(low.contains("/publications/")) typedSource="Publication";
            title = contextualFedIndexTitle(a, title, typedSource);
            FeedItem x=new FeedItem();x.title=title;x.link=abs;x.pubDate=date;x.description="";x.source=typedSource;x.epoch=parseFlexibleFedDate(date);out.add(x);
            if(out.size()>=80)break;
        }
        return out;
    }


    private static boolean genericFedIndexLabel(String title) {
        String t=(title==null?"":title).trim().toLowerCase(Locale.US);
        return t.equals("statistical release") || t.equals("publication") ||
                t.equals("feds notes") || t.equals("press release") ||
                t.equals("foia") || t.equals("supervision and regulation letter") ||
                t.equals("supervision") || t.equals("feds") || t.equals("ifdp") ||
                t.matches("^(sr|feds|ifdp)\\s+\\d{2,4}[-–]\\d+.*");
    }

    private static String stripFedContextNoise(String raw, String title, String typedSource) {
        String x=clean(raw);
        if(x.isEmpty())return "";
        x=x.replaceAll("(?i)\\b(Last Update|Please enable JavaScript).*", "").trim();
        x=x.replaceAll("\\s+", " ").trim();
        if(title!=null && !title.trim().isEmpty()) {
            x=x.replaceFirst("(?i)^\\Q"+title.trim()+"\\E\\s*[-·:]?\\s*", "");
        }
        if(typedSource!=null && !typedSource.trim().isEmpty()) {
            x=x.replaceFirst("(?i)^\\Q"+typedSource.trim()+"\\E\\s*[-·:]?\\s*", "");
        }
        x=x.replaceFirst("^\\d{1,2}/\\d{1,2}/\\d{4}\\s*", "");
        x=x.replaceFirst(
                "^(January|February|March|April|May|June|July|August|September|October|November|December)\\s+\\d{1,2},\\s+\\d{4}\\s*",
                "");
        return x.trim();
    }

    private static String contextualFedIndexTitle(org.jsoup.nodes.Element a, String title, String typedSource) {
        String base=clean(title);
        if(a==null || !genericFedIndexLabel(base))return base;
        List<String> tries=new ArrayList<>();
        org.jsoup.nodes.Element p=a.parent();
        if(p!=null){
            tries.add(p.text());
            org.jsoup.nodes.Element n=p.nextElementSibling();
            if(n!=null)tries.add(n.text());
        }
        org.jsoup.nodes.Element n=a.nextElementSibling();
        if(n!=null)tries.add(n.text());
        for(String raw:tries){
            String x=stripFedContextNoise(raw,base,typedSource);
            if(x.length()>=12 && !x.equalsIgnoreCase(base)){
                if(x.length()>180){
                    x=x.substring(0,180).replaceAll("\\s+\\S*$","").trim()+"…";
                }
                return base+" · "+x;
            }
        }
        return base;
    }

    private static boolean isStaticFedLanding(String url, String title) {
        String u=(url==null?"":url).toLowerCase(Locale.US).replaceAll("[?#].*$","");
        String t=(title==null?"":title).trim().toLowerCase(Locale.US);
        Set<String> exact=new HashSet<>(Arrays.asList(
                "https://www.federalreserve.gov/monetarypolicy/fomc.htm",
                "https://www.federalreserve.gov/monetarypolicy.htm",
                "https://www.federalreserve.gov/newsevents.htm",
                "https://www.federalreserve.gov/publications.htm",
                "https://www.federalreserve.gov/econres.htm",
                "https://www.federalreserve.gov/releases.htm"));
        if(exact.contains(u))return true;
        return t.equals("federal open market committee")||t.equals("about the fomc")||
                t.equals("monetary policy")||t.equals("news & events")||t.equals("publications")||
                t.equals("research & analysis")||t.startsWith("accessible keys for video");
    }

    private static String extractFedDateTight(org.jsoup.nodes.Element a){
        if(a==null)return"";
        org.jsoup.nodes.Element cur=a;
        for(int depth=0;depth<3&&cur!=null;depth++,cur=cur.parent()){
            String d=extractFedDate(clean(cur.text())); if(!d.isEmpty())return d;
            org.jsoup.nodes.Element p=cur.previousElementSibling();
            for(int i=0;i<2&&p!=null;i++,p=p.previousElementSibling()){
                d=extractFedDate(clean(p.text())); if(!d.isEmpty())return d;
            }
        }
        return"";
    }

    private static String extractFedDateNear(org.jsoup.nodes.Element a){
        if(a==null)return"";
        org.jsoup.nodes.Element cur=a;
        for(int depth=0;depth<4&&cur!=null;depth++,cur=cur.parent()){
            String d=extractFedDate(clean(cur.text())); if(!d.isEmpty())return d;
            org.jsoup.nodes.Element p=cur.previousElementSibling();
            for(int i=0;i<8&&p!=null;i++,p=p.previousElementSibling()){
                d=extractFedDate(clean(p.text())); if(!d.isEmpty())return d;
            }
        }
        return"";
    }

    private static String extractFedDate(String text){
        if(text==null)return"";
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("\\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\\s+\\d{1,2},\\s+20\\d{2}\\b",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(text);
        if(m.find())return m.group();
        m=java.util.regex.Pattern.compile("\\b\\d{1,2}/\\d{1,2}/20\\d{2}\\b").matcher(text);if(m.find())return m.group();return"";
    }
    private static long parseFlexibleFedDate(String value){
        if(value==null||value.trim().isEmpty())return 0L;String[] ps={"MMMM d, yyyy","MMM d, yyyy","M/d/yyyy"};for(String x:ps)try{Date d=new SimpleDateFormat(x,Locale.US).parse(value.trim());if(d!=null)return d.getTime();}catch(Exception ignored){}return parseRssDate(value);
    }

    private List<FeedItem> fetchFeed(String urlString,String source) throws Exception {
        String sep=urlString.contains("?")?"&":"?";
        HttpURLConnection c=(HttpURLConnection)new URL(urlString+sep+"_ts="+System.currentTimeMillis()).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setRequestProperty("User-Agent","MarketOS/26.1 Android");c.setRequestProperty("Accept","application/rss+xml, application/xml, text/xml, */*");c.setRequestProperty("Cache-Control","no-cache, no-store, max-age=0");c.setRequestProperty("Pragma","no-cache");int code=c.getResponseCode();if(code<200||code>=300)throw new IllegalStateException("Fed feed HTTP "+code);
        XmlPullParserFactory f=XmlPullParserFactory.newInstance();f.setNamespaceAware(false);XmlPullParser p=f.newPullParser();p.setInput(new BufferedInputStream(c.getInputStream()),"UTF-8");List<FeedItem> out=new ArrayList<>();FeedItem cur=null;String tag="";int ev=p.getEventType();while(ev!=XmlPullParser.END_DOCUMENT){if(ev==XmlPullParser.START_TAG){tag=p.getName().toLowerCase(Locale.US);if("item".equals(tag))cur=new FeedItem();}else if(ev==XmlPullParser.TEXT&&cur!=null){String tx=p.getText();if(tx!=null){if("title".equals(tag))cur.title+=tx;else if("link".equals(tag))cur.link+=tx;else if("pubdate".equals(tag))cur.pubDate+=tx;else if("description".equals(tag))cur.description+=tx;}}else if(ev==XmlPullParser.END_TAG){String end=p.getName().toLowerCase(Locale.US);if("item".equals(end)&&cur!=null){cur.source=source;cur.title=clean(cur.title);cur.link=cur.link.trim();cur.pubDate=cur.pubDate.trim();cur.epoch=parseRssDate(cur.pubDate);out.add(cur);cur=null;}tag="";}ev=p.next();}c.disconnect();return out;
    }

    private void send(String fn,String json){
        final String q=JSONObject.quote(json);
        runOnUiThread(()->{
            if(destroyed.get()||webView==null)return;
            webView.evaluateJavascript("if(window."+fn+") window."+fn+"(JSON.parse("+q+"));",null);
        });
    }
    private void sendError(String fn,Exception e){try{JSONObject p=new JSONObject();p.put("ok",false);p.put("error",friendlyAiError(e));send(fn,p.toString());}catch(Exception ignored){}}
    private void sendReqError(String fn,String requestId,Exception e){try{JSONObject p=new JSONObject();p.put("ok",false);p.put("requestId",requestId);p.put("error",friendlyAiError(e));send(fn,p.toString());}catch(Exception ignored){}}
    private String friendlyAiError(Exception e){String m=e==null?"Lỗi không xác định":String.valueOf(e.getMessage());String low=m.toLowerCase(Locale.US);if(low.contains("http 401")||low.contains("invalid api key"))return "API key không hợp lệ hoặc chưa được cấp quyền.";if(low.contains("http 404")||low.contains("not_found")||low.contains("no longer available"))return "Model không khả dụng. Hãy chọn AUTO để app tự chuyển sang Gemini Flash hiện hành.";if(low.contains("http 429")||low.contains("resource_exhausted"))return "API đang vượt hạn mức/rate limit. App dừng ở lỗi 429 để tránh đốt quota; hãy thử lại thủ công sau.";if(low.contains("http 503")||low.contains("unavailable")||low.contains("high demand"))return "Gemini đang quá tải tạm thời (503). App đã tự retry và thử model dự phòng; hãy bấm lại sau ít phút nếu tất cả model đều bận.";if(low.contains("http 500")||low.contains("http 502")||low.contains("http 504"))return "Máy chủ AI đang lỗi tạm thời. App đã retry/fallback nhưng chưa thành công.";if(low.contains("timeout"))return "API phản hồi quá chậm hoặc hết thời gian chờ.";return m.length()>420?m.substring(0,420)+"…":m;}
    private void sendFredError(String id,Exception e){try{JSONObject p=new JSONObject();p.put("ok",false);p.put("id",id);p.put("error",e.getMessage());p.put("updatedAt",isoNow());send("onFredSeriesPayload",p.toString());}catch(Exception ignored){}}
    private void sendFredBatchError(String id,String batchId,Exception e){try{JSONObject p=new JSONObject();p.put("ok",false);p.put("id",id);p.put("batchId",batchId);p.put("error",e.getMessage());p.put("updatedAt",isoNow());send("onFredSeriesPayload",p.toString());}catch(Exception ignored){}}
    private static String clean(String s){if(s==null)return"";return s.replaceAll("<[^>]+>"," ").replace("&nbsp;"," ").replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").replaceAll("\\s+"," ").trim();}
    private static long parseRssDate(String value){if(value==null)return 0L;String[] ps={"EEE, dd MMM yyyy HH:mm:ss z","EEE, dd MMM yyyy HH:mm z","MM/dd/yyyy"};for(String x:ps)try{Date d=new SimpleDateFormat(x,Locale.US).parse(value.trim());if(d!=null)return d.getTime();}catch(Exception ignored){}return 0L;}
    private static String importance(FeedItem x){String t=(x.title+" "+x.source).toLowerCase(Locale.US);if(t.contains("fomc")||t.contains("minutes")||t.contains("monetary policy report")||t.contains("projection")||t.contains("federal funds")||t.contains("beige book"))return"CRITICAL";if(t.contains("chair")||t.contains("economic outlook")||t.contains("testimony")||t.contains("balance sheet")||t.contains("liquidity"))return"HIGH";return"NORMAL";}
    private static String isoNow(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",Locale.US);f.setTimeZone(TimeZone.getDefault());return f.format(new Date());}
    @Override protected void onStart(){
        super.onStart();
        if(webView!=null){webView.onResume();notifyWebLifecycle("MarketLifecycleResume");}
    }
    @Override protected void onStop(){
        if(webView!=null){notifyWebLifecycle("MarketLifecyclePause");webView.onPause();}
        super.onStop();
    }
    @Override public void onTrimMemory(int level){
        super.onTrimMemory(level);
        if(level>=ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW){
            inFlight.clear();
            if(webView!=null)webView.clearCache(false);
        }
    }
    @Override protected void onDestroy(){
        destroyed.set(true);
        inFlight.clear();
        executor.shutdownNow();
        if(enViTranslator!=null)enViTranslator.close();
        if(webView!=null){
            webView.removeJavascriptInterface("MarketNative");
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.clearHistory();
            webView.removeAllViews();
            webView.destroy();
            webView=null;
        }
        super.onDestroy();
    }
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
