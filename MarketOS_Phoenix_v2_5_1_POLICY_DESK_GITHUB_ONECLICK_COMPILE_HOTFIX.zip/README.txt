MarketOS Phoenix v2.5.1 Policy Desk - Compile Hotfix

Upload/extract this package at repository root and run the workflow:
Build MarketOS Phoenix v2.5.1 APK - COMPILE HOTFIX

This package fixes PdfViewerActivity Java compilation and keeps the SDK workflow hotfix (no sdkmanager/setup-android).
