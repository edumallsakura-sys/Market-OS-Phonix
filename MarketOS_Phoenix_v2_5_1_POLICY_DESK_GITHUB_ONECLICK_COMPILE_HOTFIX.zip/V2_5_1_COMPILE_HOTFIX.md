# V2.5.1 Compile Hotfix

The V2.5 Policy Desk reached Java compilation but failed in `PdfViewerActivity.java` because the code called a non-existent Android API:

`Button.setTextAllCaps(false)`

It is replaced with the valid inherited `TextView` API:

`Button.setAllCaps(false)`

No Policy Desk feature is removed. The original-layout PDF renderer, page navigation, in-app PDF viewing, source fact-check button, bilingual Investor Source and Fed/FRED feeds remain unchanged.

Build pipeline is also unified on Ubuntu 24.04 + the preinstalled Android SDK 35, with no `android-actions/setup-android` or `sdkmanager` call.
