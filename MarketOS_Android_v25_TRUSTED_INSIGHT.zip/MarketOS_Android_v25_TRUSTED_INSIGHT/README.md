# Market OS v23 — Fact-Check Coin Engine

Market OS v23 corrects the main methodological gaps found in the v22 audit.

Highlights:
- real Binance Spot universe discovery instead of a hard-coded coin list
- sector + meme filters
- rejected coin reasons
- exact original 10-category /100 prompt score
- ambiguous CoinGecko ticker protection + manual ID override
- dynamic DefiLlama gecko_id mapping
- Binance Spot 4H/1D/1W/1M technical evidence
- unlock UNKNOWN semantics (no fake $0)
- Gemini grounded structured evidence → validated gate merge
- Loaded/Fresh/Stale FRED semantics

Version 23.0.0 / versionCode 26.
Universal FINAL GitHub workflow remains unchanged.


## v25 Trusted Insight
- Strict Fed article ingestion and document de-duplication.
- FRED decision readiness uses critical functional groups instead of raw observation age.
- Coin Lab /30 is explicitly research priority with component scores.
- Dynamic stablecoin exclusion includes live DefiLlama stablecoin cache.
- Native chain economics fallback via exact CoinGecko ID -> DefiLlama chain context.
- Grounded research can close native network-economics/security/supply-schedule gates when sources are actually backed.
- Conclusion refresh is due-only and respects retry/backoff.
- Investment Committee adds deterministic Insight: Bây giờ / Vì sao / Cần xác nhận tiếp.
