# Market OS v16 — Primary Live Sync / Source Audit

Audited from the actual v15.1 APK/source. No hard-coded market/demo values are used for live cards, but v15.1 could look frozen because macro releases are low-frequency and Fed relied mainly on RSS.

v16 changes:
- Federal Reserve RSS requests use no-cache and cache-busting.
- Official federalreserve.gov HTML indexes are a fallback/supplement for news, speeches and monetary policy.
- Fed refresh is deduplicated and runs every 5 minutes only while relevant tabs are active.
- Fed payload exposes latest official publication date/title and source mode.
- UI Source Audit shows whether the source is actually updating.
- FRED CSV requests force no-cache/cache-bust while retaining the observation date (publication frequency is not mislabelled as realtime).
- Crypto remains CoinGecko/Binance market data; Gold remains near-live market quote with daily fallback.
- Resource Safety Contract remains in force.
- Universal FINAL GitHub flow unchanged.
