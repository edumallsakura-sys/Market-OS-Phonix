# Market OS v9 — Deep Document Intelligence + Gemini Native

## Nâng cấp chính
- Sửa API Gemini: provider riêng, dùng `x-goog-api-key` và endpoint `generativelanguage.googleapis.com`; không gửi Gemini key dưới dạng `Authorization: Bearer`.
- Mặc định Gemini model: `gemini-2.5-flash`; endpoint Gemini có thể để trống để app tự tạo.
- Nút **Kiểm tra API** trước khi dịch/phân tích.
- API key được mã hóa bằng Android Keystore AES-GCM; tự migrate key cũ khỏi SharedPreferences plaintext.
- Fed Deep Reader: tự tìm link HTML/PDF của tài liệu; ưu tiên HTML đầy đủ, nếu trang chỉ là wrapper/press release thì đọc sâu attachment PDF bằng PDFBox.
- Xem HTML ngay trong app bằng WebView giới hạn domain federalreserve.gov.
- Xem PDF ngay trong app bằng PdfRenderer, có chuyển trang.
- Dịch sát nghĩa bằng AI theo từng chunk, giữ số liệu/ngày/thuật ngữ; ML Kit vẫn là fallback on-device.
- AI Research Note: tóm tắt điều hành, narrative/chính sách, kênh tác động US2Y/US10Y/USD/Gold/Equity/BTC, dữ liệu xác nhận và điều kiện vô hiệu.
- So sánh hai bản gần nhất cùng loại từ feed Fed: tải cả hai tài liệu, đọc sâu HTML/PDF rồi AI so sánh thay đổi về inflation/labor/growth/rates/QT/liquidity và hawkish-dovish shift.
- Giữ nguyên Market Regime, FRED Data Quality Gate, Cross-Asset Confirmation, BTC/ETH native và adaptive icon.

## Gemini
Trong Cài đặt > Dịch & AI:
1. Provider: Google Gemini API
2. Endpoint: để trống
3. Model: gemini-2.5-flash
4. Nhập API key
5. Lưu cấu hình > Kiểm tra API

Lưu ý: Google đang chuyển Gemini API sang authorization keys trong năm 2026. Nếu key hợp lệ nhưng vẫn bị 401, tạo key mới trong Google AI Studio và bảo đảm key được phép dùng Gemini API.

## Build
Dùng file `.github/workflows/build-apk.yml` hoặc gói ONECLICK v9. Artifact: `MarketOS-v9-Android-APKs`.
