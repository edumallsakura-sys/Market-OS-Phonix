MarketOS GitHub ONE-CLICK v35.2 — INVESTOR FOCUS

MỤC ĐÍCH
- Giữ nguyên V35 engine/evidence/track record, nhưng UI mặc định ưu tiên quyết định đầu tư.
- Macro raw, provider keys, Evidence Ledger, System Health và AI research vẫn còn nhưng được thu gọn/drill-down.
- Xóa dead bridge/helper không có caller/handler; không cắt feed đang dùng.

CÁCH BUILD
1) Giải nén file ONE-CLICK này vào root repo GitHub.
2) Commit/push toàn bộ .github/workflows/build-apk.yml + projects/*.zip.
3) Mở Actions > Universal Android ZIP Builder V35.2 > Run workflow.
4) Tải artifact Android-APKs.

CI bắt buộc chạy V35.2 static audit + JS syntax + Android assembleDebug trước khi upload APK.

Source: projects/MarketOS_Android_v35_2_INVESTOR_FOCUS.zip
Version: 35.0.2 / versionCode 41
