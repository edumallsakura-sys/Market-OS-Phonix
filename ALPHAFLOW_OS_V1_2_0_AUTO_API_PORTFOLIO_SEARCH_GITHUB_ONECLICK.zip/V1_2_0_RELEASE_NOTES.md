# ALPHAFLOW OS v1.2.0

## API simplification
The app now presents only three user-entered API fields: FRED, Gemini and Groq. FRED is required for FRED macro data. For AI, only one of Gemini or Groq is required; when both are configured the Copilot tries Gemini first and automatically falls back to Groq.

CoinGecko market/search/global calls use the public endpoint automatically and still support an optional previously-saved/build-time Demo key. Binance Spot chart/ticker/depth uses public market-data endpoints and does not request a user API key.

## Portfolio search
Add Position now searches CoinGecko with 500 ms debounce. Results show icon, symbol, name, CoinGecko ID and rank. Selecting a coin fills ID + symbol and fetches a current quote when available. Manual fields remain editable so the old workflow is not removed.

## Build safeguards
The GitHub workflow keeps the nested ZIP auto-discovery logic, TypeScript strict check, Expo prebuild, standalone JS bundle configuration, release/debug fallback and post-build `assets/index.android.bundle` verification.
