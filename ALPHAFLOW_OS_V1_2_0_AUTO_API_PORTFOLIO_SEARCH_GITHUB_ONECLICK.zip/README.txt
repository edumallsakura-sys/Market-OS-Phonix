ALPHAFLOW OS v1.2.0 — AUTO API + PORTFOLIO SEARCH

UPLOAD TO GITHUB:
1) Extract this ONECLICK ZIP.
2) Upload/overwrite ALL extracted contents in the repository root.
3) At minimum, repo must contain:
   .github/workflows/build-apk.yml
   projects/ALPHAFLOW_OS_SOURCE.zip
4) Run GitHub Actions workflow:
   Build ALPHAFLOW OS v1.2.0 APK - AUTO API + PORTFOLIO SEARCH
5) Download artifact:
   ALPHAFLOW-OS-v1.2.0-STANDALONE-APK

FEATURES IN THIS RELEASE:
- FRED + ONE of Gemini/Groq is enough for full macro + AI setup.
- CoinGecko and Binance public market data are automatic; no user key required by default.
- Gemini -> Groq automatic fallback.
- Portfolio coin search/autocomplete identical in spirit to Watchlist Add Coin.
- Search result auto-fills CoinGecko ID + symbol and can use current price as Entry.
- Manual ID/Symbol input is retained for offline/fallback use.
- Standalone JavaScript bundle validation remains enabled.
