# ALPHAFLOW OS v1.1.4 — NODE CACHE HOTFIX

## Lỗi đã sửa
GitHub Actions dừng ở bước `Set up Node.js 22` với lỗi:

`Some specified paths were not resolved, unable to cache dependencies.`

Nguyên nhân: workflow bật npm cache trước khi `projects/ALPHAFLOW_OS_SOURCE.zip` được giải nén, vì vậy `actions/setup-node` không thể tìm dependency path trong repo.

## Sửa trong v1.1.4
- Bỏ `cache: npm` và `cache-dependency-path` khỏi bước setup-node trước khi giải nén.
- Giữ Node 22.13.1.
- Giữ JDK 17.
- Giữ Android SDK 36 preinstalled.
- Giữ source autodiscovery.
- Giữ static audit, TypeScript strict check, Expo prebuild và Gradle wrapper build.
- Không cắt hoặc thay đổi chức năng app.

## File cần có trên GitHub
- `.github/workflows/build-apk.yml`
- `projects/ALPHAFLOW_OS_SOURCE.zip`
