package com.marketos.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PdfViewerActivity extends Activity {
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private PdfRenderer renderer; private ParcelFileDescriptor descriptor; private int pageIndex=0;
    private ImageView image; private TextView pageText,status; private Button prev,next;

    @Override protected void onCreate(Bundle b){super.onCreate(b);String url=getIntent().getStringExtra("url");if(!isAllowed(url)){finish();return;}buildUi();status.setText("Đang tải PDF chính thức từ Federal Reserve…");executor.execute(()->load(url));}
    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,16,16,16);root.setBackgroundColor(0xff07111d);
        status=new TextView(this);status.setTextColor(0xffd9e5f0);status.setTextSize(15);root.addView(status,new LinearLayout.LayoutParams(-1,-2));
        image=new ImageView(this);image.setAdjustViewBounds(true);image.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,0,1);ip.topMargin=12;root.addView(image,ip);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER);prev=new Button(this);prev.setText("← Trước");next=new Button(this);next.setText("Sau →");pageText=new TextView(this);pageText.setTextColor(0xffffffff);pageText.setPadding(24,0,24,0);bar.addView(prev);bar.addView(pageText);bar.addView(next);root.addView(bar,new LinearLayout.LayoutParams(-1,-2));setContentView(root);
        prev.setOnClickListener(v->{if(pageIndex>0){pageIndex--;render();}});next.setOnClickListener(v->{if(renderer!=null&&pageIndex<renderer.getPageCount()-1){pageIndex++;render();}});
    }
    private void load(String url){try{File f=new File(getCacheDir(),"marketos_document.pdf");HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(45000);c.setRequestProperty("User-Agent","MarketOS/9.0 Android");int code=c.getResponseCode();if(code<200||code>=300)throw new IllegalStateException("PDF HTTP "+code);try(InputStream is=c.getInputStream();FileOutputStream os=new FileOutputStream(f)){byte[] buf=new byte[16384];int n;long total=0;while((n=is.read(buf))>0){os.write(buf,0,n);total+=n;if(total>40_000_000)throw new IllegalStateException("PDF quá lớn");}}c.disconnect();descriptor=ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY);renderer=new PdfRenderer(descriptor);runOnUiThread(()->{status.setText("PDF · nguồn federalreserve.gov");render();});}catch(Exception e){runOnUiThread(()->status.setText("Không mở được PDF: "+e.getMessage()));}}
    private void render(){if(renderer==null||renderer.getPageCount()==0)return;try(PdfRenderer.Page page=renderer.openPage(pageIndex)){int target=Math.max(900,getResources().getDisplayMetrics().widthPixels-32);float ratio=(float)page.getHeight()/Math.max(1,page.getWidth());int h=Math.max(1200,(int)(target*ratio));Bitmap bmp=Bitmap.createBitmap(target,h,Bitmap.Config.ARGB_8888);page.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);image.setImageBitmap(bmp);pageText.setText((pageIndex+1)+" / "+renderer.getPageCount());prev.setEnabled(pageIndex>0);next.setEnabled(pageIndex<renderer.getPageCount()-1);}catch(Exception e){status.setText("Lỗi render PDF: "+e.getMessage());}}
    private boolean isAllowed(String url){try{Uri u=Uri.parse(url);String h=u.getHost();return "https".equalsIgnoreCase(u.getScheme())&&h!=null&&h.endsWith("federalreserve.gov")&&u.getPath()!=null&&u.getPath().toLowerCase().endsWith(".pdf");}catch(Exception e){return false;}}
    @Override protected void onDestroy(){executor.shutdownNow();try{if(renderer!=null)renderer.close();}catch(Exception ignored){}try{if(descriptor!=null)descriptor.close();}catch(Exception ignored){}super.onDestroy();}
}
