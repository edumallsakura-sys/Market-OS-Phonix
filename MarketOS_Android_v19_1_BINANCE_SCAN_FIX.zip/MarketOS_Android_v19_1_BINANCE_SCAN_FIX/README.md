# Market OS v19.1 — Binance Scan Hotfix

Fix:
- Coin Lab no longer downloads the entire Binance MINI 24h universe in one response.
- exchangeInfo is fetched once.
- Eligible USDT Spot symbols are split into chunks of 40.
- ticker/24hr MINI is fetched per chunk and merged locally.
- Each response remains bounded by the app's network safety cap.
- No automatic retry is added; scan remains user-triggered.

Federal/FRED logic is unchanged from v19.
As of the current check on 2026-09-08 morning Asia/Vietnam, Federal Reserve News & Events latest headline is still 2026-09-04.
