MARKET OS v35.3 — LEAN INVESTOR CORE

Upload TOÀN BỘ nội dung gói ONE-CLICK này vào root repo GitHub, commit/push,
rồi Actions -> chạy workflow build -> tải artifact Android-APKs.

Project nguồn: projects/MarketOS_Android_v35_3_LEAN_INVESTOR_CORE.zip

V35.3 — LEAN INVESTOR CORE (theo yêu cầu + xác nhận trực tiếp từ bạn):

Trước khi cắt gì, đã audit tĩnh toàn bộ v35.2.2 độc lập (không tin docs):
39/39 bridge method Java<->JS khớp 100%, 0 hàm JS chết, 0 onclick gãy — tức là
KHÔNG còn "mã thừa/nút ảo" theo nghĩa đen (v35.2/v35.2.1/v35.2.2 đã dọn trước
rồi). Phần cắt lần này là quyết định PHẠM VI SẢN PHẨM, không phải sửa bug:

ĐÃ CẮT (lớp đọc/UX tiện ích, không đụng đến engine ra quyết định):
- Dịch on-device ML Kit (translateToVietnamese/prepareLocalTranslator/
  translateFedTitles) + dependency mlkit:translate — đây chính là mảng từng
  gây lỗi compile ở v35.2.1, cắt hẳn thay vì vá tiếp.
- Dịch AI trùng lặp (testAiTranslator/translateWithAi/nút "Kiểm tra API") —
  API key AI vẫn giữ nguyên, vẫn dùng cho AI research coin/market/Fed.
- Trình xem HTML trong app (openHtmlInApp/DocumentWebActivity.java).
- Trình xem PDF trong app (openPdfInApp/PdfViewerActivity.java) — dependency
  pdfbox-android và code trích xuất text PDF (extractPdfText/PDDocument) VẪN
  GIỮ vì phục vụ phân tích Fed (compareWithPrevious/analyzeWithAi), khác với
  UI "xem PDF" đã bị cắt.

GIỮ NGUYÊN 100%: macro engine + recession nowcast, BIS/TIC offshore, CFTC
positioning, crypto capital flow (stablecoin/ETF/bridges/options/derivatives),
Coin Selection Lab + AI research coin, Evidence Graph (Arkham/Tokenomist/
governance/SEC-CFTC), so sánh/phân tích tuyên bố Fed, Track Record hash-chain,
portfolio sizing.

Bắt được và sửa 1 bug thật trong lúc dọn: code cũ set .style.display trên nút
htmlBtn/pdfBtn đã xoá -> sẽ crash null-reference mỗi lần mở bài Fed. Đã sửa.

Kiểm chứng: native bridge parity 32/32, callback parity 24/24, node --check
JS pass, Java brace cân bằng, v35_static_audit.py (đã cập nhật cùng file,
cùng CI gate) PASS 232/232 checks.

Đọc chi tiết: V35_3_LEAN_INVESTOR_CORE.md trong project nguồn.

Version 35.3.0 / versionCode 44.
