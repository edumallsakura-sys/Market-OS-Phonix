# Market OS v27 — Source Integrity / Decision Quality

## Root fixes
1. Fed dates are stored/sorted by epoch and rendered in Vietnamese `dd/MM/yyyy`. Raw US `9/8/2026` is no longer ambiguous.
2. Policy shows **Latest official** separately from **Latest visible under filters**, so filtering cannot masquerade as a stale feed.
3. Beige Book master URLs are resolved to the official **National Summary** page for deep reading instead of the generic About page.
4. Every Fed document passes a Document Identity Gate before translation/AI: official host, canonical URL, family, title similarity, body density and boilerplate checks. Source mismatch blocks analysis.
5. Fed reader renders canonical URL + content hash + source-only hard facts. Hawk/dove is disabled for statistical releases and Beige Book.
6. Coin Deep DD now exposes a claim-level Evidence Ledger: claim → status → exact source URL → as-of → scope. Generic homepage links no longer count as evidence for mutable numbers.
7. Grounded research sources are rendered per gate. Missing exact source keeps the gate UNKNOWN/LOCKED.
8. Stage A UI now documents the actual v26/v27 `/30` research-priority formula.

## Intentional limits
- No fake token-unlock API. GoPlus lock detail remains PARTIAL and never substitutes for a full vesting schedule.
- No claim is promoted to VERIFIED because an AI paragraph sounds confident.
- FRED remains a macro time-series layer, not a Fed-news feed.
- No higher polling frequency was added. Performance/safety contract remains in force.
