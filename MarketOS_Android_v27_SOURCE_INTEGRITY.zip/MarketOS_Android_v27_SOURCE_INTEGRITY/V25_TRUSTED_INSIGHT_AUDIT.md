# Market OS v25 — Trusted Insight Audit

## Fixed from v24
- Fed index fallback no longer ingests static navigation pages such as the FOMC landing page.
- Article reader deduplicates body blocks, strips video-accessibility boilerplate, and reports verified body/word count/read time rather than presenting character count as investment value.
- FRED decision freshness is separated from full source coverage. Monthly/quarterly observation dates are not treated like release timestamps.
- Investment Committee uses a critical-data gate by functional group; noncritical lag no longer permanently blocks the regime.
- Conclusion refresh only syncs sources that are actually due. It no longer force-refreshes every API.
- Coin Stage A /30 is explicitly decomposed into Spot eligibility 10 + liquidity 10 + activity 5 + timing 5. It is research priority, not an investment score.
- Stablecoin exclusion is dynamic via DefiLlama plus a hard safety list (including USD1/USDe/etc.).
- Native assets can complete economics/security via source-grounded NETWORK/CHAIN research; absence of a DefiLlama protocol mapping no longer means the asset can never pass.
- Full unlock evidence supports vesting or native emission/no-scheduled-unlock paths, but only when grounded to a trusted/official source.
- Summary adds Now / Drivers / Next Confirmation to force a concrete insight rather than vague commentary.

## Still intentionally strict
Some evidence cannot be reliably obtained for every coin from a production-grade free structured API:
full vesting, legal/monitoring risk, team/backer changes, catalyst calendar, native-chain security, and token-specific value capture.
These remain UNKNOWN until grounded research or a direct source resolves them. UNKNOWN is not zero and is not a buy signal.

## Native L1/L2 economics fallback
- If a selected coin has no exact DefiLlama protocol mapping, v25 now checks DefiLlama `/v2/chains` by exact CoinGecko `gecko_id`.
- When matched, UI shows `CHAIN_CONTEXT` and chain TVL instead of misleading all-dash `NO_GECKO_ID_MAPPING`.
- Chain TVL is explicitly **not** treated as token revenue/value capture and does not by itself close the Revenue gate.
- Network economics still requires sourced fees / issuance / burn / staking / value-capture evidence.
