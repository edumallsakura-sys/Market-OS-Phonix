# Market OS v26.1 — Compile Hotfix

Root cause: v26 gọi `contextualFedIndexTitle(a, title, typedSource)` trong
`scrapeFedIndex()` nhưng 3 helper Fed parser không được chèn vào MainActivity.java,
nên GitHub fail ở `:app:compileDebugJavaWithJavac` với `cannot find symbol`.

Đã thêm:
- `genericFedIndexLabel(...)`
- `stripFedContextNoise(...)`
- `contextualFedIndexTitle(...)`

Không bỏ logic đầu tư của v26.
Version 26.1.0 / versionCode 30.
