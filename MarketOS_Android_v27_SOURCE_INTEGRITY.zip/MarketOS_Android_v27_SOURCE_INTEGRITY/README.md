# Market OS v27 — Source Integrity

Decision pipeline: **source identity → exact evidence → freshness → regime → cross-asset confirmation → coin screening → Deep DD → evidence gate → capital gate**.

The v27 priority is correctness before feature count. Fed landing pages cannot be analyzed as if they were the selected article. Mutable claims require exact URLs and timestamps. Unknown data remains UNKNOWN.

Version 27.0.0 / versionCode 31.
