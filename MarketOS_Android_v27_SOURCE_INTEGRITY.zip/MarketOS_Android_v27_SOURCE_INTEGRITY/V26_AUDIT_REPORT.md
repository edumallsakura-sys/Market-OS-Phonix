# Market OS v26 — Auditable Decision Engine

## What changed

### Policy / Fed
- Fed Event Radar now supports 24h / 7D / 30D / All filters.
- Adds investment-relevance filter and data/policy type filters.
- Recent Postings generic labels are enriched with nearby official descriptor text.
- Feed items carry epoch timestamps for deterministic age filtering.
- FRED Data Update Radar is separate from Fed news: FRED confirms macro observations; it is not treated as a news feed.

### Coin Selection Lab
Stage A still discovers the live Binance SPOT/TRADING universe. It does **not** use a hard-coded top-100 list.
After quote/stable/wrapped/meme/sector/liquidity filters, only a bounded liquid pool (max 40) is enriched with 60 daily Binance Spot candles.

Research Priority /30:
- Spot eligibility 6
- Liquidity 8
- Trading activity 4
- Trend / relative strength 6
- Volume expansion 3
- Timing / FOMO penalty 3

This /30 is never an investment score.

### Evidence Lock
`EVIDENCE LOCK` means there is insufficient sourced minimum-data evidence for a capital decision.
It does not mean the coin is bearish or bad.
No missing group is renormalized into a fake /100.

### Cross-asset confirmation
Replaces the old SPX+BTC-only binary confirmation with a 6-input vote:
S&P 500, Nasdaq, BTC 7D, broad USD, 10Y real-yield change, HY OAS change.
Outputs: RISK-ON CONFIRMED / DEFENSIVE CONFIRMED / MIXED-DIVERGENCE / INSUFFICIENT.

### Model disclosure
Macro values shown as `/100` are explicitly labelled internal Signal Indices, not probabilities or externally validated facts.
