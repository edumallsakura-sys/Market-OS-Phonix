# ALPHAFLOW OS v1.1.6 — TypeScript Navigation Hotfix

The v1.1.5 pipeline successfully reached strict TypeScript validation. The only
reported compiler failures were TS2322 at `MainShell.tsx` where the `Main` route
navigation object was passed to Macro and Crypto screens typed with a generic
`NativeStackNavigationProp<RootStackParamList>`.

## Fix

The child screens now explicitly receive the navigation prop for the actual owner
route:

```ts
NativeStackNavigationProp<RootStackParamList, 'Main'>
```

This aligns route-specific `setParams` typing while preserving navigation to
`MacroDetail` and `CoinDetail`.

No feature was removed, no strictness was disabled, and no type-safety escape hatch
(`any`, `@ts-ignore`) was added.

The workflow also sorts old ONECLICK archives by semantic version so a repository
containing both v1.1.4 and v1.1.6 does not accidentally build the older archive.
