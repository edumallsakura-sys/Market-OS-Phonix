ALPHAFLOW OS v1.1.6 — TYPESCRIPT NAVIGATION HOTFIX
===================================================

WHAT FAILED IN v1.1.4/v1.1.5
GitHub reached `npm run typecheck` and TypeScript reported TS2322 in:
  src/navigation/MainShell.tsx -> MacroScreen navigation prop
  src/navigation/MainShell.tsx -> CryptoScreen navigation prop

ROOT CAUSE
React Navigation v7 makes `NativeStackNavigationProp` route-aware. MainShell owns
route `Main`, but MacroScreen/CryptoScreen declared a navigation type without the
current route name. In strict mode the `setParams` signatures become incompatible.

FIX IN v1.1.6
- MacroScreen uses NativeStackNavigationProp<RootStackParamList, 'Main'>.
- CryptoScreen uses NativeStackNavigationProp<RootStackParamList, 'Main'>.
- Crypto Discovery child uses the same route-aware type.
- No `any`, no `@ts-ignore`, no feature removal.
- Android versionCode bumped to 8.
- Workflow now prefers the highest versioned ALPHAFLOW ONECLICK ZIP if old ZIPs
  are still present in the repository, avoiding accidental rebuild of v1.1.4.

RECOMMENDED UPLOAD
1. Extract THIS ZIP locally.
2. Replace `.github/workflows/build-apk.yml` in GitHub with this v1.1.6 file.
3. Upload/replace `projects/ALPHAFLOW_OS_SOURCE.zip`.
4. Run Actions -> `Build ALPHAFLOW OS v1.1.6 APK - TYPESCRIPT NAV HOTFIX`.

ALTERNATIVE AFTER THE v1.1.6 WORKFLOW IS INSTALLED
You can upload the whole ALPHAFLOW v1.1.6 ONECLICK ZIP to repository root. The
workflow can recursively open it. Keeping old ONECLICK ZIPs is supported because
v1.1.6 discovery prefers the highest version number.
