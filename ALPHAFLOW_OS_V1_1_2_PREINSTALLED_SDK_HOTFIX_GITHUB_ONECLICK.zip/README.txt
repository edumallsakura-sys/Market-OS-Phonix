ALPHAFLOW OS v1.1.2 — PREINSTALLED ANDROID SDK HOTFIX

LOI TRONG ANH DA XAC DINH:
- Workflow dung android-actions/setup-android@v3.
- Action nay goi sdkmanager va FAIL truoc ca buoc giai nen source.
- Day KHONG PHAI loi code Macro/Crypto/Chart/AI/Portfolio/Settings.

CACH SUA V1.1.2:
- Bo hoan toan android-actions/setup-android.
- Khong goi sdkmanager de setup SDK.
- Pin runner ubuntu-24.04.
- Kiem tra truc tiep Android Platform 36 + Build Tools 36.0.0 da co san tren runner.
- Sau do moi npm install -> typecheck -> expo-doctor -> expo prebuild -> gradlew assembleDebug.

CACH DUNG:
1. Giai nen file ONECLICK nay.
2. Thay the .github/workflows/build-apk.yml trong repo bang file moi.
3. Upload projects/ALPHAFLOW_OS_V1_1_2_SOURCE.zip.
4. Xoa/disable workflow cu neu con de tranh bam nham.
5. GitHub > Actions > chon:
   Build ALPHAFLOW OS v1.1.2 APK - PREINSTALLED SDK HOTFIX
6. Run workflow.
7. Neu xanh: Artifacts > ALPHAFLOW-OS-v1.1.2-APK.

V1.1.2 KHONG cat/giam bat ky module hay chuc nang nao cua V1.1 Deep Modules.
