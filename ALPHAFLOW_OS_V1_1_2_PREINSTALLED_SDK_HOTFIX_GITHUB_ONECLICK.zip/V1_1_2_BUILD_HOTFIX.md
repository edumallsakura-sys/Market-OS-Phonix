# ALPHAFLOW OS v1.1.2 — Build Hotfix #2

## Root cause from the new screenshot
The job failed at **Set up Android SDK**, inside `android-actions/setup-android@v3`, where its bundled `sdkmanager` exited with code 1. The later steps (SDK 36 verification, source extraction, npm, Expo prebuild, Gradle) never ran.

## Fix
The GitHub-hosted `ubuntu-24.04` image already ships Android SDK Platform 36 and Build Tools 36.0.0, so the workflow now uses that preinstalled toolchain directly and does not run `setup-android` or `sdkmanager` during setup.

The app remains Expo SDK 57 with compileSdkVersion/targetSdkVersion 36 and minSdkVersion 26.

No functional module was removed or simplified.
