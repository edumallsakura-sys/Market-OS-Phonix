# ALPHAFLOW OS v1.4.0 — Intelligence + Portfolio Pro

## What was upgraded without removing working features
Macro, Crypto, Chart, AI Copilot, Alerts/Settings, Policy Desk, Portfolio coin autocomplete, local MMKV persistence and standalone APK safeguards remain present.

## Policy + News Intelligence Pro
- Official-first feeds remain the evidence backbone: Fed, BLS, ECB, BoE, BoJ, SEC and CFTC.
- Adds PBoC and RBI official portals to BEA/Treasury/Fed official navigation.
- Adds one bounded GDELT market-headline request for broader market awareness.
- Secondary items are clearly labelled and article bodies are never scraped into local cache.
- Evidence states are explicit: `PRIMARY`, `MATCHED TO PRIMARY TOPIC`, `SECONDARY · VERIFY`.
- Source rank is displayed as provenance/source-quality context, never as a truth score.
- Morning Brief separates official evidence from secondary headlines.
- Primary HTML comparison now includes stable text hashes, sentence-level added/removed changes, paired changed sentences, theme shifts and transparent rule-based wording flags.
- PDF integrity remains original-source-first with no OCR/reconstruction.

## Portfolio Pro
- BUY / SELL / SET transaction ledger with weighted-average cost.
- Realized/unrealized PnL, fees, gross buys/sells, allocation and oversell protection.
- Legacy v2 positions auto-migrate to explicit corrections.
- CoinGecko search/current-price quick fill/manual fallback preserved.
- BOOK / LEDGER / ANALYTICS views.
- Up to 730 bounded daily equity snapshots and cashflow-sensitive raw max drawdown.
- BTC 30D is market context only, not falsely presented as a portfolio-return benchmark.
- JSON v3 backup/restore plus compatibility with legacy position backup.
- Last known market prices are cached for offline-first reopen.

## Copilot
- Preserves Gemini -> Groq automatic provider/model recovery.
- Adds local Portfolio ledger evidence.
- Policy evidence carries provenance state and source rank.
- Adds portfolio concentration/risk analysis preset.

## Android safety/resource limits
- No new background service or Android permission.
- No infinite `setInterval`/polling loop.
- Policy cache 30 min; primary source concurrency max 3.
- Max 16 official items/source, 28 secondary headlines, 220 Desk items.
- Max 44 cached HTML documents and 80,000 extracted chars/document.
- Max 3,000 portfolio transactions and 730 daily snapshots.
- No OCR/PDF native dependency.
- Shared network AbortController/timeouts and finite retries remain.
- APK artifact is rejected unless the offline JS bundle exists.

Version: **1.4.0**  
Android versionCode: **13**
