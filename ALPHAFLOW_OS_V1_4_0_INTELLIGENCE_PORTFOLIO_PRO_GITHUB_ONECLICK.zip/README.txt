ALPHAFLOW OS v1.4.0 — INTELLIGENCE + PORTFOLIO PRO
==================================================

ONECLICK PACKAGE

Preferred GitHub upload:
1. Extract this ONECLICK ZIP.
2. Upload/replace ALL extracted contents in the repository root.
3. Confirm these two paths exist:
     .github/workflows/build-apk.yml
     projects/ALPHAFLOW_OS_SOURCE.zip
4. GitHub -> Actions ->
   "Build ALPHAFLOW OS v1.4.0 APK - INTELLIGENCE + PORTFOLIO PRO"
   -> Run workflow.

Artifact:
  ALPHAFLOW-OS-v1.4.0-STANDALONE-APK

Expected APK:
  ALPHAFLOW-OS-v1.4.0-standalone.apk

The workflow also understands a ONECLICK ZIP uploaded AS-IS, but replacing the extracted
workflow + projects/ALPHAFLOW_OS_SOURCE.zip is the cleanest repository layout.

This release preserves all existing working modules and upgrades Policy/News evidence,
document comparison, Portfolio transaction accounting/analytics, and Copilot portfolio evidence.
It does NOT add a background Android service, infinite polling, OCR engine, or always-on socket.
