MARKET OS v28 — LOCAL-FIRST + FAST COIN SCAN

Chỉ cần upload TOÀN BỘ nội dung gói ONE-CLICK này vào root repo GitHub.
Sau đó: Actions → Universal Android ZIP Builder FINAL → Run workflow.
Tải artifact: Android-APKs.

Project nguồn: projects/MarketOS_Android_v28_LOCAL_FIRST_FAST_SCAN.zip

v28 sửa trực tiếp:
- Việt hóa tiêu đề Policy/Fed bằng ML Kit on-device.
- Dịch toàn bài trên máy; AI chỉ là tùy chọn/fallback.
- Research nguồn không API; AI 429 không làm hỏng core app.
- Coin scan: 1 exchangeInfo + 1 bulk ticker → shortlist ngay → enrich top 10.
- Không retry storm khi Binance/AI trả 429.
- Giữ Document Identity Gate và Evidence Lock.
