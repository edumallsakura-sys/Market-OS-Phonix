MarketOS GitHub ONE-CLICK V35 — FINAL INVESTMENT COCKPIT

CÁCH DÙNG:
1. Tạo repo GitHub mới hoặc dùng repo build APK hiện có.
2. Upload TOÀN BỘ nội dung ZIP này vào root repo, gồm cả thư mục .github.
3. Commit/push lên main hoặc master.
4. Vào Actions -> Universal Android ZIP Builder V35 -> Run workflow.
5. Khi build xong, tải artifact "Android-APKs".

Workflow sẽ:
- giải nén source an toàn (chặn ZIP traversal),
- tự nhận project Android,
- chạy V35 static integrity/regression audit,
- kiểm JavaScript syntax + XML + duplicate HTML IDs,
- cài Android SDK / Gradle 8.9,
- assembleDebug,
- upload APK artifact.

V35 giữ toàn bộ V29–V34. Track record bắt đầu prospectively từ V34; V35 KHÔNG sửa/backfill snapshot cũ và chỉ thêm factor-vector hash cho snapshot V35.
