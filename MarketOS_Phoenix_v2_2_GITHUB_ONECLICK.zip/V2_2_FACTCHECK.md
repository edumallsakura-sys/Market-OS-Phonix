# Market OS Phoenix v2.2 — Fed Source Fact-check

## Root cause ở v2.1
`fetchFedRadar()` chỉ lấy:
- Monetary Policy RSS
- Speeches RSS
- Testimony RSS
- All Press Releases RSS
- Recent Postings HTML

Như vậy app có master index nhưng không đăng ký trực tiếp các kênh dữ liệu/Board/research quan trọng.

## Nguồn chính thức được bổ sung ở v2.2
- Recent Postings: https://www.federalreserve.gov/recentpostings.htm
- Board Meetings RSS: https://www.federalreserve.gov/feeds/boardmeetings.xml
- FEDS Notes RSS: https://www.federalreserve.gov/feeds/feds_notes.xml
- All Data Download announcements: https://www.federalreserve.gov/feeds/datadownload.xml
- Financial Accounts Z.1 RSS: https://www.federalreserve.gov/feeds/z1.xml
- Monetary policy / press / speeches / testimony RSS vẫn giữ nguyên.

Federal Reserve RSS directory công khai liệt kê Board Meetings, FEDS Notes và các DDP statistical-release announcement feeds.

## Z.1 kiểm chứng
Federal Reserve Recent Postings hiện liệt kê:
- 11/09/2026 — Statistical Release — Financial Accounts of the United States - Z.1.

Z.1 2026:Q2 release:
- release ngày 11/09/2026;
- household & nonprofit net worth +$12.8T, lên $195.9T;
- household debt +5.0% SAAR;
- domestic nonfinancial business debt +4.6% SAAR.

Đây là dữ liệu có giá trị cho wealth effect, leverage, credit impulse và financial conditions; app phải xem nó là HIGH-impact data release chứ không phải tin thường.

## X @federalreserve
X có thể nhanh cho alert, nhưng không được dùng làm canonical evidence trong engine:
- public scraping có thể thay đổi/đòi đăng nhập;
- post có thể chỉ là headline/link;
- canonical document vẫn là federalreserve.gov.

V2.2 vì vậy thêm nút mở @federalreserve nhưng không scrape X trong background.

## Lỗi ngày đăng
V2.1 có nguy cơ nhầm event date trong mô tả meeting với publication date.
V2.2:
- ưu tiên date/time node và date ở phần tử đứng trước item;
- reject publication epoch > hiện tại + 12 giờ;
- item không xác minh được ngày sẽ ghi `Ngày đăng chưa xác minh`;
- future date không được phép trở thành `latestDate`.

## Phạm vi thay đổi
Không sửa:
- FRED macro engine
- Gold fallback
- Binance watchlist/order book/candles
- Coin Lab
- Decision Engine
- ML Kit translation
- Document Identity Gate

Mục tiêu là nâng coverage Fed mà không làm hỏng các phần đang chạy.
