MARKET OS PHOENIX v2.2 — ONECLICK

Fed Source Expansion patch over Phoenix v2.1.

1) Giải nén file ONECLICK này.
2) Upload TOÀN BỘ nội dung vào root repo GitHub.
3) Actions -> Build MarketOS Phoenix v2.2 APK -> Run workflow.
4) Workflow chạy static audit + JavaScript syntax check trước khi assembleDebug.
5) Tải artifact: MarketOS-Phoenix-v2.2-debug-APK.

Project Android: /projects/MarketOS_Phoenix_v2_2_ANDROID_SOURCE.zip
Fact-check: /V2_2_FACTCHECK.md

Điểm mới:
- Recent Postings + Board Meetings + FEDS Notes + Data Download + Z.1 RSS
- Source health
- filter Dữ liệu Fed / Nghiên cứu
- future/event-date guard
- nút Z.1 và @federalreserve X (alert only; không dùng X làm evidence)
