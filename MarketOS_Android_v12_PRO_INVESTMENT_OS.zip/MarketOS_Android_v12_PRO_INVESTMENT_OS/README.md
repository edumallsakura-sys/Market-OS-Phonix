# Market OS v12 — Professional Investment Decision OS

Bản v12 chuyển trọng tâm từ news/report reader sang decision cockpit:

- Decision Cockpit: regime, conviction, Action Map, scenario/invalidation.
- Investor lenses: Soros reflexivity, Taleb fragility/optionality, Graham margin-of-safety gate.
- Global liquidity: Fed + ECB + BoJ dùng normalized momentum, không cộng sai đơn vị tiền tệ.
- U.S. fiscal pulse: TGA, monthly deficit/surplus, outlays, receipts, public debt.
- Cross-asset confirmation: USD, S&P 500, Gold, BTC.
- Crypto Market Board tùy biến: thêm/bớt CoinGecko ID, live refresh, chart 30/90D, SMA20, RSI14, realized volatility, volume trend.
- Fed Deep Reader: evidence extraction thay cho brief lặp; AI Research Note theo policy delta/transmission/scenario.
- PDF Viewer: render nền trắng; chuyển sang lớp văn bản có thể bôi đen; menu chọn 'Dịch VI' bằng ML Kit on-device.
- HTML/PDF/nguồn gốc vẫn giữ để kiểm chứng.
- Data quality: không demo/fake; missing/stale được hiển thị.

## Giới hạn cố ý

PBoC/China fiscal chưa được nối parser primary-source live trong v12. App đánh dấu thiếu thay vì suy đoán. Market OS không phải hệ thống bảo đảm lợi nhuận; nó là khung evidence/risk/decision.
