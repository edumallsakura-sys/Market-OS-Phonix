# Market OS v24 — Investment Committee / Kết luận đầu tư

## Mục tiêu
Biến toàn bộ dữ liệu của app thành một quy trình quyết định duy nhất:

Data integrity → Macro regime → Cross-asset confirmation → Coin selection → Deep DD → Prompt score → Commitment Gate → Risk unit / invalidation.

## Cổng giải ngân
App không hiển thị BUY chỉ vì nhiều ô xanh. Cổng chỉ mở khi:
- dữ liệu macro đủ fresh và batch không fail;
- regime không ở trạng thái low-quality;
- đã chọn coin và chạy Deep Due Diligence;
- 10 nhóm Prompt Score hoàn tất, không renormalize dữ liệu thiếu;
- không có hard reject;
- full unlock + catalyst có nguồn;
- có invalidation + risk plan;
- với trạng thái mạnh nhất, cross-asset phải CONFIRMED.

## Kết quả
- >=85/100 + macro/risk/cross-asset đạt: ĐỦ ĐIỀU KIỆN XEM XÉT GIẢI NGÂN.
- 70–84 + risk budget đủ: GIẢI NGÂN THĂM DÒ CÓ ĐIỀU KIỆN.
- 55–69: THEO DÕI.
- <55 hoặc hard reject: LOẠI.
- Thiếu một gate bắt buộc: FINAL SCORE LOCKED / CHỜ.

Risk unit là hệ số so với mức rủi ro chuẩn, không phải % tài khoản bắt buộc.
