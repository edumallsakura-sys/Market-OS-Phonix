# ALPHAFLOW OS v1.1.6

Deep Modules build with GitHub Actions that can recursively open the uploaded ONECLICK ZIP and locate the nested Expo source automatically.

Deep Modules build with robust GitHub Actions source discovery.

# ALPHAFLOW OS v1.1.0

Compact modular Android investment research app built with Expo + React Native.

## Modules
1. Macro Cockpit — FRED snapshot, indicator library, regime, calendar, detail ranges/notes.
2. Crypto Lab — grouped watchlists, discovery, screener, global market, scoring, coin detail.
3. Chart Viewer — Binance candlesticks, MA20/MA50, volume, RSI, MACD, depth snapshot.
4. AI Copilot — Gemini with OpenRouter fallback, grounded in local Macro/Crypto evidence.
5. Portfolio — local positions, PnL, allocation donut, backup/import/share JSON.
6. Alerts + Settings — local alert checks, API keys, cache controls and runtime policy.

## API keys
FRED requires a key. Gemini/OpenRouter are optional for AI. CoinGecko works keyless where allowed; a Demo key can be entered in Settings. Keys are not hardcoded.

## Offline behavior
Cached FRED/CoinGecko responses fall back to stale data on transient failures. Watchlists, groups, portfolio, notes, alerts, and chat history are stored locally with MMKV.

## Safety / performance
- HTTP timeout 10 seconds.
- Finite retry/backoff.
- No unbounded `setInterval` polling.
- No background WebSocket.
- Market data is loaded on demand and cached.
- Android minSdk 26.

Use GitHub Actions from the outer ONECLICK package to build the APK without Android Studio.
