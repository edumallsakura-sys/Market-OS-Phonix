# ALPHAFLOW OS v1.1.7 — Standalone JavaScript bundle hotfix

## Root cause verified from the user's v1.1.6 APK
The APK was a Gradle Debug build and contained no `assets/index.android.bundle`.
A React Native Debug build normally expects Metro, so an installed APK opened the
red `Unable to load script` screen.

## Fix
- Version: 1.1.7 / Android versionCode 9.
- Added a local Expo config plugin that sets React Native Gradle Plugin
  `debuggableVariants = []`, forcing a JS bundle into Debug as a safety net.
- GitHub Actions now prefers `assembleRelease` for a normal standalone APK.
- The workflow validates the produced APK as a ZIP and refuses to upload it unless
  `assets/index.android.bundle` is present.
- If Release cannot be produced for an environment-specific signing reason, the
  workflow can fall back to a bundled Debug APK; the bundle validation still applies.
- No app feature or module was removed.
