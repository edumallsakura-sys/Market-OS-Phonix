from pathlib import Path
import json
root=Path(__file__).resolve().parent
pkg=json.loads((root/'package.json').read_text())
assert pkg['version']=='1.1.7'
assert pkg['dependencies']['expo'].startswith('57.')
assert pkg['dependencies']['react-native']=='0.86.3'
app=json.loads((root/'app.json').read_text())['expo']
assert app['version']=='1.1.7'
assert app['android']['package']=='com.alphaflow.os'
assert app['android']['versionCode']==9
assert './plugins/withStandaloneDebugBundle' in app['plugins']
plugin=(root/'plugins/withStandaloneDebugBundle.js')
assert plugin.is_file()
pt=plugin.read_text(encoding='utf-8')
assert 'debuggableVariants = []' in pt
for f in root.glob('src/**/*'):
    if f.suffix in {'.ts','.tsx'}:
        t=f.read_text(encoding='utf-8')
        assert 'TODO: implement' not in t, f'placeholder found: {f}'
        assert 'setInterval(' not in t, f'unbounded interval forbidden: {f}'
        assert 'while (true)' not in t and 'while(true)' not in t, f'unbounded loop forbidden: {f}'
network=(root/'src/core/network.ts').read_text()
assert '10_000' in network and 'AbortController' in network
assert 'inFlight' in network
assert (root/'assets/icon.png').stat().st_size>10000
main_shell=(root/'src/navigation/MainShell.tsx').read_text()
macro=(root/'src/modules/macro/MacroScreen.tsx').read_text()
crypto=(root/'src/modules/crypto/CryptoScreen.tsx').read_text()
assert "NativeStackScreenProps<RootStackParamList, 'Main'>" in main_shell
assert "NativeStackNavigationProp<RootStackParamList, 'Main'>" in macro
assert crypto.count("NativeStackNavigationProp<RootStackParamList, 'Main'>") >= 2
print('Static audit OK - v1.1.7 standalone bundle hotfix')
