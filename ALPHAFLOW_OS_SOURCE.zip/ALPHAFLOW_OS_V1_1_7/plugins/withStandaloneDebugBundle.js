const { withAppBuildGradle } = require('@expo/config-plugins');

/**
 * ALPHAFLOW OS standalone-debug safety net.
 *
 * React Native normally treats the `debug` variant as Metro-driven and skips
 * creation of index.android.bundle. GitHub users can accidentally build Debug
 * and install it as if it were a standalone APK, which results in the red
 * "Unable to load script" screen.
 *
 * Setting `debuggableVariants = []` tells the React Native Gradle Plugin that
 * even Debug must run the JS bundling task. Release builds are unaffected.
 */
module.exports = function withStandaloneDebugBundle(config) {
  return withAppBuildGradle(config, (modConfig) => {
    if (modConfig.modResults.language !== 'groovy') {
      throw new Error('ALPHAFLOW standalone bundle plugin expects Groovy app/build.gradle');
    }

    let contents = modConfig.modResults.contents;
    if (!contents.includes('debuggableVariants = []')) {
      const marker = 'react {';
      const index = contents.indexOf(marker);
      if (index < 0) {
        throw new Error('Could not locate the React Native `react {` block in app/build.gradle');
      }
      const insertion = `${marker}\n    // ALPHAFLOW: package JS even for debug APKs so Metro is never required.\n    debuggableVariants = []`;
      contents = contents.replace(marker, insertion);
    }

    modConfig.modResults.contents = contents;
    return modConfig;
  });
};
