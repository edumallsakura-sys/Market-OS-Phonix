# ALPHAFLOW OS v1.1.0 — Deep Modules

## Macro
- Expanded FRED catalog across Rates, Inflation, Labor, Liquidity, Growth and Market.
- Regime detection now uses explicit evidence factors and supporting GDP/S&P/10Y data.
- Economic calendar seed for official 2026 Fed/BLS/BEA dates.
- Search, category filters, favorites, richer detail stats, changes, metadata and notes.

## Crypto
- Multiple watchlist groups, autocomplete search, tag/sort/filter.
- Market Overview, Fear & Greed, Trending, Discovery and top-250 Screener.
- Rich Coin Detail, links, notes, TVL attempt, research-score breakdown.
- Binance ticker/depth/kline and DefiLlama public data helpers.

## Chart
- Native SVG candlesticks, MA20/MA50, volume, RSI, MACD, ticker and order-book snapshot.
- 1h / 4h / 1d / 1W / 1M.

## AI
- Evidence-first local context from Macro + Crypto caches.
- Bounded local history and Gemini -> OpenRouter fallback.

## Portfolio
- Edit/remove positions, allocation donut, cost/PnL, JSON backup/import/share.

## Alerts / Settings
- Price, 24h change and volume-spike local alerts with cooldown.
- Cache clearing preserves user data and keys.

No infinite polling/background loop was added.


## v1.1.6 — TypeScript navigation hotfix
- Fixed strict React Navigation v7 typing between MainShell and Macro/Crypto screens.
- Removed no features and added no `any`/`@ts-ignore` workaround.
- Android versionCode 8.
- ONECLICK discovery prefers the highest versioned outer ZIP when several old packages remain in the repo.
