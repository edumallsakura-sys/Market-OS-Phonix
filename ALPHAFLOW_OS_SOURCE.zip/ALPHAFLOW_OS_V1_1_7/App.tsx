import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import MainShell from './src/navigation/MainShell';
import MacroDetailScreen from './src/modules/macro/MacroDetailScreen';
import CoinDetailScreen from './src/modules/crypto/CoinDetailScreen';
import { C } from './src/core/theme';

export type RootStackParamList = {
  Main: undefined;
  MacroDetail: { code: string; name: string };
  CoinDetail: { id: string };
};

const Stack = createNativeStackNavigator<RootStackParamList>();
const theme = { ...DarkTheme, colors: { ...DarkTheme.colors, background: C.bg, card: C.panel, text: C.text, border: C.border, primary: C.gold } };

export default function App() {
  return (
    <SafeAreaProvider>
      <NavigationContainer theme={theme}>
        <StatusBar style="light" />
        <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: C.bg }, headerTintColor: C.text, contentStyle: { backgroundColor: C.bg } }}>
          <Stack.Screen name="Main" component={MainShell} options={{ headerShown: false }} />
          <Stack.Screen name="MacroDetail" component={MacroDetailScreen} options={({ route }) => ({ title: route.params.name })} />
          <Stack.Screen name="CoinDetail" component={CoinDetailScreen} options={{ title: 'Coin Detail' }} />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
