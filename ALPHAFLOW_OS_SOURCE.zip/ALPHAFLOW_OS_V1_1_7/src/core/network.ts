import { getJson, setJson } from './storage';

export class HttpError extends Error {
  constructor(message: string, public readonly status?: number, public readonly url?: string) {
    super(message);
    this.name = 'HttpError';
  }
}

type CacheEnvelope<T> = { savedAt: number; data: T };
const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));
const inFlight = new Map<string, Promise<unknown>>();

function retryable(error: unknown): boolean {
  if (error instanceof HttpError) return error.status === 408 || error.status === 429 || (error.status != null && error.status >= 500);
  return true;
}

export async function fetchJson<T>(
  url: string,
  options: RequestInit = {},
  timeoutMs = 10_000,
  retries = 2,
): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt <= retries; attempt += 1) {
    if (attempt > 0) await sleep(Math.min(4_000, 500 * 2 ** (attempt - 1)));
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, { ...options, signal: controller.signal });
      if (!response.ok) {
        const err = new HttpError(`HTTP ${response.status}`, response.status, url);
        if (!retryable(err)) throw err;
        lastError = err;
        continue;
      }
      return (await response.json()) as T;
    } catch (error) {
      const normalized = error instanceof Error && error.name === 'AbortError'
        ? new HttpError(`Timeout ${Math.round(timeoutMs / 1000)}s`, 408, url)
        : error;
      lastError = normalized;
      if (!retryable(normalized) || attempt >= retries) throw normalized;
    } finally {
      clearTimeout(timer);
    }
  }
  throw lastError instanceof Error ? lastError : new Error('Network request failed');
}

export async function cachedJson<T>(
  cacheKey: string,
  ttlMs: number,
  loader: () => Promise<T>,
  force = false,
): Promise<{ data: T; stale: boolean; savedAt: number }> {
  const cached = getJson<CacheEnvelope<T> | null>(cacheKey, null);
  const now = Date.now();
  if (!force && cached && now - cached.savedAt < ttlMs) return { data: cached.data, stale: false, savedAt: cached.savedAt };

  const existing = inFlight.get(cacheKey);
  if (existing) return existing as Promise<{ data: T; stale: boolean; savedAt: number }>;

  const task = (async () => {
    try {
      const data = await loader();
      const savedAt = Date.now();
      setJson(cacheKey, { data, savedAt } satisfies CacheEnvelope<T>);
      return { data, stale: false, savedAt };
    } catch (error) {
      if (cached && retryable(error)) return { data: cached.data, stale: true, savedAt: cached.savedAt };
      throw error;
    } finally {
      inFlight.delete(cacheKey);
    }
  })();
  inFlight.set(cacheKey, task);
  return task;
}

export function formatCacheAge(savedAt: number | null): string {
  if (!savedAt) return 'chưa có cache';
  const mins = Math.max(0, Math.floor((Date.now() - savedAt) / 60_000));
  if (mins < 1) return 'vừa cập nhật';
  if (mins < 60) return `${mins} phút trước`;
  const hours = Math.floor(mins / 60);
  if (hours < 48) return `${hours} giờ trước`;
  return `${Math.floor(hours / 24)} ngày trước`;
}

export function createRateLimiter(minGapMs: number): () => Promise<void> {
  let queue: Promise<void> = Promise.resolve();
  let lastStarted = 0;
  return async () => {
    let release: (() => void) | undefined;
    const prev = queue;
    queue = new Promise<void>((resolve) => { release = resolve; });
    await prev;
    try {
      const wait = Math.max(0, minGapMs - (Date.now() - lastStarted));
      if (wait > 0) await sleep(wait);
      lastStarted = Date.now();
    } finally {
      release?.();
    }
  };
}
