import { createMMKV } from 'react-native-mmkv';

export const storage = createMMKV({ id: 'alphaflow.main' });

export function getJson<T>(key: string, fallback: T): T {
  try {
    const raw = storage.getString(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function setJson<T>(key: string, value: T): void {
  storage.set(key, JSON.stringify(value));
}

export function getString(key: string, fallback = ''): string {
  return storage.getString(key) ?? fallback;
}

export function setString(key: string, value: string): void {
  storage.set(key, value);
}

export function getBoolean(key: string, fallback = false): boolean {
  return storage.getBoolean(key) ?? fallback;
}

export function setBoolean(key: string, value: boolean): void {
  storage.set(key, value);
}

export function removeKey(key: string): void {
  storage.remove(key);
}

export function keysByPrefix(prefix: string): string[] {
  return storage.getAllKeys().filter((key) => key.startsWith(prefix));
}

export function removeKeysByPrefix(prefix: string): number {
  const keys = keysByPrefix(prefix);
  for (const key of keys) storage.remove(key);
  return keys.length;
}

export function trimStorage(): void {
  storage.trim();
}

export function storageByteSize(): number {
  return storage.byteSize;
}
