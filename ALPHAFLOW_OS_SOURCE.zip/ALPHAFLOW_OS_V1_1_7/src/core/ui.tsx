import React from 'react';
import { Pressable, StyleSheet, Text, View, ViewStyle } from 'react-native';
import Svg, { Polyline } from 'react-native-svg';
import { C } from './theme';

export function Panel({ children, style }: { children: React.ReactNode; style?: ViewStyle | ViewStyle[] }) {
  return <View style={[styles.panel, style]}>{children}</View>;
}

export function Pill({ text, tone = 'blue' }: { text: string; tone?: 'blue' | 'green' | 'red' | 'yellow' | 'gold' }) {
  const map = { blue: C.blue, green: C.green, red: C.red, yellow: C.yellow, gold: C.gold };
  return <View style={[styles.pill, { borderColor: map[tone] }]}><Text style={[styles.pillText, { color: map[tone] }]}>{text}</Text></View>;
}

export function Button({ title, onPress, secondary = false, disabled = false, compact = false }: { title: string; onPress: () => void; secondary?: boolean; disabled?: boolean; compact?: boolean }) {
  return <Pressable disabled={disabled} onPress={onPress} style={({ pressed }) => [styles.button, compact && styles.compact, secondary && styles.secondary, disabled && { opacity: 0.45 }, pressed && { opacity: 0.75 }]}><Text style={[styles.buttonText, secondary && { color: C.text }, compact && { fontSize: 11 }]}>{title}</Text></Pressable>;
}

export function Sparkline({ values, color = C.blue, width = 120, height = 42 }: { values: number[]; color?: string; width?: number; height?: number }) {
  if (values.length < 2) return <View style={{ width, height }} />;
  const min = Math.min(...values); const max = Math.max(...values); const span = max - min || 1;
  const points = values.map((v, i) => `${(i / (values.length - 1)) * width},${height - ((v - min) / span) * (height - 4) - 2}`).join(' ');
  return <Svg width={width} height={height}><Polyline points={points} fill="none" stroke={color} strokeWidth="2" /></Svg>;
}

export function ProgressBar({ value, color = C.gold }: { value: number; color?: string }) {
  const pct = Math.max(0, Math.min(100, value));
  return <View style={styles.track}><View style={[styles.fill, { width: `${pct}%`, backgroundColor: color }]} /></View>;
}

export function SectionTitle({ title, right }: { title: string; right?: React.ReactNode }) {
  return <View style={styles.sectionRow}><Text style={styles.sectionTitle}>{title}</Text>{right}</View>;
}

const styles = StyleSheet.create({
  panel: { backgroundColor: C.panel, borderColor: C.border, borderWidth: 1, borderRadius: 14, padding: 14 },
  pill: { borderWidth: 1, borderRadius: 999, paddingHorizontal: 9, paddingVertical: 4, alignSelf: 'flex-start' },
  pillText: { fontSize: 11, fontWeight: '800' },
  button: { backgroundColor: C.gold, borderRadius: 10, paddingVertical: 10, paddingHorizontal: 14, alignItems: 'center', justifyContent: 'center' },
  compact: { paddingVertical: 7, paddingHorizontal: 10, borderRadius: 8 },
  secondary: { backgroundColor: C.panel2, borderColor: C.border, borderWidth: 1 },
  buttonText: { color: '#0B0D10', fontWeight: '800' },
  track: { height: 7, borderRadius: 999, backgroundColor: C.panel2, overflow: 'hidden' },
  fill: { height: '100%', borderRadius: 999 },
  sectionRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  sectionTitle: { color: C.gold, fontWeight: '900', fontSize: 14 },
});
