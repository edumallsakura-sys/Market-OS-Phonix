export const C = {
  bg: '#070A10',
  panel: '#101722',
  panel2: '#161F2D',
  border: '#263348',
  text: '#F5F1E8',
  muted: '#8C98AA',
  gold: '#D8B25B',
  green: '#39C889',
  red: '#F0666E',
  yellow: '#E6B94F',
  blue: '#5A9DF8',
  purple: '#B58BFA',
};

export const spacing = { xs: 6, sm: 10, md: 14, lg: 18, xl: 24 };
