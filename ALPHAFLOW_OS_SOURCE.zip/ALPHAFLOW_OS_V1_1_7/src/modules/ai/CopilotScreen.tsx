import React, { useMemo, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { C } from '../../core/theme';
import { Button, Panel, Pill, SectionTitle } from '../../core/ui';
import { fetchJson } from '../../core/network';
import { getJson, getString, setJson } from '../../core/storage';
import { useMacroStore } from '../macro/macroData';
import { useCryptoStore } from '../crypto/cryptoData';

type Message = { role: 'user' | 'assistant'; text: string; at: number };
const KEY = 'ai.chat.v2'; const MAX_STORED = 80; const presets = ['Tóm tắt vĩ mô từ dữ liệu trong app', 'Phân tích BTC từ watchlist hiện tại', 'Tôi nên chú ý gì tuần này?'];

function buildLocalContext(): { text: string; evidenceCount: number } {
  const macro = useMacroStore.getState(); const crypto = useCryptoStore.getState(); const lines: string[] = [];
  if (macro.items.length) { lines.push(`MACRO cache/update: ${macro.lastUpdate ? new Date(macro.lastUpdate).toISOString() : 'unknown'}`); lines.push(`Regime: ${macro.regime.name} (${macro.regime.confidence}%): ${macro.regime.description}`); for (const x of macro.items) lines.push(`${x.code} ${x.name}: ${x.display}; last-period change=${x.change ?? 'n/a'}; stale=${x.stale}`); }
  if (crypto.market.length) { lines.push(`CRYPTO watchlist ${crypto.activeListId}; update=${crypto.lastUpdate ? new Date(crypto.lastUpdate).toISOString() : 'unknown'}; stale=${crypto.stale}`); for (const x of crypto.market.slice(0, 30)) lines.push(`${x.symbol}/${x.id}: price=${x.price}; 24h=${x.change24h.toFixed(2)}%; 7d=${x.change7d?.toFixed(2) ?? 'n/a'}%; mcap=${x.marketCap}; volume=${x.volume}`); }
  return { text: lines.length ? lines.join('\n') : 'Không có dữ liệu market/macro đã tải trong local context.', evidenceCount: lines.length };
}

function systemText(context: string): string {
  return `Bạn là ALPHAFLOW Copilot. Chỉ dùng dữ liệu trong LOCAL EVIDENCE dưới đây cho các con số hiện tại. Không được tự bịa giá, CPI, lãi suất, tin tức hoặc sự kiện ngoài evidence. Nếu câu hỏi cần dữ liệu live mà evidence không có, hãy nói rõ cần refresh/nguồn ngoài. Phân biệt FACT / INFERENCE / RISK. Không tự động đưa position size hay cam kết lợi nhuận.\n\nLOCAL EVIDENCE:\n${context}`;
}

async function askGemini(history: Message[], context: string): Promise<string> {
  const key = getString('settings.geminiApiKey', process.env.EXPO_PUBLIC_GEMINI_API_KEY ?? '').trim(); if (!key) throw new Error('Không có Gemini key');
  const contents = [{ role: 'user', parts: [{ text: systemText(context) }] }, { role: 'model', parts: [{ text: 'Đã hiểu. Tôi sẽ chỉ dùng evidence được cung cấp và đánh dấu suy luận.' }] }, ...history.slice(-10).map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.text }] }))];
  const r = await fetchJson<any>(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(key)}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents, generationConfig: { temperature: 0.25, maxOutputTokens: 1400 } }) }, 10_000, 1);
  const text = r.candidates?.[0]?.content?.parts?.map((p: any) => p.text ?? '').join('\n').trim(); if (!text) throw new Error('Gemini trả rỗng'); return text;
}
async function askOpenRouter(history: Message[], context: string): Promise<string> {
  const key = getString('settings.openRouterApiKey', process.env.EXPO_PUBLIC_OPENROUTER_API_KEY ?? '').trim(); if (!key) throw new Error('Không có OpenRouter key');
  const messages = [{ role: 'system', content: systemText(context) }, ...history.slice(-10).map((m) => ({ role: m.role, content: m.text }))];
  const r = await fetchJson<any>('https://openrouter.ai/api/v1/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}`, 'X-Title': 'ALPHAFLOW OS' }, body: JSON.stringify({ model: 'openrouter/free', messages, temperature: 0.25, max_tokens: 1400 }) }, 10_000, 1);
  const text = r.choices?.[0]?.message?.content?.trim(); if (!text) throw new Error('OpenRouter trả rỗng'); return text;
}

export default function CopilotScreen() {
  const [messages, setMessages] = useState<Message[]>(() => getJson<Message[]>(KEY, []).slice(-MAX_STORED)); const [input, setInput] = useState(''); const [loading, setLoading] = useState(false); const [provider, setProvider] = useState(''); const local = buildLocalContext();
  const recent = useMemo(() => messages.slice(-40), [messages]);
  const persist = (next: Message[]) => { const bounded = next.slice(-MAX_STORED); setMessages(bounded); setJson(KEY, bounded); };
  const send = async (text = input) => { const q = text.trim(); if (!q || loading) return; const user: Message = { role: 'user', text: q, at: Date.now() }; const next = [...messages, user].slice(-MAX_STORED); persist(next); setInput(''); setLoading(true); try { let answer: string; try { answer = await askGemini(next, local.text); setProvider('Gemini 2.5 Flash'); } catch { answer = await askOpenRouter(next, local.text); setProvider('OpenRouter free'); } persist([...next, { role: 'assistant', text: answer, at: Date.now() }]); } catch (e) { persist([...next, { role: 'assistant', text: `AI chưa khả dụng: ${e instanceof Error ? e.message : String(e)}. Hãy nhập API key trong Cài đặt; dữ liệu local vẫn dùng được ở Macro/Crypto.`, at: Date.now() }]); } finally { setLoading(false); } };
  return <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}><View style={styles.wrap}><View style={styles.head}><View><Text style={styles.h1}>AI Copilot</Text><Text style={styles.sub}>Gemini → OpenRouter fallback · context từ cache trong app</Text></View><Button title="Clear" compact secondary onPress={() => persist([])} /></View><Panel><View style={styles.evidence}><Pill text={`${local.evidenceCount} evidence lines`} tone={local.evidenceCount > 2 ? 'green' : 'yellow'} />{provider ? <Pill text={provider} tone="gold" /> : null}</View><Text style={styles.contextNote}>Copilot không tự coi kiến thức model là dữ liệu thị trường hiện tại. Refresh Macro/Crypto trước khi hỏi câu phụ thuộc số liệu mới.</Text></Panel><View style={styles.presets}>{presets.map((x) => <Button key={x} title={x} secondary compact onPress={() => void send(x)} />)}</View><ScrollView style={styles.chat} contentContainerStyle={{ gap: 8, paddingVertical: 8 }}>{recent.length ? recent.map((m, i) => <Panel key={`${m.at}-${i}`} style={m.role === 'user' ? styles.user : styles.ai}><Text style={styles.role}>{m.role === 'user' ? 'YOU' : 'COPILOT'}</Text><Text style={styles.text}>{m.text}</Text><Text style={styles.time}>{new Date(m.at).toLocaleTimeString('vi-VN')}</Text></Panel>) : <Panel><SectionTitle title="Evidence-first Copilot" /><Text style={styles.empty}>Chọn một preset hoặc nhập câu hỏi. Copilot sẽ nhận snapshot Macro + Crypto đang có trong app làm evidence.</Text></Panel>}</ScrollView><View style={styles.composer}><TextInput value={input} onChangeText={setInput} multiline placeholder="Hỏi ALPHAFLOW…" placeholderTextColor={C.muted} style={styles.input} /><Button title={loading ? 'Đang nghĩ…' : 'Gửi'} disabled={loading} onPress={() => void send()} /></View></View></KeyboardAvoidingView>;
}
const styles = StyleSheet.create({ wrap: { flex: 1, padding: 14 }, head: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, h1: { color: C.text, fontSize: 24, fontWeight: '900' }, sub: { color: C.muted, fontSize: 9, marginBottom: 8 }, evidence: { flexDirection: 'row', gap: 6, flexWrap: 'wrap' }, contextNote: { color: C.muted, fontSize: 9, lineHeight: 14, marginTop: 8 }, presets: { gap: 5, marginTop: 8 }, chat: { flex: 1, marginVertical: 8 }, user: { marginLeft: 42, backgroundColor: '#182233' }, ai: { marginRight: 24 }, role: { color: C.gold, fontSize: 9, fontWeight: '900', marginBottom: 5 }, text: { color: C.text, lineHeight: 20, fontSize: 12 }, time: { color: C.muted, fontSize: 8, marginTop: 7 }, empty: { color: C.muted, lineHeight: 18 }, composer: { flexDirection: 'row', gap: 8, alignItems: 'flex-end' }, input: { flex: 1, maxHeight: 110, minHeight: 44, borderColor: C.border, borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 9, color: C.text, backgroundColor: C.panel } });
