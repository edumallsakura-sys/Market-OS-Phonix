import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../../../App';
import { C } from '../../core/theme';
import { Button, Panel, Pill, SectionTitle, Sparkline } from '../../core/ui';
import { formatCacheAge } from '../../core/network';
import { eventCountdown, getMacroFavorites, MACRO_CATEGORIES, MACRO_INDICATORS, MacroCategory, toggleMacroFavorite, upcomingEvents, useMacroStore } from './macroData';

function toneColor(tone: 'green' | 'red' | 'yellow' | 'blue'): string {
  return tone === 'green' ? C.green : tone === 'red' ? C.red : tone === 'yellow' ? C.yellow : C.blue;
}

export default function MacroScreen({ navigation }: { navigation: NativeStackNavigationProp<RootStackParamList, 'Main'> }) {
  const { items, support, loading, error, lastUpdate, regime, refresh } = useMacroStore();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<MacroCategory | 'All'>('All');
  const [favorites, setFavorites] = useState<string[]>(() => getMacroFavorites());
  useEffect(() => { if (!items.length) void refresh(false); }, [items.length, refresh]);

  const catalog = useMemo(() => {
    const q = query.trim().toLowerCase();
    return MACRO_INDICATORS.filter((x) => (category === 'All' || x.category === category) && (!q || `${x.code} ${x.name} ${x.description}`.toLowerCase().includes(q)))
      .sort((a, b) => Number(favorites.includes(b.code)) - Number(favorites.includes(a.code)) || a.name.localeCompare(b.name));
  }, [category, favorites, query]);
  const events = upcomingEvents(6);
  const globals = ['DEXUSEU', 'DEXJPUS', 'DEXCHUS', 'DTWEXBGS'].flatMap((code) => { const x = support.find((s) => s.code === code); return x ? [x] : []; });
  const regimeTone = regime.tone === 'green' ? 'green' : regime.tone === 'red' ? 'red' : regime.tone === 'yellow' ? 'yellow' : 'blue';

  return <ScrollView contentContainerStyle={styles.content} refreshControl={<RefreshControl refreshing={loading} onRefresh={() => void refresh(true)} tintColor={C.gold} />} keyboardShouldPersistTaps="handled">
    <View style={styles.head}><View><Text style={styles.h1}>Macro Cockpit</Text><Text style={styles.sub}>{lastUpdate ? `Data ${formatCacheAge(lastUpdate)}` : 'Offline-first · FRED'}</Text></View><Button title="Refresh" secondary compact onPress={() => void refresh(true)} /></View>

    <Panel style={{ borderLeftColor: toneColor(regime.tone), borderLeftWidth: 4 }}>
      <View style={styles.regimeRow}><Pill text={regime.name} tone={regimeTone} /><Text style={styles.conf}>{regime.confidence}% confidence</Text></View>
      <Text style={styles.regimeText}>{regime.description}</Text>
      <View style={styles.factorWrap}>{regime.factors.map((factor) => <Text key={factor} style={styles.factor}>• {factor}</Text>)}</View>
    </Panel>

    {error ? <Panel><Text style={styles.error}>{error}</Text><Text style={styles.sub}>Vào Cài đặt → nhập FRED API key. Cache cũ vẫn được ưu tiên khi mạng/FRED lỗi tạm thời.</Text></Panel> : null}

    <SectionTitle title="6 chỉ báo sáng nay" />
    <View style={styles.grid}>{items.map((item) => {
      const color = toneColor(item.tone);
      return <Pressable key={item.code} style={styles.card} onPress={() => navigation.navigate('MacroDetail', { code: item.code, name: item.name })}>
        <View style={styles.cardTop}><Text style={styles.code}>{item.code}</Text>{item.stale ? <Text style={styles.cached}>STALE</Text> : null}</View>
        <Text style={styles.label}>{item.name}</Text><Text style={[styles.value, { color }]}>{item.display}</Text>
        <Text style={[styles.change, { color: (item.change ?? 0) >= 0 ? C.green : C.red }]}>{item.change == null ? '—' : `${item.change >= 0 ? '+' : ''}${item.change.toFixed(2)} kỳ gần nhất`}</Text>
        <Sparkline values={item.spark} color={color} width={135} height={42} />
      </Pressable>;
    })}</View>

    {globals.length ? <Panel><SectionTitle title="Global FX / USD pulse" right={<Text style={styles.mini}>FRED</Text>} /><View style={styles.globalGrid}>{globals.map((x) => <Pressable key={x.code} style={styles.globalCell} onPress={() => navigation.navigate('MacroDetail', { code: x.code, name: x.name })}><Text style={styles.code}>{x.code}</Text><Text style={styles.globalValue}>{x.display}</Text><Text style={[styles.mini, { color: (x.change ?? 0) >= 0 ? C.green : C.red }]}>{x.change == null ? '—' : `${x.change >= 0 ? '+' : ''}${x.change.toFixed(3)}`}</Text></Pressable>)}</View></Panel> : null}

    <Panel>
      <SectionTitle title="Economic Calendar" right={<Pill text="2026 OFFICIAL DATES" tone="gold" />} />
      {events.length ? events.map((event) => <View key={event.id} style={styles.eventRow}><View style={{ flex: 1 }}><View style={styles.eventHead}><Pill text={event.source} tone={event.importance === 'high' ? 'red' : 'blue'} /><Text style={styles.eventCountdown}>{eventCountdown(event)}</Text></View><Text style={styles.eventTitle}>{event.title}</Text><Text style={styles.mini}>{new Date(event.at).toLocaleString('vi-VN')} · {event.note}</Text></View></View>) : <Text style={styles.sub}>Không còn sự kiện seed trong lịch 2026. Lịch chỉ là schedule, không phải dự báo kết quả.</Text>}
    </Panel>

    <Panel>
      <SectionTitle title={`Indicator Library · ${MACRO_INDICATORS.length}`} />
      <TextInput value={query} onChangeText={setQuery} placeholder="Tìm tên hoặc FRED code…" placeholderTextColor={C.muted} style={styles.search} />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filters}><Button title="ALL" compact secondary={category !== 'All'} onPress={() => setCategory('All')} />{MACRO_CATEGORIES.map((x) => <Button key={x} title={x} compact secondary={category !== x} onPress={() => setCategory(x)} />)}</ScrollView>
      {catalog.map((x) => <View key={x.code} style={styles.catalogRow}><Pressable style={{ flex: 1 }} onPress={() => navigation.navigate('MacroDetail', { code: x.code, name: x.name })}><Text style={styles.catalogName}>{x.name} <Text style={styles.code}>· {x.code}</Text></Text><Text style={styles.mini}>{x.category} · {x.frequency} · {x.unit || 'value'} · {x.description}</Text></Pressable><Pressable onPress={() => setFavorites(toggleMacroFavorite(x.code))}><Text style={[styles.star, { color: favorites.includes(x.code) ? C.gold : C.muted }]}>{favorites.includes(x.code) ? '★' : '☆'}</Text></Pressable></View>)}
    </Panel>
  </ScrollView>;
}

const styles = StyleSheet.create({
  content: { padding: 14, gap: 12, paddingBottom: 28 }, head: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, h1: { color: C.text, fontWeight: '900', fontSize: 24 }, sub: { color: C.muted, fontSize: 11, lineHeight: 17 },
  regimeRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, conf: { color: C.muted, fontSize: 11 }, regimeText: { color: C.text, marginTop: 10, lineHeight: 20, fontWeight: '700' }, factorWrap: { marginTop: 7, gap: 2 }, factor: { color: C.muted, fontSize: 11 }, error: { color: C.red, fontWeight: '700', marginBottom: 6 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 }, card: { width: '48.5%', minHeight: 160, backgroundColor: C.panel, borderColor: C.border, borderWidth: 1, borderRadius: 14, padding: 12 }, cardTop: { flexDirection: 'row', justifyContent: 'space-between' }, code: { color: C.gold, fontSize: 10, fontWeight: '900' }, cached: { color: C.yellow, fontSize: 9 }, label: { color: C.muted, fontSize: 11, marginTop: 4 }, value: { fontWeight: '900', fontSize: 24, marginTop: 8 }, change: { fontWeight: '800', fontSize: 9, marginBottom: 2 },
  globalGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 }, globalCell: { width: '48%', borderWidth: 1, borderColor: C.border, borderRadius: 10, backgroundColor: C.panel2, padding: 9 }, globalValue: { color: C.text, fontWeight: '900', marginTop: 4 }, mini: { color: C.muted, fontSize: 9, lineHeight: 14 },
  eventRow: { paddingVertical: 9, borderTopWidth: 1, borderTopColor: C.border }, eventHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, eventCountdown: { color: C.gold, fontSize: 10, fontWeight: '900' }, eventTitle: { color: C.text, fontWeight: '800', marginTop: 6 },
  search: { color: C.text, borderColor: C.border, borderWidth: 1, borderRadius: 10, paddingHorizontal: 11, paddingVertical: 9 }, filters: { gap: 5, paddingVertical: 9 }, catalogRow: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 9, borderTopWidth: 1, borderTopColor: C.border }, catalogName: { color: C.text, fontWeight: '800', fontSize: 12 }, star: { fontSize: 24, paddingHorizontal: 5 },
});
