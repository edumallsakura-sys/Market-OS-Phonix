import React, { useEffect, useMemo, useState } from 'react';
import { ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../../../App';
import { C } from '../../core/theme';
import { Button, Panel, Pill, SectionTitle, Sparkline } from '../../core/ui';
import { fetchFredSeries, formatMacroValue, getIndicator, getMacroFavorites, MacroPoint, toggleMacroFavorite, transformSeries } from './macroData';
import { getString, setString } from '../../core/storage';

 type Props = NativeStackScreenProps<RootStackParamList, 'MacroDetail'>;
const ranges: Record<string, number> = { '1M': 40, '3M': 110, '6M': 210, '1Y': 430, '5Y': 1900, '10Y': 3800, MAX: 36500 };

function previousValue(data: MacroPoint[], targetMs: number): number | null {
  let found: number | null = null;
  for (const point of data) { if (Date.parse(`${point.date}T00:00:00Z`) <= targetMs) found = point.value; else break; }
  return found;
}
function pct(now: number, before: number | null): number | null { return before == null || before === 0 ? null : ((now - before) / Math.abs(before)) * 100; }

export default function MacroDetailScreen({ route }: Props) {
  const { code, name } = route.params; const meta = getIndicator(code);
  const [range, setRange] = useState('1Y'); const [data, setData] = useState<MacroPoint[]>([]); const [error, setError] = useState<string | null>(null); const [loading, setLoading] = useState(false);
  const [note, setNote] = useState(() => getString(`macro.note.${code}`)); const [favorite, setFavorite] = useState(() => getMacroFavorites().includes(code));
  useEffect(() => { setLoading(true); void fetchFredSeries(code, ranges[range] ?? 430, false).then((r) => { setData(transformSeries(code, r.data)); setError(null); }).catch((e: unknown) => setError(e instanceof Error ? e.message : String(e))).finally(() => setLoading(false)); }, [code, range]);
  const values = data.map((x) => x.value);
  const stats = useMemo(() => values.length ? { current: values[values.length - 1] ?? 0, min: Math.min(...values), max: Math.max(...values), avg: values.reduce((a, b) => a + b, 0) / values.length } : null, [values]);
  const changes = useMemo(() => {
    if (!data.length || !stats) return [] as Array<[string, number | null]>;
    const latestDate = Date.parse(`${data[data.length - 1]?.date ?? new Date().toISOString().slice(0, 10)}T00:00:00Z`); const day = 86_400_000;
    const y = new Date(latestDate); const ytd = Date.UTC(y.getUTCFullYear(), 0, 1);
    return [['1D', pct(stats.current, previousValue(data, latestDate - day))], ['1W', pct(stats.current, previousValue(data, latestDate - 7 * day))], ['1M', pct(stats.current, previousValue(data, latestDate - 30 * day))], ['3M', pct(stats.current, previousValue(data, latestDate - 91 * day))], ['6M', pct(stats.current, previousValue(data, latestDate - 182 * day))], ['1Y', pct(stats.current, previousValue(data, latestDate - 365 * day))], ['YTD', pct(stats.current, previousValue(data, ytd))]] as Array<[string, number | null]>;
  }, [data, stats]);

  return <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
    <View style={styles.titleRow}><View style={{ flex: 1 }}><Text style={styles.title}>{name}</Text><Text style={styles.code}>{code} · FRED</Text></View><Button title={favorite ? '★ PINNED' : '☆ PIN'} secondary={!favorite} compact onPress={() => { const next = toggleMacroFavorite(code); setFavorite(next.includes(code)); }} /></View>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.ranges}>{Object.keys(ranges).map((r) => <Button key={r} title={r} compact secondary={r !== range} onPress={() => setRange(r)} />)}</ScrollView>
    <Panel>{values.length ? <><Sparkline values={values.length > 600 ? values.filter((_, i) => i % Math.ceil(values.length / 600) === 0) : values} width={340} height={180} color={C.gold} /><Text style={styles.muted}>{data[0]?.date} → {data[data.length - 1]?.date} · {values.length} observations</Text></> : <Text style={styles.muted}>{loading ? 'Đang tải…' : error ?? 'Không có dữ liệu'}</Text>}</Panel>
    {stats ? <><View style={styles.stats}>{[['CURRENT', stats.current], ['MIN', stats.min], ['MAX', stats.max], ['AVERAGE', stats.avg]].map(([label, value]) => <Panel key={String(label)} style={styles.stat}><Text style={styles.muted}>{label}</Text><Text style={styles.v}>{formatMacroValue(code, Number(value))}</Text></Panel>)}</View><Panel><SectionTitle title="Changes in selected range" /><View style={styles.changeGrid}>{changes.map(([label, value]) => <View key={label} style={styles.changeCell}><Text style={styles.muted}>{label}</Text><Text style={[styles.changeValue, { color: value == null ? C.muted : value >= 0 ? C.green : C.red }]}>{value == null ? '—' : `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`}</Text></View>)}</View></Panel></> : null}
    <Panel><SectionTitle title="Metadata" /><View style={styles.metaRow}><Text style={styles.muted}>Category</Text><Pill text={meta.category} tone="blue" /></View><View style={styles.metaRow}><Text style={styles.muted}>Frequency</Text><Text style={styles.metaValue}>{meta.frequency}</Text></View><View style={styles.metaRow}><Text style={styles.muted}>Units</Text><Text style={styles.metaValue}>{meta.unit || 'index/value'}</Text></View><View style={styles.metaRow}><Text style={styles.muted}>Transform</Text><Text style={styles.metaValue}>{meta.transform === 'yoy' ? 'YoY % calculated locally' : 'FRED level'}</Text></View><Text style={styles.description}>{meta.description}</Text></Panel>
    <Panel><SectionTitle title="Ghi chú cá nhân" /><TextInput multiline value={note} onChangeText={setNote} placeholder="Thesis, catalyst, điều cần kiểm chứng…" placeholderTextColor={C.muted} style={styles.input} /><Button title="Lưu note" onPress={() => setString(`macro.note.${code}`, note)} /></Panel>
  </ScrollView>;
}
const styles = StyleSheet.create({ content: { padding: 14, gap: 12, paddingBottom: 28 }, titleRow: { flexDirection: 'row', alignItems: 'center', gap: 10 }, title: { color: C.text, fontSize: 23, fontWeight: '900' }, code: { color: C.gold, fontWeight: '800', marginTop: 3 }, ranges: { gap: 5 }, muted: { color: C.muted, fontSize: 10 }, stats: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 }, stat: { width: '48%' }, v: { color: C.text, fontSize: 18, fontWeight: '900', marginTop: 6 }, changeGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 }, changeCell: { width: '23%', backgroundColor: C.panel2, borderRadius: 8, padding: 8 }, changeValue: { fontWeight: '900', fontSize: 11, marginTop: 4 }, metaRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderTopWidth: 1, borderColor: C.border, paddingVertical: 8 }, metaValue: { color: C.text, fontWeight: '700', fontSize: 11 }, description: { color: C.text, lineHeight: 18, fontSize: 11, marginTop: 8 }, input: { minHeight: 110, borderWidth: 1, borderColor: C.border, borderRadius: 10, color: C.text, padding: 10, textAlignVertical: 'top', marginBottom: 10 } });
