import { create } from 'zustand';
import { cachedJson, createRateLimiter, fetchJson } from '../../core/network';
import { getJson, getString, removeKeysByPrefix, setJson } from '../../core/storage';

export type MacroCategory = 'Rates' | 'Inflation' | 'Labor' | 'Liquidity' | 'Growth' | 'Market';
export type Frequency = 'Daily' | 'Weekly' | 'Monthly' | 'Quarterly';
export type MacroTransform = 'level' | 'yoy';

export type MacroIndicator = {
  code: string;
  name: string;
  category: MacroCategory;
  unit: string;
  frequency: Frequency;
  description: string;
  transform?: MacroTransform;
  decimals?: number;
};

export type MacroPoint = { date: string; value: number };
export type MacroSnapshot = {
  code: string;
  name: string;
  value: number | null;
  display: string;
  change: number | null;
  trend: number | null;
  spark: number[];
  tone: 'green' | 'red' | 'yellow' | 'blue';
  stale: boolean;
  savedAt: number;
};

export const MACRO_INDICATORS: MacroIndicator[] = [
  { code: 'FEDFUNDS', name: 'Fed Funds Rate', category: 'Rates', unit: '%', frequency: 'Monthly', description: 'Federal funds effective rate, monthly average.' },
  { code: 'DFF', name: 'Effective Fed Funds Rate', category: 'Rates', unit: '%', frequency: 'Daily', description: 'Daily effective federal funds rate.' },
  { code: 'DGS2', name: 'US Treasury 2Y', category: 'Rates', unit: '%', frequency: 'Daily', description: '2-year Treasury constant maturity rate.' },
  { code: 'DGS10', name: 'US Treasury 10Y', category: 'Rates', unit: '%', frequency: 'Daily', description: '10-year Treasury constant maturity rate.' },
  { code: 'DGS30', name: 'US Treasury 30Y', category: 'Rates', unit: '%', frequency: 'Daily', description: '30-year Treasury constant maturity rate.' },
  { code: 'T10Y2Y', name: 'Yield Curve 10Y-2Y', category: 'Rates', unit: '%', frequency: 'Daily', description: '10-year minus 2-year Treasury spread.' },
  { code: 'T10Y3M', name: 'Yield Curve 10Y-3M', category: 'Rates', unit: '%', frequency: 'Daily', description: '10-year minus 3-month Treasury spread.' },
  { code: 'DFEDTARU', name: 'Fed Target Upper', category: 'Rates', unit: '%', frequency: 'Daily', description: 'Upper bound of the federal funds target range.' },
  { code: 'DFEDTARL', name: 'Fed Target Lower', category: 'Rates', unit: '%', frequency: 'Daily', description: 'Lower bound of the federal funds target range.' },
  { code: 'SOFR', name: 'SOFR', category: 'Rates', unit: '%', frequency: 'Daily', description: 'Secured Overnight Financing Rate.' },

  { code: 'CPIAUCSL', name: 'CPI YoY', category: 'Inflation', unit: '% YoY', frequency: 'Monthly', description: 'Headline CPI annual growth.', transform: 'yoy' },
  { code: 'CPILFESL', name: 'Core CPI YoY', category: 'Inflation', unit: '% YoY', frequency: 'Monthly', description: 'CPI excluding food and energy annual growth.', transform: 'yoy' },
  { code: 'PCEPI', name: 'PCE Inflation YoY', category: 'Inflation', unit: '% YoY', frequency: 'Monthly', description: 'PCE price index annual growth.', transform: 'yoy' },
  { code: 'PCEPILFE', name: 'Core PCE YoY', category: 'Inflation', unit: '% YoY', frequency: 'Monthly', description: 'Core PCE inflation, a key Fed inflation measure.', transform: 'yoy' },
  { code: 'PPIACO', name: 'PPI All Commodities YoY', category: 'Inflation', unit: '% YoY', frequency: 'Monthly', description: 'Producer price index annual growth.', transform: 'yoy' },
  { code: 'T5YIE', name: '5Y Breakeven Inflation', category: 'Inflation', unit: '%', frequency: 'Daily', description: 'Market-implied five-year inflation expectation.' },
  { code: 'T10YIE', name: '10Y Breakeven Inflation', category: 'Inflation', unit: '%', frequency: 'Daily', description: 'Market-implied ten-year inflation expectation.' },

  { code: 'UNRATE', name: 'Unemployment Rate', category: 'Labor', unit: '%', frequency: 'Monthly', description: 'US civilian unemployment rate.' },
  { code: 'PAYEMS', name: 'Nonfarm Payrolls', category: 'Labor', unit: 'K jobs', frequency: 'Monthly', description: 'Total nonfarm payroll employment.' },
  { code: 'ICSA', name: 'Initial Jobless Claims', category: 'Labor', unit: 'claims', frequency: 'Weekly', description: 'Initial unemployment insurance claims.' },
  { code: 'CCSA', name: 'Continued Claims', category: 'Labor', unit: 'claims', frequency: 'Weekly', description: 'Continued unemployment insurance claims.' },
  { code: 'JTSJOL', name: 'JOLTS Job Openings', category: 'Labor', unit: 'K jobs', frequency: 'Monthly', description: 'Job openings level from JOLTS.' },
  { code: 'AWHAETP', name: 'Average Weekly Hours', category: 'Labor', unit: 'hours', frequency: 'Monthly', description: 'Average weekly hours of all employees, total private.' },

  { code: 'M2SL', name: 'M2 Money Supply YoY', category: 'Liquidity', unit: '% YoY', frequency: 'Monthly', description: 'M2 money stock annual growth.', transform: 'yoy' },
  { code: 'M1SL', name: 'M1 Money Supply YoY', category: 'Liquidity', unit: '% YoY', frequency: 'Monthly', description: 'M1 money stock annual growth.', transform: 'yoy' },
  { code: 'WALCL', name: 'Fed Balance Sheet', category: 'Liquidity', unit: '$M', frequency: 'Weekly', description: 'Federal Reserve total assets.' },
  { code: 'RRPONTSYD', name: 'Reverse Repo', category: 'Liquidity', unit: '$B', frequency: 'Daily', description: 'Overnight reverse repurchase agreements.' },
  { code: 'WRESBAL', name: 'Bank Reserves', category: 'Liquidity', unit: '$M', frequency: 'Weekly', description: 'Reserve balances with Federal Reserve Banks.' },
  { code: 'WTREGEN', name: 'Treasury General Account', category: 'Liquidity', unit: '$M', frequency: 'Weekly', description: 'US Treasury General Account balance.' },

  { code: 'GDP', name: 'Nominal GDP', category: 'Growth', unit: '$B', frequency: 'Quarterly', description: 'Gross domestic product, current dollars.' },
  { code: 'GDPC1', name: 'Real GDP YoY', category: 'Growth', unit: '% YoY', frequency: 'Quarterly', description: 'Real GDP annual growth.', transform: 'yoy' },
  { code: 'INDPRO', name: 'Industrial Production YoY', category: 'Growth', unit: '% YoY', frequency: 'Monthly', description: 'Industrial production annual growth.', transform: 'yoy' },
  { code: 'RSAFS', name: 'Retail Sales YoY', category: 'Growth', unit: '% YoY', frequency: 'Monthly', description: 'Retail and food services sales annual growth.', transform: 'yoy' },
  { code: 'HOUST', name: 'Housing Starts', category: 'Growth', unit: 'K units', frequency: 'Monthly', description: 'New privately-owned housing units started.' },
  { code: 'UMCSENT', name: 'Consumer Sentiment', category: 'Growth', unit: 'index', frequency: 'Monthly', description: 'University of Michigan consumer sentiment index.' },

  { code: 'DEXUSEU', name: 'USD per EUR', category: 'Market', unit: 'FX', frequency: 'Daily', description: 'US dollars per euro.' },
  { code: 'DEXJPUS', name: 'JPY per USD', category: 'Market', unit: 'FX', frequency: 'Daily', description: 'Japanese yen per US dollar.' },
  { code: 'DEXCHUS', name: 'CNY per USD', category: 'Market', unit: 'FX', frequency: 'Daily', description: 'Chinese yuan per US dollar.' },
  { code: 'VIXCLS', name: 'VIX', category: 'Market', unit: 'index', frequency: 'Daily', description: 'CBOE Volatility Index.' },
  { code: 'BAMLH0A0HYM2', name: 'High Yield Spread', category: 'Market', unit: '%', frequency: 'Daily', description: 'ICE BofA US High Yield option-adjusted spread.' },
  { code: 'BAMLC0A0CM', name: 'Investment Grade Spread', category: 'Market', unit: '%', frequency: 'Daily', description: 'ICE BofA US Corporate option-adjusted spread.' },
  { code: 'DTWEXBGS', name: 'Broad Dollar Index', category: 'Market', unit: 'index', frequency: 'Daily', description: 'Trade-weighted US dollar index, broad.' },
  { code: 'SP500', name: 'S&P 500', category: 'Market', unit: 'index', frequency: 'Daily', description: 'S&P 500 market index; used as supporting risk-regime evidence.' },
];

export const MACRO_CATEGORIES: MacroCategory[] = ['Rates', 'Inflation', 'Labor', 'Liquidity', 'Growth', 'Market'];
const META = Object.fromEntries(MACRO_INDICATORS.map((x) => [x.code, x])) as Record<string, MacroIndicator>;
const fredSlot = createRateLimiter(220);

function fredKey(): string {
  return getString('settings.fredApiKey', process.env.EXPO_PUBLIC_FRED_API_KEY ?? '').trim();
}

type FredResponse = { observations?: Array<{ date: string; value: string }> };

function dateDaysAgo(days: number): string {
  const d = new Date(); d.setUTCDate(d.getUTCDate() - Math.max(1, days)); return d.toISOString().slice(0, 10);
}

export async function fetchFredSeries(code: string, days = 400, force = false): Promise<{ data: MacroPoint[]; stale: boolean; savedAt: number }> {
  const key = fredKey();
  if (!key) throw new Error('Chưa có FRED API key. Nhập key ở Cài đặt.');
  const meta = META[code];
  const ttl = meta && (meta.frequency === 'Monthly' || meta.frequency === 'Quarterly') ? 24 * 60 * 60_000 : 6 * 60 * 60_000;
  const cacheKey = `fred.v2.${code}.${days}`;
  return cachedJson(cacheKey, ttl, async () => {
    await fredSlot();
    const start = dateDaysAgo(days);
    const params = `series_id=${encodeURIComponent(code)}&api_key=${encodeURIComponent(key)}&file_type=json&sort_order=asc&observation_start=${start}`;
    const raw = await fetchJson<FredResponse>(`https://api.stlouisfed.org/fred/series/observations?${params}`);
    const points = (raw.observations ?? []).filter((o) => o.value !== '.' && Number.isFinite(Number(o.value))).map((o) => ({ date: o.date, value: Number(o.value) }));
    if (!points.length) throw new Error(`FRED không trả dữ liệu cho ${code}`);
    return points;
  }, force);
}

function periodsPerYear(frequency: Frequency): number {
  if (frequency === 'Quarterly') return 4;
  if (frequency === 'Monthly') return 12;
  if (frequency === 'Weekly') return 52;
  return 252;
}

export function transformSeries(code: string, points: MacroPoint[]): MacroPoint[] {
  const meta = META[code];
  if (!meta || meta.transform !== 'yoy') return points;
  const lag = periodsPerYear(meta.frequency);
  const out: MacroPoint[] = [];
  for (let i = lag; i < points.length; i += 1) {
    const now = points[i]; const prev = points[i - lag];
    if (!now || !prev || prev.value === 0) continue;
    out.push({ date: now.date, value: ((now.value - prev.value) / Math.abs(prev.value)) * 100 });
  }
  return out;
}

export function getIndicator(code: string): MacroIndicator {
  return META[code] ?? { code, name: code, category: 'Market', unit: '', frequency: 'Daily', description: 'FRED series.' };
}

export function formatMacroValue(code: string, value: number): string {
  const meta = getIndicator(code); const d = meta.decimals ?? (Math.abs(value) >= 1000 ? 0 : Math.abs(value) >= 100 ? 1 : 2);
  if (meta.unit === '$M') return `$${value >= 1_000_000 ? `${(value / 1_000_000).toFixed(2)}T` : value >= 1_000 ? `${(value / 1_000).toFixed(1)}B` : `${value.toFixed(0)}M`}`;
  if (meta.unit === '$B') return `$${value >= 1_000 ? `${(value / 1_000).toFixed(2)}T` : `${value.toFixed(1)}B`}`;
  if (meta.unit === 'claims' || meta.unit === 'K jobs' || meta.unit === 'K units') return value.toLocaleString('en-US', { maximumFractionDigits: 0 });
  if (meta.unit === '%' || meta.unit === '% YoY') return `${value.toFixed(2)}%`;
  return value.toLocaleString('en-US', { maximumFractionDigits: d });
}

function toneFor(code: string, value: number): MacroSnapshot['tone'] {
  if (code === 'CPIAUCSL') return value > 3 ? 'red' : value >= 2 ? 'yellow' : 'green';
  if (code === 'T10Y2Y') return value < 0 ? 'red' : 'green';
  if (code === 'VIXCLS') return value > 25 ? 'red' : value >= 15 ? 'yellow' : 'green';
  if (code === 'UNRATE') return value >= 5 ? 'red' : value >= 4 ? 'yellow' : 'green';
  return 'blue';
}

async function makeSnapshot(code: string, force: boolean, days = 500): Promise<MacroSnapshot> {
  const result = await fetchFredSeries(code, days, force);
  const transformed = transformSeries(code, result.data); const p = transformed.length ? transformed : result.data;
  const latest = p[p.length - 1]; if (!latest) throw new Error(`Thiếu dữ liệu ${code}`);
  const prev = p[p.length - 2];
  const trendBack = p[Math.max(0, p.length - Math.min(21, p.length))];
  return {
    code, name: getIndicator(code).name, value: latest.value, display: formatMacroValue(code, latest.value),
    change: prev ? latest.value - prev.value : null,
    trend: trendBack && trendBack.value !== 0 ? ((latest.value - trendBack.value) / Math.abs(trendBack.value)) * 100 : null,
    spark: p.slice(-30).map((x) => x.value), tone: toneFor(code, latest.value), stale: result.stale, savedAt: result.savedAt,
  };
}

export type Regime = { name: string; description: string; confidence: number; tone: MacroSnapshot['tone']; factors: string[] };

export function detectRegime(items: MacroSnapshot[]): Regime {
  const by = Object.fromEntries(items.map((x) => [x.code, x])) as Record<string, MacroSnapshot | undefined>;
  const cpi = by.CPIAUCSL?.value; const unrate = by.UNRATE?.value; const vix = by.VIXCLS?.value; const gdp = by.GDPC1?.value;
  const spxTrend = by.SP500?.trend; const fedTrend = by.FEDFUNDS?.trend; const tenTrend = by.DGS10?.trend;
  const present = [cpi, unrate, vix].filter((v) => v != null).length;
  if (present < 3) return { name: 'Chưa đủ dữ liệu', description: 'Cần CPI, thất nghiệp và VIX để xác định regime đáng tin cậy.', confidence: 0, tone: 'blue', factors: ['Thiếu dữ liệu cốt lõi'] };
  if ((cpi ?? 99) < 1 && (vix ?? 0) > 25) return { name: 'Risk-Off + Deflation', description: 'Lạm phát rất thấp trong khi volatility cao — ưu tiên quản trị rủi ro và kiểm tra tăng trưởng.', confidence: 86, tone: 'red', factors: [`CPI ${cpi?.toFixed(2)}% < 1%`, `VIX ${vix?.toFixed(1)} > 25`] };
  if ((cpi ?? 0) > 4 && gdp != null && gdp < 1) return { name: 'Stagflation', description: 'Lạm phát cao đi cùng tăng trưởng thực yếu.', confidence: 88, tone: 'red', factors: [`CPI ${cpi?.toFixed(2)}% > 4%`, `Real GDP YoY ${gdp.toFixed(2)}% < 1%`] };
  if (cpi != null && cpi >= 2 && cpi <= 3 && gdp != null && gdp > 2 && (unrate ?? 99) < 5) return { name: 'Goldilocks', description: 'Lạm phát 2–3%, tăng trưởng thực trên 2% và thất nghiệp dưới 5%.', confidence: 90, tone: 'green', factors: [`CPI ${cpi.toFixed(2)}%`, `GDP ${gdp.toFixed(2)}%`, `UNRATE ${unrate?.toFixed(2)}%`] };
  if ((cpi ?? 0) > 3 && (spxTrend ?? 0) > 0) return { name: 'Risk-On + Inflation', description: 'Giá tài sản vẫn có đà tăng nhưng lạm phát cao hơn vùng 3%.', confidence: 76, tone: 'yellow', factors: [`CPI ${cpi?.toFixed(2)}% > 3%`, `S&P 500 momentum ${spxTrend?.toFixed(1)}%`] };
  if ((fedTrend ?? 0) > 0.15 && (tenTrend ?? 0) > 0) return { name: 'Tightening', description: 'Fed Funds và lợi suất dài hạn cùng tăng.', confidence: 72, tone: 'yellow', factors: [`Fed trend ${fedTrend?.toFixed(1)}%`, `10Y trend ${tenTrend?.toFixed(1)}%`] };
  if ((fedTrend ?? 0) < -0.15 && (tenTrend ?? 0) < 0) return { name: 'Easing', description: 'Fed Funds và lợi suất dài hạn cùng giảm.', confidence: 72, tone: 'green', factors: [`Fed trend ${fedTrend?.toFixed(1)}%`, `10Y trend ${tenTrend?.toFixed(1)}%`] };
  return { name: 'Mixed / Transition', description: 'Các tín hiệu tăng trưởng, lạm phát và thị trường chưa tạo thành một regime cực đoan thống nhất.', confidence: 58, tone: 'blue', factors: [`CPI ${cpi?.toFixed(2)}%`, `UNRATE ${unrate?.toFixed(2)}%`, `VIX ${vix?.toFixed(1)}`] };
}

export type EconomicEvent = { id: string; title: string; at: string; source: 'Fed' | 'BLS' | 'BEA'; importance: 'high' | 'medium'; note: string };
export const ECONOMIC_CALENDAR: EconomicEvent[] = [
  { id: 'bea-2026-09-30-pce', title: 'PCE + Personal Income (Aug)', at: '2026-09-30T12:30:00Z', source: 'BEA', importance: 'high', note: 'Core PCE is a key Fed inflation input.' },
  { id: 'bea-2026-09-30-gdp', title: 'GDP Q2 — Third Estimate', at: '2026-09-30T12:30:00Z', source: 'BEA', importance: 'medium', note: 'Final scheduled Q2 estimate.' },
  { id: 'bls-2026-10-02-nfp', title: 'Employment Situation / NFP (Sep)', at: '2026-10-02T12:30:00Z', source: 'BLS', importance: 'high', note: 'Payrolls, unemployment and wage data.' },
  { id: 'fed-2026-10-07-minutes', title: 'FOMC Minutes (Sep meeting)', at: '2026-10-07T18:00:00Z', source: 'Fed', importance: 'medium', note: 'Minutes released three weeks after the Sep decision.' },
  { id: 'bls-2026-10-14-cpi', title: 'CPI (Sep)', at: '2026-10-14T12:30:00Z', source: 'BLS', importance: 'high', note: 'Headline and core CPI.' },
  { id: 'fed-2026-10-28-fomc', title: 'FOMC Decision', at: '2026-10-28T18:00:00Z', source: 'Fed', importance: 'high', note: 'Oct 27–28 meeting; press conference follows the decision.' },
  { id: 'bea-2026-10-29-gdp', title: 'GDP Q3 — Advance Estimate', at: '2026-10-29T12:30:00Z', source: 'BEA', importance: 'high', note: 'First estimate for Q3 real GDP.' },
  { id: 'bea-2026-10-29-pce', title: 'PCE + Personal Income (Sep)', at: '2026-10-29T12:30:00Z', source: 'BEA', importance: 'high', note: 'PCE inflation release.' },
  { id: 'bls-2026-11-06-nfp', title: 'Employment Situation / NFP (Oct)', at: '2026-11-06T13:30:00Z', source: 'BLS', importance: 'high', note: 'Payrolls, unemployment and wage data.' },
  { id: 'bls-2026-11-10-cpi', title: 'CPI (Oct)', at: '2026-11-10T13:30:00Z', source: 'BLS', importance: 'high', note: 'Headline and core CPI.' },
  { id: 'fed-2026-11-18-minutes', title: 'FOMC Minutes (Oct meeting)', at: '2026-11-18T19:00:00Z', source: 'Fed', importance: 'medium', note: 'Minutes from Oct 27–28 meeting.' },
  { id: 'bea-2026-11-25-gdp', title: 'GDP Q3 — Second Estimate', at: '2026-11-25T13:30:00Z', source: 'BEA', importance: 'medium', note: 'Second Q3 GDP estimate.' },
  { id: 'bea-2026-11-25-pce', title: 'PCE + Personal Income (Oct)', at: '2026-11-25T13:30:00Z', source: 'BEA', importance: 'high', note: 'PCE inflation release.' },
  { id: 'bls-2026-12-04-nfp', title: 'Employment Situation / NFP (Nov)', at: '2026-12-04T13:30:00Z', source: 'BLS', importance: 'high', note: 'Payrolls, unemployment and wage data.' },
  { id: 'fed-2026-12-09-fomc', title: 'FOMC Decision + SEP', at: '2026-12-09T19:00:00Z', source: 'Fed', importance: 'high', note: 'Dec 8–9 meeting with Summary of Economic Projections.' },
  { id: 'bls-2026-12-10-cpi', title: 'CPI (Nov)', at: '2026-12-10T13:30:00Z', source: 'BLS', importance: 'high', note: 'Headline and core CPI.' },
  { id: 'bea-2026-12-23-pce', title: 'PCE + Personal Income (Nov)', at: '2026-12-23T13:30:00Z', source: 'BEA', importance: 'high', note: 'PCE inflation release.' },
];

export function upcomingEvents(limit = 6, now = Date.now()): EconomicEvent[] {
  return ECONOMIC_CALENDAR.filter((event) => Date.parse(event.at) >= now - 60 * 60_000).sort((a, b) => Date.parse(a.at) - Date.parse(b.at)).slice(0, limit);
}

export function eventCountdown(event: EconomicEvent, now = Date.now()): string {
  const delta = Date.parse(event.at) - now;
  if (delta <= 0) return 'đang/đã diễn ra';
  const hours = Math.floor(delta / 3_600_000); const days = Math.floor(hours / 24);
  if (days > 0) return `${days} ngày ${hours % 24} giờ`;
  return `${hours} giờ ${Math.floor((delta % 3_600_000) / 60_000)} phút`;
}

const FAVORITES_KEY = 'macro.favorites.v2';
export function getMacroFavorites(): string[] { return getJson<string[]>(FAVORITES_KEY, ['FEDFUNDS', 'CPIAUCSL', 'UNRATE', 'T10Y2Y', 'M2SL', 'VIXCLS']); }
export function toggleMacroFavorite(code: string): string[] {
  const current = getMacroFavorites(); const next = current.includes(code) ? current.filter((x) => x !== code) : [...current, code]; setJson(FAVORITES_KEY, next); return next;
}
export function clearMacroCache(): number { return removeKeysByPrefix('fred.'); }

const VISIBLE_CODES = ['FEDFUNDS', 'CPIAUCSL', 'UNRATE', 'T10Y2Y', 'M2SL', 'VIXCLS'];
const SUPPORT_CODES = ['GDPC1', 'DGS10', 'SP500', 'DEXUSEU', 'DEXJPUS', 'DEXCHUS', 'DTWEXBGS'];

type MacroState = {
  items: MacroSnapshot[]; support: MacroSnapshot[]; loading: boolean; error: string | null; lastUpdate: number | null; regime: Regime;
  refresh: (force?: boolean) => Promise<void>;
};

export const useMacroStore = create<MacroState>((set) => ({
  items: [], support: [], loading: false, error: null, lastUpdate: null,
  regime: { name: 'Chưa tải', description: 'Kéo xuống hoặc bấm Refresh.', confidence: 0, tone: 'blue', factors: [] },
  refresh: async (force = false) => {
    set({ loading: true, error: null });
    const codes = [...VISIBLE_CODES, ...SUPPORT_CODES];
    const settled = await Promise.allSettled(codes.map((code) => makeSnapshot(code, force, code === 'GDPC1' ? 2200 : 520)));
    const loaded = settled.flatMap((r) => (r.status === 'fulfilled' ? [r.value] : []));
    const items = VISIBLE_CODES.flatMap((code) => { const item = loaded.find((x) => x.code === code); return item ? [item] : []; });
    const support = SUPPORT_CODES.flatMap((code) => { const item = loaded.find((x) => x.code === code); return item ? [item] : []; });
    const firstError = settled.find((r) => r.status === 'rejected');
    set({
      items, support, loading: false,
      error: firstError && items.length === 0 ? String((firstError as PromiseRejectedResult).reason instanceof Error ? (firstError as PromiseRejectedResult).reason.message : (firstError as PromiseRejectedResult).reason) : null,
      lastUpdate: loaded.length ? Math.max(...loaded.map((x) => x.savedAt)) : null,
      regime: detectRegime([...items, ...support]),
    });
  },
}));
