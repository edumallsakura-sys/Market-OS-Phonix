import { create } from 'zustand';
import { cachedJson, createRateLimiter, fetchJson } from '../../core/network';
import { getJson, getString, removeKeysByPrefix, setJson, setString } from '../../core/storage';

export type CryptoTag = 'DeFi' | 'L1' | 'L2' | 'Meme' | 'AI' | 'Gaming' | 'RWA' | 'LSD' | 'Privacy' | 'Exchange';
export const CRYPTO_TAGS: CryptoTag[] = ['DeFi', 'L1', 'L2', 'Meme', 'AI', 'Gaming', 'RWA', 'LSD', 'Privacy', 'Exchange'];

export type MarketCoin = {
  id: string; symbol: string; name: string; image: string;
  price: number; change1h: number | null; change24h: number; change7d: number | null; change30d: number | null;
  marketCap: number; fdv: number | null; volume: number; rank: number | null;
  circulating: number | null; totalSupply: number | null; maxSupply: number | null;
  ath: number | null; athChange: number | null; athDate: string | null;
  atl: number | null; atlChange: number | null; spark: number[]; tags: CryptoTag[];
};
export type CoinLinkSet = { homepage: string[]; explorers: string[]; twitter: string | null; telegram: string | null; github: string[]; whitepaper: string | null };
export type CoinDetail = {
  id: string; symbol: string; name: string; image: string; rank: number | null;
  description: string; categories: string[]; platforms: Record<string, string>; genesisDate: string | null; links: CoinLinkSet;
  price: number | null; marketCap: number | null; fdv: number | null; volume: number | null;
  circulating: number | null; totalSupply: number | null; maxSupply: number | null;
  ath: number | null; athChange: number | null; athDate: string | null;
  atl: number | null; atlChange: number | null; atlDate: string | null; tags: CryptoTag[];
};
export type Candle = { t: number; o: number; h: number; l: number; c: number; v: number; qv: number; trades: number; takerBuy: number };
export type SearchCoin = { id: string; name: string; symbol: string; rank: number | null; thumb: string };
export type GlobalMarket = { active: number; marketCapUsd: number; volumeUsd: number; btcDominance: number; ethDominance: number; marketCapChange24h: number };
export type FearGreed = { value: number; label: string; updatedAt: number };
export type BinanceTicker = { symbol: string; price: number; change24h: number; quoteVolume: number; high: number; low: number };
export type OrderBook = { bids: Array<[number, number]>; asks: Array<[number, number]>; lastUpdateId: number };
export type WatchlistGroup = { id: string; name: string; coinIds: string[] };

const DEFAULT_IDS = ['bitcoin', 'ethereum', 'solana', 'chainlink', 'uniswap'];
const GROUPS_KEY = 'crypto.groups.v2'; const ACTIVE_GROUP_KEY = 'crypto.activeGroup.v2'; const LEGACY_KEY = 'crypto.watchlist.v1';
const cgSlot = createRateLimiter(2_000);

const TAG_BY_ID: Record<string, CryptoTag[]> = {
  bitcoin: ['L1'], ethereum: ['L1'], solana: ['L1'], cardano: ['L1'], avalanche: ['L1'], sui: ['L1'], aptos: ['L1'],
  arbitrum: ['L2'], optimism: ['L2'], mantle: ['L2'], 'matic-network': ['L2'], polygon: ['L2'],
  uniswap: ['DeFi'], aave: ['DeFi'], maker: ['DeFi', 'RWA'], sky: ['DeFi', 'RWA'], curve: ['DeFi'], lido: ['DeFi', 'LSD'],
  chainlink: ['DeFi'], 'render-token': ['AI'], bittensor: ['AI'], 'artificial-superintelligence-alliance': ['AI'],
  dogecoin: ['Meme'], shiba: ['Meme'], pepe: ['Meme'], bonk: ['Meme'],
  immutable: ['Gaming'], beam: ['Gaming'], ronin: ['Gaming'],
  tether: ['Exchange'], binancecoin: ['Exchange', 'L1'], okb: ['Exchange'],
  monero: ['Privacy'], zcash: ['Privacy'],
};

function autoTags(id: string, categories: string[] = []): CryptoTag[] {
  const set = new Set<CryptoTag>(TAG_BY_ID[id] ?? []); const text = categories.join(' ').toLowerCase();
  const rules: Array<[CryptoTag, string[]]> = [
    ['DeFi', ['decentralized finance', 'defi']], ['L1', ['layer 1', 'smart contract platform']], ['L2', ['layer 2', 'rollup']], ['Meme', ['meme']], ['AI', ['artificial intelligence', 'ai agents']], ['Gaming', ['gaming', 'gamefi']], ['RWA', ['real world assets', 'rwa']], ['LSD', ['liquid staking', 'liquid staked']], ['Privacy', ['privacy']], ['Exchange', ['exchange-based tokens', 'centralized exchange']],
  ];
  for (const [tag, needles] of rules) if (needles.some((n) => text.includes(n))) set.add(tag);
  return [...set];
}

function cgHeaders(): Record<string, string> {
  const key = getString('settings.coinGeckoApiKey', process.env.EXPO_PUBLIC_COINGECKO_API_KEY ?? '').trim();
  return key ? { Accept: 'application/json', 'x-cg-demo-api-key': key } : { Accept: 'application/json' };
}
async function cgJson<T>(url: string, retries = 2): Promise<T> { await cgSlot(); return fetchJson<T>(url, { headers: cgHeaders() }, 10_000, retries); }

function marketMap(r: Record<string, unknown>): MarketCoin {
  return {
    id: String(r.id), symbol: String(r.symbol ?? '').toUpperCase(), name: String(r.name ?? ''), image: String(r.image ?? ''), price: Number(r.current_price ?? 0),
    change1h: r.price_change_percentage_1h_in_currency == null ? null : Number(r.price_change_percentage_1h_in_currency), change24h: Number(r.price_change_percentage_24h_in_currency ?? r.price_change_percentage_24h ?? 0),
    change7d: r.price_change_percentage_7d_in_currency == null ? null : Number(r.price_change_percentage_7d_in_currency), change30d: r.price_change_percentage_30d_in_currency == null ? null : Number(r.price_change_percentage_30d_in_currency),
    marketCap: Number(r.market_cap ?? 0), fdv: r.fully_diluted_valuation == null ? null : Number(r.fully_diluted_valuation), volume: Number(r.total_volume ?? 0), rank: r.market_cap_rank == null ? null : Number(r.market_cap_rank),
    circulating: r.circulating_supply == null ? null : Number(r.circulating_supply), totalSupply: r.total_supply == null ? null : Number(r.total_supply), maxSupply: r.max_supply == null ? null : Number(r.max_supply),
    ath: r.ath == null ? null : Number(r.ath), athChange: r.ath_change_percentage == null ? null : Number(r.ath_change_percentage), athDate: r.ath_date == null ? null : String(r.ath_date),
    atl: r.atl == null ? null : Number(r.atl), atlChange: r.atl_change_percentage == null ? null : Number(r.atl_change_percentage),
    spark: ((r.sparkline_in_7d as { price?: number[] } | undefined)?.price ?? []).filter((v) => Number.isFinite(v)), tags: autoTags(String(r.id)),
  };
}

export async function fetchMarkets(ids: string[], force = false): Promise<{ data: MarketCoin[]; stale: boolean; savedAt: number }> {
  const clean = Array.from(new Set(ids.map((x) => x.trim().toLowerCase()).filter(Boolean))).slice(0, 250);
  if (!clean.length) return { data: [], stale: false, savedAt: Date.now() };
  const hash = clean.slice().sort().join(',');
  return cachedJson(`cg.v2.markets.${hash}`, 5 * 60_000, async () => {
    const q = `vs_currency=usd&ids=${encodeURIComponent(clean.join(','))}&order=market_cap_desc&per_page=${clean.length}&page=1&sparkline=true&price_change_percentage=1h,24h,7d,30d&precision=full`;
    const raw = await cgJson<Array<Record<string, unknown>>>(`https://api.coingecko.com/api/v3/coins/markets?${q}`);
    return raw.map(marketMap);
  }, force);
}

export async function fetchMarketUniverse(force = false): Promise<MarketCoin[]> {
  return (await cachedJson('cg.v2.universe.250', 10 * 60_000, async () => {
    const q = 'vs_currency=usd&order=market_cap_desc&per_page=250&page=1&sparkline=false&price_change_percentage=1h,24h,7d,30d&precision=full';
    const raw = await cgJson<Array<Record<string, unknown>>>(`https://api.coingecko.com/api/v3/coins/markets?${q}`);
    return raw.map(marketMap);
  }, force)).data;
}

export async function searchCoins(query: string): Promise<SearchCoin[]> {
  const q = query.trim(); if (!q) return [];
  return (await cachedJson(`cg.v2.search.${q.toLowerCase()}`, 15 * 60_000, async () => {
    const raw = await cgJson<{ coins?: Array<Record<string, unknown>> }>(`https://api.coingecko.com/api/v3/search?query=${encodeURIComponent(q)}`);
    return (raw.coins ?? []).slice(0, 20).map((x) => ({ id: String(x.id), name: String(x.name), symbol: String(x.symbol).toUpperCase(), rank: x.market_cap_rank == null ? null : Number(x.market_cap_rank), thumb: String(x.thumb ?? '') }));
  })).data;
}

export async function fetchCoinDetail(id: string): Promise<CoinDetail> {
  const clean = id.trim().toLowerCase();
  return (await cachedJson(`cg.v2.detail.${clean}`, 60 * 60_000, async () => {
    const r = await cgJson<Record<string, any>>(`https://api.coingecko.com/api/v3/coins/${encodeURIComponent(clean)}?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false`);
    const md = r.market_data ?? {}; const categories = Array.isArray(r.categories) ? r.categories.map(String) : [];
    return {
      id: String(r.id), symbol: String(r.symbol ?? '').toUpperCase(), name: String(r.name ?? clean), image: String(r.image?.large ?? r.image?.small ?? ''), rank: r.market_cap_rank == null ? null : Number(r.market_cap_rank),
      description: String(r.description?.en ?? '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim(), categories, platforms: typeof r.platforms === 'object' && r.platforms ? r.platforms as Record<string, string> : {}, genesisDate: r.genesis_date ?? null,
      links: { homepage: (r.links?.homepage ?? []).filter(Boolean), explorers: (r.links?.blockchain_site ?? []).filter(Boolean), twitter: r.links?.twitter_screen_name ? `https://x.com/${r.links.twitter_screen_name}` : null, telegram: r.links?.telegram_channel_identifier ? `https://t.me/${r.links.telegram_channel_identifier}` : null, github: (r.links?.repos_url?.github ?? []).filter(Boolean), whitepaper: r.links?.whitepaper || null },
      price: md.current_price?.usd == null ? null : Number(md.current_price.usd), marketCap: md.market_cap?.usd == null ? null : Number(md.market_cap.usd), fdv: md.fully_diluted_valuation?.usd == null ? null : Number(md.fully_diluted_valuation.usd), volume: md.total_volume?.usd == null ? null : Number(md.total_volume.usd),
      circulating: md.circulating_supply == null ? null : Number(md.circulating_supply), totalSupply: md.total_supply == null ? null : Number(md.total_supply), maxSupply: md.max_supply == null ? null : Number(md.max_supply),
      ath: md.ath?.usd == null ? null : Number(md.ath.usd), athChange: md.ath_change_percentage?.usd == null ? null : Number(md.ath_change_percentage.usd), athDate: md.ath_date?.usd ?? null,
      atl: md.atl?.usd == null ? null : Number(md.atl.usd), atlChange: md.atl_change_percentage?.usd == null ? null : Number(md.atl_change_percentage.usd), atlDate: md.atl_date?.usd ?? null, tags: autoTags(clean, categories),
    } satisfies CoinDetail;
  })).data;
}

export async function fetchCoinChart(id: string, days = 30): Promise<Array<{ t: number; value: number }>> {
  return (await cachedJson(`cg.v2.chart.${id}.${days}`, 15 * 60_000, async () => {
    const r = await cgJson<{ prices?: Array<[number, number]> }>(`https://api.coingecko.com/api/v3/coins/${encodeURIComponent(id)}/market_chart?vs_currency=usd&days=${Math.max(1, Math.min(365, days))}&precision=full`);
    return (r.prices ?? []).filter((x) => Number.isFinite(x[1])).map((x) => ({ t: x[0], value: x[1] }));
  })).data;
}

export async function fetchTrending(): Promise<SearchCoin[]> {
  return (await cachedJson('cg.v2.trending', 10 * 60_000, async () => {
    const r = await cgJson<{ coins?: Array<{ item: Record<string, unknown> }> }>('https://api.coingecko.com/api/v3/search/trending');
    return (r.coins ?? []).slice(0, 7).map(({ item }) => ({ id: String(item.id), name: String(item.name), symbol: String(item.symbol).toUpperCase(), rank: item.market_cap_rank == null ? null : Number(item.market_cap_rank), thumb: String(item.thumb ?? '') }));
  })).data;
}

export async function fetchGlobal(force = false): Promise<GlobalMarket> {
  return (await cachedJson('cg.v2.global', 30 * 60_000, async () => {
    const r = await cgJson<{ data?: Record<string, any> }>('https://api.coingecko.com/api/v3/global'); const d = r.data ?? {};
    return { active: Number(d.active_cryptocurrencies ?? 0), marketCapUsd: Number(d.total_market_cap?.usd ?? 0), volumeUsd: Number(d.total_volume?.usd ?? 0), btcDominance: Number(d.market_cap_percentage?.btc ?? 0), ethDominance: Number(d.market_cap_percentage?.eth ?? 0), marketCapChange24h: Number(d.market_cap_change_percentage_24h_usd ?? 0) };
  }, force)).data;
}

export async function fetchFearGreed(force = false): Promise<FearGreed> {
  return (await cachedJson('crypto.fng.v1', 30 * 60_000, async () => {
    const r = await fetchJson<{ data?: Array<{ value?: string; value_classification?: string; timestamp?: string }> }>('https://api.alternative.me/fng/?limit=1&format=json'); const x = r.data?.[0];
    return { value: Number(x?.value ?? 0), label: String(x?.value_classification ?? 'Unknown'), updatedAt: Number(x?.timestamp ?? 0) * 1000 };
  }, force)).data;
}

const BINANCE_BASES = ['https://data-api.binance.vision', 'https://api.binance.com', 'https://api-gcp.binance.com'];
async function binanceFirst<T>(path: string): Promise<T> { let last: unknown; for (const base of BINANCE_BASES) { try { return await fetchJson<T>(`${base}${path}`, {}, 10_000, 1); } catch (e) { last = e; } } throw last instanceof Error ? last : new Error('Binance public endpoints unavailable'); }

export async function fetchBinanceKlines(symbol: string, interval: string, limit = 200): Promise<Candle[]> {
  const s = symbol.replace(/[^A-Za-z0-9]/g, '').toUpperCase(); const lim = Math.min(500, Math.max(30, limit));
  const rows = await binanceFirst<unknown[][]>(`/api/v3/klines?symbol=${encodeURIComponent(s)}&interval=${encodeURIComponent(interval)}&limit=${lim}`);
  return rows.map((r) => ({ t: Number(r[0]), o: Number(r[1]), h: Number(r[2]), l: Number(r[3]), c: Number(r[4]), v: Number(r[5]), qv: Number(r[7] ?? 0), trades: Number(r[8] ?? 0), takerBuy: Number(r[9] ?? 0) }));
}
export async function fetchBinanceTicker(symbol: string): Promise<BinanceTicker> {
  const s = symbol.replace(/[^A-Za-z0-9]/g, '').toUpperCase(); const r = await binanceFirst<Record<string, string>>(`/api/v3/ticker/24hr?symbol=${encodeURIComponent(s)}`);
  return { symbol: s, price: Number(r.lastPrice ?? 0), change24h: Number(r.priceChangePercent ?? 0), quoteVolume: Number(r.quoteVolume ?? 0), high: Number(r.highPrice ?? 0), low: Number(r.lowPrice ?? 0) };
}
export async function fetchBinanceDepth(symbol: string, limit = 20): Promise<OrderBook> {
  const s = symbol.replace(/[^A-Za-z0-9]/g, '').toUpperCase(); const lim = [5, 10, 20, 50, 100].includes(limit) ? limit : 20;
  const r = await binanceFirst<{ lastUpdateId: number; bids: string[][]; asks: string[][] }>(`/api/v3/depth?symbol=${encodeURIComponent(s)}&limit=${lim}`);
  return { lastUpdateId: r.lastUpdateId, bids: r.bids.map((x) => [Number(x[0]), Number(x[1])]), asks: r.asks.map((x) => [Number(x[0]), Number(x[1])]) };
}

export async function fetchProtocolTVL(protocol: string): Promise<number | null> {
  try { const value = await fetchJson<number>(`https://api.llama.fi/tvl/${encodeURIComponent(protocol.trim().toLowerCase())}`); return Number.isFinite(value) ? value : null; } catch { return null; }
}
export async function fetchChains(): Promise<Array<{ name: string; tvl: number }>> {
  return (await cachedJson('llama.chains.v1', 30 * 60_000, async () => { const rows = await fetchJson<Array<Record<string, unknown>>>('https://api.llama.fi/v2/chains'); return rows.map((x) => ({ name: String(x.name ?? ''), tvl: Number(x.tvl ?? 0) })).filter((x) => x.name && Number.isFinite(x.tvl)); })).data;
}

export type CoinScore = { total: number; label: 'Strong' | 'Watch' | 'Neutral' | 'Avoid'; factors: string[]; breakdown: Record<string, number> };
export function scoreCoin(c: MarketCoin, detail?: CoinDetail | null, protocolTvl?: number | null): CoinScore {
  const breakdown: Record<string, number> = {}; const factors: string[] = [];
  const rankScore = c.rank && c.rank <= 10 ? 20 : c.rank && c.rank <= 100 ? 15 : c.rank && c.rank <= 300 ? 9 : 3; breakdown.rank = rankScore; factors.push(`Market cap rank +${rankScore}`);
  const turnover = c.marketCap > 0 ? c.volume / c.marketCap : 0; const liq = turnover >= 0.04 && turnover <= 0.45 ? 20 : turnover > 0.01 ? 12 : turnover > 0 ? 6 : 0; breakdown.liquidity = liq; factors.push(`Volume/MCap ${(turnover * 100).toFixed(1)}% +${liq}`);
  const momentum = (c.change7d ?? 0) > 5 ? 12 : (c.change7d ?? 0) > 0 ? 8 : (c.change7d ?? 0) > -15 ? 4 : 0; breakdown.momentum = momentum; factors.push(`7d momentum +${momentum}`);
  const ath = (c.athChange ?? -100) > -25 ? 14 : (c.athChange ?? -100) > -60 ? 9 : 4; breakdown.ath = ath; factors.push(`Distance from ATH +${ath}`);
  const ageDays = detail?.genesisDate ? Math.max(0, (Date.now() - Date.parse(`${detail.genesisDate}T00:00:00Z`)) / 86_400_000) : null; const age = ageDays == null ? 5 : ageDays > 1825 ? 12 : ageDays > 730 ? 9 : ageDays > 180 ? 5 : 2; breakdown.age = age; factors.push(`Age/track record +${age}`);
  const category = (detail?.tags ?? c.tags).some((t) => ['DeFi', 'L1', 'L2', 'AI', 'RWA'].includes(t)) ? 8 : 4; breakdown.category = category; factors.push(`Category evidence +${category}`);
  const tvl = protocolTvl != null && protocolTvl > 1_000_000_000 ? 14 : protocolTvl != null && protocolTvl > 100_000_000 ? 9 : protocolTvl != null && protocolTvl > 0 ? 4 : 0; breakdown.tvl = tvl; if (protocolTvl != null) factors.push(`Protocol TVL +${tvl}`);
  const stability = c.change24h > -15 && c.change24h < 20 ? 8 : 2; breakdown.stability = stability;
  const total = Math.max(0, Math.min(100, Object.values(breakdown).reduce((a, b) => a + b, 0)));
  return { total, label: total >= 72 ? 'Strong' : total >= 58 ? 'Watch' : total >= 40 ? 'Neutral' : 'Avoid', factors, breakdown };
}

function initialGroups(): WatchlistGroup[] {
  const existing = getJson<WatchlistGroup[] | null>(GROUPS_KEY, null); if (existing?.length) return existing;
  const legacy = getJson<string[]>(LEGACY_KEY, DEFAULT_IDS); const groups = [{ id: 'main', name: 'Main', coinIds: legacy.length ? legacy : DEFAULT_IDS }]; setJson(GROUPS_KEY, groups); return groups;
}
function saveGroups(groups: WatchlistGroup[]): void { setJson(GROUPS_KEY, groups); }

 type CryptoState = {
  groups: WatchlistGroup[]; activeListId: string; market: MarketCoin[]; loading: boolean; error: string | null; stale: boolean; lastUpdate: number | null;
  refresh: (force?: boolean) => Promise<void>; add: (id: string) => Promise<void>; remove: (id: string) => void; createList: (name: string) => void; renameList: (id: string, name: string) => void; deleteList: (id: string) => void; switchList: (id: string) => Promise<void>; duplicateList: (id: string) => void;
};

const groupsSeed = initialGroups(); const activeSeedRaw = getString(ACTIVE_GROUP_KEY, groupsSeed[0]?.id ?? 'main'); const activeSeed = groupsSeed.some((g) => g.id === activeSeedRaw) ? activeSeedRaw : groupsSeed[0]?.id ?? 'main';
export const useCryptoStore = create<CryptoState>((set, get) => ({
  groups: groupsSeed, activeListId: activeSeed, market: [], loading: false, error: null, stale: false, lastUpdate: null,
  refresh: async (force = false) => {
    const active = get().groups.find((g) => g.id === get().activeListId); set({ loading: true, error: null });
    try { const r = await fetchMarkets(active?.coinIds ?? [], force); set({ market: r.data, stale: r.stale, lastUpdate: r.savedAt, loading: false }); }
    catch (e) { set({ error: e instanceof Error ? e.message : String(e), loading: false }); }
  },
  add: async (id) => {
    const clean = id.trim().toLowerCase(); if (!clean) return; const groups = get().groups.map((g) => g.id === get().activeListId ? { ...g, coinIds: Array.from(new Set([...g.coinIds, clean])).slice(0, 250) } : g); saveGroups(groups); set({ groups }); await get().refresh(true);
  },
  remove: (id) => { const groups = get().groups.map((g) => g.id === get().activeListId ? { ...g, coinIds: g.coinIds.filter((x) => x !== id) } : g); saveGroups(groups); set({ groups, market: get().market.filter((x) => x.id !== id) }); },
  createList: (name) => { const clean = name.trim(); if (!clean) return; const id = `list-${Date.now()}`; const groups = [...get().groups, { id, name: clean, coinIds: [] }]; saveGroups(groups); setString(ACTIVE_GROUP_KEY, id); set({ groups, activeListId: id, market: [] }); },
  renameList: (id, name) => { const clean = name.trim(); if (!clean) return; const groups = get().groups.map((g) => g.id === id ? { ...g, name: clean } : g); saveGroups(groups); set({ groups }); },
  deleteList: (id) => { if (get().groups.length <= 1) return; const groups = get().groups.filter((g) => g.id !== id); const activeListId = get().activeListId === id ? groups[0]?.id ?? 'main' : get().activeListId; saveGroups(groups); setString(ACTIVE_GROUP_KEY, activeListId); set({ groups, activeListId, market: [] }); void get().refresh(false); },
  switchList: async (id) => { if (!get().groups.some((g) => g.id === id)) return; setString(ACTIVE_GROUP_KEY, id); set({ activeListId: id, market: [] }); await get().refresh(false); },
  duplicateList: (id) => { const source = get().groups.find((g) => g.id === id); if (!source) return; const copy = { id: `list-${Date.now()}`, name: `${source.name} Copy`, coinIds: [...source.coinIds] }; const groups = [...get().groups, copy]; saveGroups(groups); set({ groups }); },
}));

export function clearCryptoCache(): number { return removeKeysByPrefix('cg.') + removeKeysByPrefix('crypto.fng.') + removeKeysByPrefix('llama.'); }
