import React, { useState } from 'react';
import { Pressable, SafeAreaView, StyleSheet, Text, View } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../../App';
import { C } from '../core/theme';
import { getString, setString } from '../core/storage';
import MacroScreen from '../modules/macro/MacroScreen';
import CryptoScreen from '../modules/crypto/CryptoScreen';
import ChartScreen from '../modules/chart/ChartScreen';
import CopilotScreen from '../modules/ai/CopilotScreen';
import PortfolioScreen from '../modules/portfolio/PortfolioScreen';
import SettingsScreen from '../modules/settings/SettingsScreen';

type Props = NativeStackScreenProps<RootStackParamList, 'Main'>;
type TabKey = 'macro' | 'crypto' | 'chart' | 'ai' | 'portfolio' | 'settings';
const tabs: Array<{ key: TabKey; label: string; icon: string }> = [
  { key: 'macro', label: 'Macro', icon: '◈' },
  { key: 'crypto', label: 'Crypto', icon: '₿' },
  { key: 'chart', label: 'Chart', icon: '⌁' },
  { key: 'ai', label: 'AI', icon: '✦' },
  { key: 'portfolio', label: 'PF', icon: '◉' },
  { key: 'settings', label: 'Cài đặt', icon: '⚙' },
];

export default function MainShell({ navigation }: Props) {
  const saved = getString('ui.lastTab', 'macro') as TabKey;
  const [tab, setTab] = useState<TabKey>(tabs.some((x) => x.key === saved) ? saved : 'macro');
  const screen = tab === 'macro' ? <MacroScreen navigation={navigation} />
    : tab === 'crypto' ? <CryptoScreen navigation={navigation} />
      : tab === 'chart' ? <ChartScreen />
        : tab === 'ai' ? <CopilotScreen />
          : tab === 'portfolio' ? <PortfolioScreen />
            : <SettingsScreen />;

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.brand}><Text style={styles.title}>ALPHAFLOW OS</Text><Text style={styles.version}>V1.1.6 · Deep Modules</Text></View>
      <View style={styles.body}>{screen}</View>
      <View style={styles.nav}>
        {tabs.map((item) => (
          <Pressable key={item.key} onPress={() => { setTab(item.key); setString('ui.lastTab', item.key); }} style={[styles.navItem, tab === item.key && styles.navActive]}>
            <Text style={[styles.navIcon, tab === item.key && { color: C.gold }]}>{item.icon}</Text>
            <Text numberOfLines={1} style={[styles.navText, tab === item.key && { color: C.gold }]}>{item.label}</Text>
          </Pressable>
        ))}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  brand: { paddingHorizontal: 16, paddingTop: 8, paddingBottom: 8, borderBottomWidth: 1, borderColor: C.border, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline' },
  title: { color: C.gold, fontWeight: '900', fontSize: 20, letterSpacing: 1 },
  version: { color: C.muted, fontSize: 11 },
  body: { flex: 1 },
  nav: { height: 62, borderTopWidth: 1, borderColor: C.border, backgroundColor: C.panel, flexDirection: 'row' },
  navItem: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 2 },
  navActive: { backgroundColor: '#171A20' },
  navIcon: { color: C.muted, fontSize: 17 },
  navText: { color: C.muted, fontSize: 9, fontWeight: '700' },
});
