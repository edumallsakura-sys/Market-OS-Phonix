MARKET OS PHOENIX v1 — ONECLICK

1) Giải nén ZIP này.
2) Upload toàn bộ nội dung (.github + projects + README.txt) lên repo GitHub trống.
3) Commit vào branch main.
4) GitHub -> Actions -> Build MarketOS Phoenix APK -> Run workflow.
5) Tải artifact MarketOS-Phoenix-v1-debug-APK.

Workflow tự tìm ZIP trong repo, giải nén, phát hiện settings.gradle và build bằng JDK17 + Gradle 8.9.
