MARKET OS PHOENIX v2 — GITHUB ONECLICK

1. Giải nén ZIP này.
2. Upload TOÀN BỘ nội dung bên trong vào root repository GitHub.
3. Vào Actions > Build MarketOS Phoenix v2 APK > Run workflow.
4. Khi job xanh, tải artifact: MarketOS-Phoenix-v2-debug-APK.

Workflow tự tìm ZIP Android trong /projects, giải nén, chạy static preflight rồi assembleDebug.
