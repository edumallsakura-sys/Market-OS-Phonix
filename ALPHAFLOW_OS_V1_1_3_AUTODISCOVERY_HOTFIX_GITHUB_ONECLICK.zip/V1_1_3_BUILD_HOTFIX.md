# v1.1.3 build hotfix

Root cause addressed: the previous workflow hardcoded a version-specific source ZIP path.
The application modules are preserved; this release changes packaging/build discovery only.

Preferred repository source path from now on:
`projects/ALPHAFLOW_OS_SOURCE.zip`
