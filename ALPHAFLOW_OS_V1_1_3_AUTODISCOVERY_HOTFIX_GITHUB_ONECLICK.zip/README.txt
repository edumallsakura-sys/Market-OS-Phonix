ALPHAFLOW OS v1.1.3 — ROBUST SOURCE AUTODISCOVERY HOTFIX
=========================================================

WHY THIS VERSION EXISTS
The previous workflow expected one exact versioned path:
  projects/ALPHAFLOW_OS_V1_1_2_SOURCE.zip
If the repo still contained an older source ZIP, or only the workflow was replaced,
the build stopped immediately with "Missing ...SOURCE.zip".

WHAT CHANGED
1. The source ZIP now has a STABLE filename:
     projects/ALPHAFLOW_OS_SOURCE.zip
2. The workflow can also build if the Expo project is unpacked at repository root.
3. If the stable ZIP is absent, the workflow searches recursively for an older
   ALPHAFLOW *SOURCE*.zip instead of blindly failing on one hardcoded version.
4. A repository diagnostic step prints exactly what GitHub received.
5. Android SDK setup still uses the runner's preinstalled SDK; no sdkmanager action.

UPLOAD
- Extract THIS outer ZIP on your phone/computer.
- Upload ALL extracted contents to the ROOT of the GitHub repository.
- Confirm GitHub contains BOTH:
    .github/workflows/build-apk.yml
    projects/ALPHAFLOW_OS_SOURCE.zip
- Run Actions -> "Build ALPHAFLOW OS v1.1.3 APK - ROBUST SOURCE AUTODISCOVERY".

Do not upload only build-apk.yml.
