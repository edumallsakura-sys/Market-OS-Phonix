ALPHAFLOW OS v1.1.0 — DEEP MODULES — GITHUB ONECLICK

Cach dung:
1. Giai nen ZIP nay.
2. Upload TOAN BO noi dung ben trong len root repo GitHub.
3. Branch main hoac master.
4. GitHub -> Actions -> Build ALPHAFLOW OS v1.1 APK -> Run workflow.
5. Khi build xanh -> Artifacts -> ALPHAFLOW-OS-v1.1-APK.
6. Giai nen artifact va cai ALPHAFLOW-OS-v1.1-debug.apk.

Khong can Android Studio.
Khong can EAS secret.
API keys FRED/Gemini/OpenRouter/CoinGecko Demo co the nhap trong app Settings va luu local MMKV.

Source:
projects/ALPHAFLOW_OS_V1_1_SOURCE.zip
