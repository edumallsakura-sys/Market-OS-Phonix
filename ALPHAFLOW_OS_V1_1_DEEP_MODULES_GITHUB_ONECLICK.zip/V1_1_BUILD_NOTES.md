# ALPHAFLOW OS v1.1.0 — Deep Modules

This package keeps the compact one-click structure used in the supplied MarketOS packages: one GitHub workflow plus one nested source ZIP.

## Deepened modules
- Macro: ~40 FRED series metadata, 6-card cockpit, support signals for regime, search/categories/favorites, official-date economic calendar seed, detail ranges/stats/change table/notes.
- Crypto: grouped watchlists, autocomplete search, tags/sorts, CoinGecko global + Fear & Greed, discovery, top-250 screener, richer coin detail, research score, DefiLlama TVL helper.
- Chart: Binance candles rendered natively with SVG, MA20/50, volume, RSI, MACD, ticker and depth snapshot.
- AI: local evidence context from Macro/Crypto, Gemini -> OpenRouter fallback, bounded MMKV history.
- Portfolio: edit/remove positions, PnL/cost, allocation donut, JSON share/backup/import.
- Alerts: local price/change/volume checks, notification cooldown, pause/resume, cache tools.

## Runtime guardrails
- 10 second HTTP timeout.
- Finite exponential retries.
- No unbounded polling or setInterval background loops.
- No background WebSocket.
- Stale-cache fallback for transient API failures.
- Android API 26+.

## Verification performed before packaging
- Static audit passed.
- TypeScript syntax transpilation passed for all TS/TSX source files.
- Full native Gradle build is intentionally delegated to GitHub Actions because dependencies/Android SDK artifacts are downloaded there.
