ALPHAFLOW OS v1.4.3 — COPILOT KEYBOARD HOTFIX

Upload the extracted contents of this ONECLICK package to the GitHub repository root.
Required paths:
  .github/workflows/build-apk.yml
  projects/ALPHAFLOW_OS_SOURCE.zip

GitHub Actions workflow:
  Build ALPHAFLOW OS v1.4.3 APK - COPILOT KEYBOARD HOTFIX

This version preserves all v1.4.2 functionality and fixes the Android keyboard/composer overlap in AI Copilot.
