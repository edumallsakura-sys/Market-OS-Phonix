# ALPHAFLOW OS v1.4.3 — Android Copilot Keyboard Hotfix

Version: 1.4.3  
Android versionCode: 16

## Root cause confirmed from v1.4.2
- `softwareKeyboardLayoutMode=resize` was enabled, but `CopilotScreen` also used `KeyboardAvoidingView` with Android `behavior=height`.
- On some Android/OEM/Gboard combinations this double-handling can shrink the chat twice or fail to move the composer, leaving the input bar below the keyboard.

## Fix
- Removed `KeyboardAvoidingView` from Copilot.
- Added runtime overlap measurement using `measureInWindow()` + `keyboardDidShow`.
- If Android already resizes the app window, keyboard overlap resolves to 0 and nothing extra is added.
- If the keyboard overlays the app, only the real overlap is applied as bottom margin to the composer.
- Re-measures after MainShell hides bottom navigation so the composer sits directly above Gboard.
- Clears timers/listeners on unmount; no polling or background loop added.

## Preserved
- Macro/Crypto/Chart/Desk/Portfolio/Settings behavior is unchanged.
- Gemini → Groq fallback and evidence-first AI context are unchanged.
- Android safety contract remains: no background service, no infinite polling, no 24/7 WebSocket, bounded cache/network behavior.
