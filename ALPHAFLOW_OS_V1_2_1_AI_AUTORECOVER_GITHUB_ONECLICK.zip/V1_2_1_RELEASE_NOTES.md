# ALPHAFLOW OS v1.2.1 — AI Auto-Recover

Hotfix for AI Copilot returning `HTTP 404` on both providers.

- Cause: `gemini-2.5-flash` and `llama-3.3-70b-versatile` no longer exist for most keys (Groq decommissioned the latter on 2026-08-16; Google is retiring Gemini 2.5 Flash).
- Fix: dynamic model discovery + automatic fallback + cache + re-discovery (`src/core/ai.ts`).
- Also: header safe-area fix, Test AI button, real error messages, calendar evidence for Copilot.

Android version 1.2.1 · versionCode 11 · artifact `ALPHAFLOW-OS-v1.2.1-STANDALONE-APK`.
