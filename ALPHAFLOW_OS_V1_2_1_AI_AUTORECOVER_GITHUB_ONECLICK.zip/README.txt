ALPHAFLOW OS v1.2.1 — AI AUTO-RECOVER (hotfix on v1.2.0)

UPLOAD TO GITHUB (same as before):
1) Extract this ONECLICK ZIP.
2) Upload/overwrite ALL extracted contents in the repository root.
3) At minimum, repo must contain:
   .github/workflows/build-apk.yml
   projects/ALPHAFLOW_OS_SOURCE.zip
4) Run GitHub Actions workflow:
   Build ALPHAFLOW OS v1.2.1 APK - AI AUTO-RECOVER
5) Download artifact:
   ALPHAFLOW-OS-v1.2.1-STANDALONE-APK

WHAT CHANGED:
- FIX: Copilot "Gemini: HTTP 404 · Groq: HTTP 404" — the hard-coded models were retired by Google/Groq.
  The app now discovers a working model from your own key (ListModels), tries up to 3, remembers the winner,
  and re-discovers automatically if it is retired again. No more rebuilding the APK just to rename a model.
- FIX: header drawing under the Android status bar.
- NEW: "Test AI" button in Cài đặt (real call per provider, shows the model used).
- NEW: real server error text instead of a bare "HTTP 404"; API keys never appear in URLs.
- Copilot evidence now includes the in-app economic calendar + current time.

AFTER INSTALLING: Cài đặt -> keep your Gemini/Groq keys -> "Lưu API keys" -> "Test AI".
Macro tab stays empty until a FRED API key is entered (free at fred.stlouisfed.org).
