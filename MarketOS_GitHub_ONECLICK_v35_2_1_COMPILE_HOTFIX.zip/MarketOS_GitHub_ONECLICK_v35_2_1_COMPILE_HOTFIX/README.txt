MarketOS GitHub ONE-CLICK v35.2.1 — COMPILE HOTFIX

MỤC ĐÍCH
- Sửa lỗi Gradle/Javac `cannot find symbol: ensureLocalTranslator()` phát sinh sau cleanup V35.2.
- Khôi phục đúng ML Kit local-translator lifecycle helper; giữ nguyên Investor Focus UI và toàn bộ engine/evidence/track record V35.
- Không hoàn tác dead-code cleanup hợp lệ và không cắt chức năng.

CÁCH BUILD
1) Giải nén file ONE-CLICK này vào root repo GitHub.
2) Commit/push toàn bộ .github/workflows/build-apk.yml + projects/*.zip.
3) Mở Actions > Universal Android ZIP Builder V35.2.1 > Run workflow.
4) Tải artifact Android-APKs.

CI chạy V35.2.1 static audit + JavaScript syntax + Android assembleDebug trước khi upload APK.

Source: projects/MarketOS_Android_v35_2_1_COMPILE_HOTFIX.zip
Version: 35.0.3 / versionCode 42
Engine/hash semantics: 35.0.0 (unchanged)
